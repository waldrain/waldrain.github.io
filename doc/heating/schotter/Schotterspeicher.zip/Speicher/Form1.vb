Public Class Form1
    Inherits System.Windows.Forms.Form
    Public ooo, Objektbezeichnung, Datei, Feld, Speicherfeld, Verlauf As String
    Public StartOK, Richtung, p, pmax, i, j, k, imax(12), jmax(12), kmax(12), Dtau, Tagesstunde(9000) As Integer
    Public imax1(12), jmax1(12), kmax1(12), imax2(12), jmax2(12), kmax2(12), s, smax, R(26, 25), ETag As Integer
    Public BS, BSmax, Zeit, Zeitmax, GanzeStunde, Stunde, Stunde1, Uhrbeginn, ETagfix, Intervall, Intervallmax As Integer
    Public Zahl, sBeginn, sEnde, sStep, BSTest, pTest As Integer
    Public rho, lam, c, PSI, V(12), Anteil(12), O(12), Fak, Exp, Hoehe, Laenge, Breite, Vh, dK, pL As Single
    Public x, y, Rest, Rest0, a(12), b(12), Dx(12), Dy(12), VTyp(12), Vfest, ZP(12), Oanteil(12) As Single
    Public Sum, mfest, VLuft, aFaehigkeit, DtauPartikel(12), x1, y1 As Single
    Public a1(12), a2(12), b1(12), b2(12), Dx1(12), Dy1(12), Dx2(12), Dy2(12), DtauPartikel1(12), DtauPartikel2(12) As Single
    Public AEi(12), AE(12), VE(12), CE(12), REi(12), RE(12), LEi(12), LE(12), tStart As Single
    Public t(120, 12, 15, 15, 15), tn(120, 12, 15, 15, 15) As Single
    Public QSpeicher(9000), QMedium(9000), tLein(9000), xLein(9000), phiLein(9000) As Single
    Public RichtungBS(9000), tLaus(9000), xLaus(9000), phiLaus(9000), Kondensatmenge(9000) As Single
    Public tau, tauUhr, Dtaumax, DtauVorschlag, tx, tx1, xx, xx1, tLa, xLa, tL(120), xL(120), phiL(120) As Single
    Public tLETag(21, 25), xLETag(21, 25), phiETag(21, 25) As Single
    Public rhoM, cM, PrM, lamM, nyM, tmittel As Single
    Public QL(120), tE, Qiein, Qiaus, Qjein, Qjaus, Qkein, Qkaus, QE, alphaL As Single
    Public hstern, xS, xstern, tstern, ttaustern, phistern, w, FF, NuZ, ReZ As Single
    Public hein, phiein, ttauein, vein, mLmax, mL, VLanteil(21, 25), hL(120), Kondensat(120) As Single


#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents TextBox155 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox131 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox130 As System.Windows.Forms.TextBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents TextBox170 As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.TextBox155 = New System.Windows.Forms.TextBox
        Me.TextBox131 = New System.Windows.Forms.TextBox
        Me.TextBox130 = New System.Windows.Forms.TextBox
        Me.Button7 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Label71 = New System.Windows.Forms.Label
        Me.Label73 = New System.Windows.Forms.Label
        Me.Button10 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label69 = New System.Windows.Forms.Label
        Me.Label74 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.Label48 = New System.Windows.Forms.Label
        Me.Label47 = New System.Windows.Forms.Label
        Me.Button5 = New System.Windows.Forms.Button
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.TextBox6 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label78 = New System.Windows.Forms.Label
        Me.Label79 = New System.Windows.Forms.Label
        Me.TextBox170 = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.TextBox31 = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.TextBox30 = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label85 = New System.Windows.Forms.Label
        Me.TextBox20 = New System.Windows.Forms.TextBox
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.TextBox36 = New System.Windows.Forms.TextBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.TextBox35 = New System.Windows.Forms.TextBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.TextBox38 = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.TextBox37 = New System.Windows.Forms.TextBox
        Me.TextBox13 = New System.Windows.Forms.TextBox
        Me.TextBox12 = New System.Windows.Forms.TextBox
        Me.TextBox11 = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label75 = New System.Windows.Forms.Label
        Me.Label72 = New System.Windows.Forms.Label
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.TextBox44 = New System.Windows.Forms.TextBox
        Me.TextBox43 = New System.Windows.Forms.TextBox
        Me.TextBox42 = New System.Windows.Forms.TextBox
        Me.TextBox41 = New System.Windows.Forms.TextBox
        Me.Label80 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.Label53 = New System.Windows.Forms.Label
        Me.Label52 = New System.Windows.Forms.Label
        Me.TextBox50 = New System.Windows.Forms.TextBox
        Me.TextBox45 = New System.Windows.Forms.TextBox
        Me.Label51 = New System.Windows.Forms.Label
        Me.Label46 = New System.Windows.Forms.Label
        Me.Label49 = New System.Windows.Forms.Label
        Me.Label50 = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox34 = New System.Windows.Forms.TextBox
        Me.TextBox39 = New System.Windows.Forms.TextBox
        Me.TextBox40 = New System.Windows.Forms.TextBox
        Me.TextBox23 = New System.Windows.Forms.TextBox
        Me.TextBox24 = New System.Windows.Forms.TextBox
        Me.TextBox25 = New System.Windows.Forms.TextBox
        Me.TextBox26 = New System.Windows.Forms.TextBox
        Me.TextBox27 = New System.Windows.Forms.TextBox
        Me.TextBox28 = New System.Windows.Forms.TextBox
        Me.TextBox29 = New System.Windows.Forms.TextBox
        Me.TextBox33 = New System.Windows.Forms.TextBox
        Me.TextBox19 = New System.Windows.Forms.TextBox
        Me.TextBox21 = New System.Windows.Forms.TextBox
        Me.TextBox22 = New System.Windows.Forms.TextBox
        Me.TextBox14 = New System.Windows.Forms.TextBox
        Me.TextBox15 = New System.Windows.Forms.TextBox
        Me.TextBox16 = New System.Windows.Forms.TextBox
        Me.TextBox17 = New System.Windows.Forms.TextBox
        Me.TextBox18 = New System.Windows.Forms.TextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.TextBox5 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox32 = New System.Windows.Forms.TextBox
        Me.Button4 = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label56 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label55 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label42 = New System.Windows.Forms.Label
        Me.TextBox51 = New System.Windows.Forms.TextBox
        Me.Label54 = New System.Windows.Forms.Label
        Me.TextBox52 = New System.Windows.Forms.TextBox
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox155
        '
        Me.TextBox155.ForeColor = System.Drawing.Color.Green
        Me.TextBox155.Location = New System.Drawing.Point(360, 136)
        Me.TextBox155.Name = "TextBox155"
        Me.TextBox155.Size = New System.Drawing.Size(64, 27)
        Me.TextBox155.TabIndex = 563
        Me.TextBox155.Text = ""
        Me.TextBox155.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox131
        '
        Me.TextBox131.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox131.Location = New System.Drawing.Point(904, 8)
        Me.TextBox131.Name = "TextBox131"
        Me.TextBox131.Size = New System.Drawing.Size(328, 26)
        Me.TextBox131.TabIndex = 580
        Me.TextBox131.Text = ""
        '
        'TextBox130
        '
        Me.TextBox130.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox130.ForeColor = System.Drawing.Color.Magenta
        Me.TextBox130.Location = New System.Drawing.Point(536, 8)
        Me.TextBox130.Name = "TextBox130"
        Me.TextBox130.Size = New System.Drawing.Size(360, 26)
        Me.TextBox130.TabIndex = 581
        Me.TextBox130.Text = ""
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.Magenta
        Me.Button7.Location = New System.Drawing.Point(352, 808)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(280, 32)
        Me.Button7.TabIndex = 567
        Me.Button7.Text = "DRUCK EINGABEWERTE"
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.Magenta
        Me.Button8.Location = New System.Drawing.Point(832, 784)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(224, 32)
        Me.Button8.TabIndex = 568
        Me.Button8.Text = "DRUCK ERGEBNISSE"
        '
        'Label71
        '
        Me.Label71.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label71.Location = New System.Drawing.Point(480, 520)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(216, 68)
        Me.Label71.TabIndex = 574
        Me.Label71.Text = "3. Bei Eingabe oder Korrektur der Werte bitte nur Zahlen, Komma, Minuszeichen ode" & _
        "r ""Blank"" verwenden!"
        '
        'Label73
        '
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label73.Location = New System.Drawing.Point(480, 480)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(216, 38)
        Me.Label73.TabIndex = 573
        Me.Label73.Text = "2. Daten aus Datei laden oder Neueingabe vornehmen!"
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.Magenta
        Me.Button10.Location = New System.Drawing.Point(648, 744)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(168, 32)
        Me.Button10.TabIndex = 570
        Me.Button10.Text = "ZEITVERLAUF"
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.Magenta
        Me.Button3.Location = New System.Drawing.Point(176, 744)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(160, 32)
        Me.Button3.TabIndex = 563
        Me.Button3.Text = "DATEI LADEN"
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.Magenta
        Me.Button6.Location = New System.Drawing.Point(832, 744)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(224, 32)
        Me.Button6.TabIndex = 564
        Me.Button6.Text = "BERECHNUNG"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Magenta
        Me.Button2.Location = New System.Drawing.Point(0, 744)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(160, 32)
        Me.Button2.TabIndex = 562
        Me.Button2.Text = "STARTEN"
        '
        'Label69
        '
        Me.Label69.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label69.Location = New System.Drawing.Point(480, 632)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(224, 69)
        Me.Label69.TabIndex = 575
        Me.Label69.Text = "5. ZEITVERLAUF, BERECH-NUNG, DRUCK EINGABE-WERTE bzw. ERGEBNISSE oder DIAGRAMM dr" & _
        "�cken!"
        '
        'Label74
        '
        Me.Label74.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.ForeColor = System.Drawing.Color.Magenta
        Me.Label74.Location = New System.Drawing.Point(480, 416)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(73, 23)
        Me.Label74.TabIndex = 571
        Me.Label74.Text = "Abl�ufe:"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Magenta
        Me.Button1.Location = New System.Drawing.Point(1072, 744)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(160, 32)
        Me.Button1.TabIndex = 565
        Me.Button1.Text = "BEENDEN"
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.Magenta
        Me.Button9.Location = New System.Drawing.Point(832, 824)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(224, 32)
        Me.Button9.TabIndex = 569
        Me.Button9.Text = "DIAGRAMM"
        '
        'Label48
        '
        Me.Label48.Font = New System.Drawing.Font("Times New Roman", 12.15584!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.Magenta
        Me.Label48.Location = New System.Drawing.Point(8, 8)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(504, 40)
        Me.Label48.TabIndex = 561
        Me.Label48.Text = "Schotterspeicher mit Luftdurchstr�mung"
        '
        'Label47
        '
        Me.Label47.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(192, Byte))
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.Black
        Me.Label47.Location = New System.Drawing.Point(8, 48)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(320, 23)
        Me.Label47.TabIndex = 560
        Me.Label47.Text = "Autor: Prof. Dr.-Ing. habil. Bernd Gl�ck (V1/2007)"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.Magenta
        Me.Button5.Location = New System.Drawing.Point(352, 744)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(280, 56)
        Me.Button5.TabIndex = 566
        Me.Button5.Text = "AUFBEREITUNG DER EINGABEN + DATENSPEICHERUNG"
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(255, Byte))
        Me.GroupBox5.Controls.Add(Me.TextBox6)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Controls.Add(Me.Label78)
        Me.GroupBox5.Controls.Add(Me.Label79)
        Me.GroupBox5.Controls.Add(Me.TextBox170)
        Me.GroupBox5.Controls.Add(Me.Label26)
        Me.GroupBox5.Controls.Add(Me.Label27)
        Me.GroupBox5.Controls.Add(Me.TextBox31)
        Me.GroupBox5.Controls.Add(Me.Label23)
        Me.GroupBox5.Controls.Add(Me.Label25)
        Me.GroupBox5.Controls.Add(Me.TextBox30)
        Me.GroupBox5.Controls.Add(Me.Label20)
        Me.GroupBox5.Controls.Add(Me.Label22)
        Me.GroupBox5.Controls.Add(Me.TextBox10)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Controls.Add(Me.Label38)
        Me.GroupBox5.Controls.Add(Me.Label85)
        Me.GroupBox5.Controls.Add(Me.TextBox20)
        Me.GroupBox5.Controls.Add(Me.GroupBox6)
        Me.GroupBox5.Controls.Add(Me.TextBox13)
        Me.GroupBox5.Controls.Add(Me.TextBox12)
        Me.GroupBox5.Controls.Add(Me.TextBox11)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.Color.Black
        Me.GroupBox5.Location = New System.Drawing.Point(808, 288)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(424, 120)
        Me.GroupBox5.TabIndex = 578
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Speicherabmessungen"
        '
        'TextBox6
        '
        Me.TextBox6.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(192, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(312, 80)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(56, 27)
        Me.TextBox6.TabIndex = 538
        Me.TextBox6.Text = ""
        Me.TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(264, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 38)
        Me.Label1.TabIndex = 539
        Me.Label1.Text = "Anzahl der     L�ngenunterteilungen"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label78
        '
        Me.Label78.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.ForeColor = System.Drawing.Color.Black
        Me.Label78.Location = New System.Drawing.Point(440, 456)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(64, 22)
        Me.Label78.TabIndex = 535
        Me.Label78.Text = "�C"
        '
        'Label79
        '
        Me.Label79.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.ForeColor = System.Drawing.Color.Black
        Me.Label79.Location = New System.Drawing.Point(8, 456)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(368, 23)
        Me.Label79.TabIndex = 534
        Me.Label79.Text = "Bezugstemperatur f�r Speicherw�rmebestimmung:"
        '
        'TextBox170
        '
        Me.TextBox170.ForeColor = System.Drawing.Color.Black
        Me.TextBox170.Location = New System.Drawing.Point(376, 456)
        Me.TextBox170.Name = "TextBox170"
        Me.TextBox170.Size = New System.Drawing.Size(64, 27)
        Me.TextBox170.TabIndex = 536
        Me.TextBox170.Text = ""
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(255, Byte))
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(440, 418)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(64, 22)
        Me.Label26.TabIndex = 527
        Me.Label26.Text = "m�K/W"
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(255, Byte))
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(8, 418)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(368, 23)
        Me.Label27.TabIndex = 526
        Me.Label27.Text = "Rh hinterer W�rmeleitwiderstand mit 1/alpha_hinten:"
        '
        'TextBox31
        '
        Me.TextBox31.ForeColor = System.Drawing.Color.Black
        Me.TextBox31.Location = New System.Drawing.Point(376, 418)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(64, 27)
        Me.TextBox31.TabIndex = 528
        Me.TextBox31.Text = ""
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(255, Byte))
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(440, 388)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(64, 21)
        Me.Label23.TabIndex = 524
        Me.Label23.Text = "m�K/W"
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(255, Byte))
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(8, 388)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(368, 22)
        Me.Label25.TabIndex = 523
        Me.Label25.Text = "Rv vorderer W�rmeleitwiderstand mit 1/alpha_vorn:"
        '
        'TextBox30
        '
        Me.TextBox30.ForeColor = System.Drawing.Color.Black
        Me.TextBox30.Location = New System.Drawing.Point(376, 388)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(64, 27)
        Me.TextBox30.TabIndex = 525
        Me.TextBox30.Text = ""
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(255, Byte))
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(440, 357)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(64, 22)
        Me.Label20.TabIndex = 521
        Me.Label20.Text = "m�K/W"
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(255, Byte))
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(8, 357)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(368, 23)
        Me.Label22.TabIndex = 520
        Me.Label22.Text = "Ru unterer W�rmeleitwiderstand mit 1/alpha_unten:"
        '
        'TextBox10
        '
        Me.TextBox10.ForeColor = System.Drawing.Color.Black
        Me.TextBox10.Location = New System.Drawing.Point(376, 357)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(64, 27)
        Me.TextBox10.TabIndex = 522
        Me.TextBox10.Text = ""
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(8, 296)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(704, 23)
        Me.Label15.TabIndex = 512
        Me.Label15.Text = "^ Bei Phasenwandelmaterial Lambda- sowie c-Fl�ssigzustand, r und t-Wandel (Ober- " & _
        "und Unterwert) angeben!"
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(255, Byte))
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Black
        Me.Label38.Location = New System.Drawing.Point(440, 327)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(64, 23)
        Me.Label38.TabIndex = 471
        Me.Label38.Text = "m�K/W"
        '
        'Label85
        '
        Me.Label85.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(255, Byte))
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.ForeColor = System.Drawing.Color.Black
        Me.Label85.Location = New System.Drawing.Point(8, 327)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(368, 23)
        Me.Label85.TabIndex = 470
        Me.Label85.Text = "Ro oberer W�rmeleitwiderstand mit 1/alpha_oben:"
        '
        'TextBox20
        '
        Me.TextBox20.ForeColor = System.Drawing.Color.Black
        Me.TextBox20.Location = New System.Drawing.Point(376, 327)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(64, 27)
        Me.TextBox20.TabIndex = 500
        Me.TextBox20.Text = ""
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.Ivory
        Me.GroupBox6.Controls.Add(Me.Label31)
        Me.GroupBox6.Controls.Add(Me.Label33)
        Me.GroupBox6.Controls.Add(Me.TextBox36)
        Me.GroupBox6.Controls.Add(Me.Label32)
        Me.GroupBox6.Controls.Add(Me.Label30)
        Me.GroupBox6.Controls.Add(Me.TextBox35)
        Me.GroupBox6.Controls.Add(Me.Label36)
        Me.GroupBox6.Controls.Add(Me.TextBox38)
        Me.GroupBox6.Controls.Add(Me.Label35)
        Me.GroupBox6.Controls.Add(Me.TextBox37)
        Me.GroupBox6.Location = New System.Drawing.Point(512, 319)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(200, 160)
        Me.GroupBox6.TabIndex = 524
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Gitterdaten f�r x- und                            z-Achse:"
        '
        'Label31
        '
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(152, 114)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(40, 23)
        Me.Label31.TabIndex = 529
        Me.Label31.Text = "mm"
        '
        'Label33
        '
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Black
        Me.Label33.Location = New System.Drawing.Point(32, 114)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(64, 23)
        Me.Label33.TabIndex = 527
        Me.Label33.Text = "Dz "
        '
        'TextBox36
        '
        Me.TextBox36.ForeColor = System.Drawing.Color.Black
        Me.TextBox36.Location = New System.Drawing.Point(96, 106)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(56, 27)
        Me.TextBox36.TabIndex = 528
        Me.TextBox36.Text = ""
        '
        'Label32
        '
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(152, 46)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(40, 22)
        Me.Label32.TabIndex = 526
        Me.Label32.Text = "mm"
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(32, 46)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(64, 22)
        Me.Label30.TabIndex = 522
        Me.Label30.Text = "Dx "
        '
        'TextBox35
        '
        Me.TextBox35.ForeColor = System.Drawing.Color.Black
        Me.TextBox35.Location = New System.Drawing.Point(96, 38)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(56, 27)
        Me.TextBox35.TabIndex = 523
        Me.TextBox35.Text = ""
        '
        'Label36
        '
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Black
        Me.Label36.Location = New System.Drawing.Point(32, 68)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(56, 23)
        Me.Label36.TabIndex = 534
        Me.Label36.Text = "iSmax "
        '
        'TextBox38
        '
        Me.TextBox38.ForeColor = System.Drawing.Color.Black
        Me.TextBox38.Location = New System.Drawing.Point(96, 61)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(56, 27)
        Me.TextBox38.TabIndex = 535
        Me.TextBox38.Text = ""
        '
        'Label35
        '
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Black
        Me.Label35.Location = New System.Drawing.Point(32, 137)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(56, 23)
        Me.Label35.TabIndex = 536
        Me.Label35.Text = "kSmax"
        '
        'TextBox37
        '
        Me.TextBox37.ForeColor = System.Drawing.Color.Black
        Me.TextBox37.Location = New System.Drawing.Point(96, 129)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(56, 27)
        Me.TextBox37.TabIndex = 537
        Me.TextBox37.Text = ""
        '
        'TextBox13
        '
        Me.TextBox13.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(192, Byte))
        Me.TextBox13.Location = New System.Drawing.Point(16, 80)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(56, 27)
        Me.TextBox13.TabIndex = 532
        Me.TextBox13.Text = ""
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox12
        '
        Me.TextBox12.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(192, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(192, 80)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(56, 27)
        Me.TextBox12.TabIndex = 534
        Me.TextBox12.Text = ""
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox11
        '
        Me.TextBox11.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(192, Byte))
        Me.TextBox11.Location = New System.Drawing.Point(104, 80)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(56, 27)
        Me.TextBox11.TabIndex = 533
        Me.TextBox11.Text = ""
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(16, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 38)
        Me.Label4.TabIndex = 535
        Me.Label4.Text = "H�he                 m"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(96, 32)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 38)
        Me.Label3.TabIndex = 536
        Me.Label3.Text = "Breite                 m"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(184, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 38)
        Me.Label2.TabIndex = 537
        Me.Label2.Text = "L�nge              m"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label75
        '
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label75.Location = New System.Drawing.Point(480, 440)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(224, 38)
        Me.Label75.TabIndex = 572
        Me.Label75.Text = "1. STARTEN dr�cken und Pfad best�tigen bzw. neu eingeben!"
        '
        'Label72
        '
        Me.Label72.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label72.Location = New System.Drawing.Point(480, 592)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(216, 34)
        Me.Label72.TabIndex = 576
        Me.Label72.Text = "4. DATENSPEICHERUNG dr�cken!"
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(192, Byte))
        Me.GroupBox7.Controls.Add(Me.TextBox8)
        Me.GroupBox7.Controls.Add(Me.Label10)
        Me.GroupBox7.Controls.Add(Me.Label18)
        Me.GroupBox7.Controls.Add(Me.TextBox4)
        Me.GroupBox7.Controls.Add(Me.Label17)
        Me.GroupBox7.Controls.Add(Me.Label12)
        Me.GroupBox7.Controls.Add(Me.Label9)
        Me.GroupBox7.Controls.Add(Me.Label7)
        Me.GroupBox7.Controls.Add(Me.TextBox44)
        Me.GroupBox7.Controls.Add(Me.TextBox43)
        Me.GroupBox7.Controls.Add(Me.TextBox42)
        Me.GroupBox7.Controls.Add(Me.TextBox41)
        Me.GroupBox7.Controls.Add(Me.Label80)
        Me.GroupBox7.Controls.Add(Me.TextBox155)
        Me.GroupBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(8, 416)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(432, 312)
        Me.GroupBox7.TabIndex = 579
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Daten zum Simulationsablauf"
        '
        'TextBox8
        '
        Me.TextBox8.ForeColor = System.Drawing.Color.Green
        Me.TextBox8.Location = New System.Drawing.Point(16, 272)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(408, 27)
        Me.TextBox8.TabIndex = 645
        Me.TextBox8.Text = ""
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(16, 248)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(400, 23)
        Me.Label10.TabIndex = 644
        Me.Label10.Text = "Bei tStart =-273, Laden einer Temperaturverteilung:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(16, 176)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(328, 23)
        Me.Label18.TabIndex = 643
        Me.Label18.Text = "Ausgew�hlter Entwurfstag (ETagfix: 1 ... 20)"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox4
        '
        Me.TextBox4.ForeColor = System.Drawing.Color.Green
        Me.TextBox4.Location = New System.Drawing.Point(360, 176)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(64, 27)
        Me.TextBox4.TabIndex = 642
        Me.TextBox4.Text = ""
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(16, 136)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(328, 23)
        Me.Label17.TabIndex = 641
        Me.Label17.Text = "Luftvolumenstrom in m�/h (Maximalwert)"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(16, 216)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(328, 23)
        Me.Label12.TabIndex = 640
        Me.Label12.Text = "Starttemperatur in �C f�r den gesamten Speicher"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(16, 96)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(328, 23)
        Me.Label9.TabIndex = 639
        Me.Label9.Text = "Zeitschrittweite in s (ganzzahlig in 3600 teilbar)"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(16, 64)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(296, 23)
        Me.Label7.TabIndex = 638
        Me.Label7.Text = "Beginn der Simulation (Uhrzeit: 0 ... 23)"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox44
        '
        Me.TextBox44.ForeColor = System.Drawing.Color.Green
        Me.TextBox44.Location = New System.Drawing.Point(360, 216)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(64, 27)
        Me.TextBox44.TabIndex = 538
        Me.TextBox44.Text = ""
        Me.TextBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox43
        '
        Me.TextBox43.ForeColor = System.Drawing.Color.Green
        Me.TextBox43.Location = New System.Drawing.Point(360, 96)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(64, 27)
        Me.TextBox43.TabIndex = 537
        Me.TextBox43.Text = ""
        Me.TextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox42
        '
        Me.TextBox42.ForeColor = System.Drawing.Color.Green
        Me.TextBox42.Location = New System.Drawing.Point(360, 64)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(64, 27)
        Me.TextBox42.TabIndex = 536
        Me.TextBox42.Text = ""
        Me.TextBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox41
        '
        Me.TextBox41.ForeColor = System.Drawing.Color.Green
        Me.TextBox41.Location = New System.Drawing.Point(360, 32)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(64, 27)
        Me.TextBox41.TabIndex = 535
        Me.TextBox41.Text = ""
        Me.TextBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label80
        '
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.ForeColor = System.Drawing.Color.Black
        Me.Label80.Location = New System.Drawing.Point(16, 32)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(320, 23)
        Me.Label80.TabIndex = 531
        Me.Label80.Text = "Maximale Anzahl der Simulationsstunden in h"
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(808, 80)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(424, 208)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 577
        Me.PictureBox1.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(224, Byte), CType(192, Byte))
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.TextBox7)
        Me.GroupBox4.Controls.Add(Me.Label53)
        Me.GroupBox4.Controls.Add(Me.Label52)
        Me.GroupBox4.Controls.Add(Me.TextBox50)
        Me.GroupBox4.Controls.Add(Me.TextBox45)
        Me.GroupBox4.Controls.Add(Me.Label51)
        Me.GroupBox4.Controls.Add(Me.Label46)
        Me.GroupBox4.Controls.Add(Me.Label49)
        Me.GroupBox4.Controls.Add(Me.Label50)
        Me.GroupBox4.Controls.Add(Me.Label45)
        Me.GroupBox4.Controls.Add(Me.Label44)
        Me.GroupBox4.Controls.Add(Me.Label43)
        Me.GroupBox4.Controls.Add(Me.Label29)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.TextBox1)
        Me.GroupBox4.Controls.Add(Me.TextBox34)
        Me.GroupBox4.Controls.Add(Me.TextBox39)
        Me.GroupBox4.Controls.Add(Me.TextBox40)
        Me.GroupBox4.Controls.Add(Me.TextBox23)
        Me.GroupBox4.Controls.Add(Me.TextBox24)
        Me.GroupBox4.Controls.Add(Me.TextBox25)
        Me.GroupBox4.Controls.Add(Me.TextBox26)
        Me.GroupBox4.Controls.Add(Me.TextBox27)
        Me.GroupBox4.Controls.Add(Me.TextBox28)
        Me.GroupBox4.Controls.Add(Me.TextBox29)
        Me.GroupBox4.Controls.Add(Me.TextBox33)
        Me.GroupBox4.Controls.Add(Me.TextBox19)
        Me.GroupBox4.Controls.Add(Me.TextBox21)
        Me.GroupBox4.Controls.Add(Me.TextBox22)
        Me.GroupBox4.Controls.Add(Me.TextBox14)
        Me.GroupBox4.Controls.Add(Me.TextBox15)
        Me.GroupBox4.Controls.Add(Me.TextBox16)
        Me.GroupBox4.Controls.Add(Me.TextBox17)
        Me.GroupBox4.Controls.Add(Me.TextBox18)
        Me.GroupBox4.Controls.Add(Me.Label24)
        Me.GroupBox4.Controls.Add(Me.Label37)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.Label13)
        Me.GroupBox4.Controls.Add(Me.TextBox3)
        Me.GroupBox4.Controls.Add(Me.TextBox5)
        Me.GroupBox4.Controls.Add(Me.TextBox2)
        Me.GroupBox4.Controls.Add(Me.TextBox32)
        Me.GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.GroupBox4.Location = New System.Drawing.Point(8, 80)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(792, 328)
        Me.GroupBox4.TabIndex = 585
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Daten des Speichermaterials"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(472, 24)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(272, 40)
        Me.Label8.TabIndex = 577
        Me.Label8.Text = "Aquivalenter F�llk�rperdurchmesser           mm"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'TextBox7
        '
        Me.TextBox7.ForeColor = System.Drawing.Color.Black
        Me.TextBox7.Location = New System.Drawing.Point(584, 64)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(56, 27)
        Me.TextBox7.TabIndex = 576
        Me.TextBox7.Text = ""
        Me.TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label53
        '
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 5.798658!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.Black
        Me.Label53.Location = New System.Drawing.Point(624, 272)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(144, 48)
        Me.Label53.TabIndex = 575
        Me.Label53.Text = "Oberfl�che in cm� und Volumen in cm�"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label52
        '
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.Black
        Me.Label52.Location = New System.Drawing.Point(8, 288)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(272, 23)
        Me.Label52.TabIndex = 574
        Me.Label52.Text = "Oberfl�chen-Volumen-Korrelation"
        '
        'TextBox50
        '
        Me.TextBox50.ForeColor = System.Drawing.Color.Black
        Me.TextBox50.Location = New System.Drawing.Point(536, 272)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(56, 27)
        Me.TextBox50.TabIndex = 573
        Me.TextBox50.Text = ""
        Me.TextBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox45
        '
        Me.TextBox45.ForeColor = System.Drawing.Color.Black
        Me.TextBox45.Location = New System.Drawing.Point(392, 288)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(56, 27)
        Me.TextBox45.TabIndex = 572
        Me.TextBox45.Text = ""
        Me.TextBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label51
        '
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.Black
        Me.Label51.Location = New System.Drawing.Point(296, 288)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(304, 22)
        Me.Label51.TabIndex = 571
        Me.Label51.Text = "Oberfl�che =                  * Volumen"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label46
        '
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.Black
        Me.Label46.Location = New System.Drawing.Point(744, 160)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(24, 22)
        Me.Label46.TabIndex = 570
        Me.Label46.Text = "10 "
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label49
        '
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.Black
        Me.Label49.Location = New System.Drawing.Point(680, 160)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(24, 22)
        Me.Label49.TabIndex = 569
        Me.Label49.Text = "9 "
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label50
        '
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.Black
        Me.Label50.Location = New System.Drawing.Point(616, 160)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(24, 22)
        Me.Label50.TabIndex = 568
        Me.Label50.Text = "8 "
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label45
        '
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Black
        Me.Label45.Location = New System.Drawing.Point(552, 160)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(24, 22)
        Me.Label45.TabIndex = 567
        Me.Label45.Text = "7 "
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label44
        '
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Black
        Me.Label44.Location = New System.Drawing.Point(488, 160)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(24, 22)
        Me.Label44.TabIndex = 566
        Me.Label44.Text = "6 "
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label43
        '
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Black
        Me.Label43.Location = New System.Drawing.Point(424, 160)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(24, 22)
        Me.Label43.TabIndex = 565
        Me.Label43.Text = "5 "
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.Black
        Me.Label29.Location = New System.Drawing.Point(360, 160)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(24, 22)
        Me.Label29.TabIndex = 564
        Me.Label29.Text = "4 "
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(296, 160)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(24, 22)
        Me.Label21.TabIndex = 563
        Me.Label21.Text = "3 "
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(232, 160)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(24, 22)
        Me.Label19.TabIndex = 562
        Me.Label19.Text = "2 "
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(168, 160)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(24, 22)
        Me.Label11.TabIndex = 561
        Me.Label11.Text = "1 "
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox1
        '
        Me.TextBox1.ForeColor = System.Drawing.Color.Black
        Me.TextBox1.Location = New System.Drawing.Point(664, 216)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(56, 27)
        Me.TextBox1.TabIndex = 559
        Me.TextBox1.Text = ""
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox34
        '
        Me.TextBox34.ForeColor = System.Drawing.Color.Black
        Me.TextBox34.Location = New System.Drawing.Point(728, 216)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(56, 27)
        Me.TextBox34.TabIndex = 560
        Me.TextBox34.Text = ""
        Me.TextBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox39
        '
        Me.TextBox39.ForeColor = System.Drawing.Color.Black
        Me.TextBox39.Location = New System.Drawing.Point(664, 184)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(56, 27)
        Me.TextBox39.TabIndex = 557
        Me.TextBox39.Text = ""
        Me.TextBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox40
        '
        Me.TextBox40.ForeColor = System.Drawing.Color.Black
        Me.TextBox40.Location = New System.Drawing.Point(728, 184)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(56, 27)
        Me.TextBox40.TabIndex = 558
        Me.TextBox40.Text = ""
        Me.TextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox23
        '
        Me.TextBox23.ForeColor = System.Drawing.Color.Black
        Me.TextBox23.Location = New System.Drawing.Point(472, 216)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(56, 27)
        Me.TextBox23.TabIndex = 554
        Me.TextBox23.Text = ""
        Me.TextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox24
        '
        Me.TextBox24.ForeColor = System.Drawing.Color.Black
        Me.TextBox24.Location = New System.Drawing.Point(536, 216)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(56, 27)
        Me.TextBox24.TabIndex = 555
        Me.TextBox24.Text = ""
        Me.TextBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox25
        '
        Me.TextBox25.ForeColor = System.Drawing.Color.Black
        Me.TextBox25.Location = New System.Drawing.Point(600, 216)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(56, 27)
        Me.TextBox25.TabIndex = 556
        Me.TextBox25.Text = ""
        Me.TextBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox26
        '
        Me.TextBox26.ForeColor = System.Drawing.Color.Black
        Me.TextBox26.Location = New System.Drawing.Point(216, 216)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(56, 27)
        Me.TextBox26.TabIndex = 550
        Me.TextBox26.Text = ""
        Me.TextBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox27
        '
        Me.TextBox27.ForeColor = System.Drawing.Color.Black
        Me.TextBox27.Location = New System.Drawing.Point(280, 216)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(56, 27)
        Me.TextBox27.TabIndex = 551
        Me.TextBox27.Text = ""
        Me.TextBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox28
        '
        Me.TextBox28.ForeColor = System.Drawing.Color.Black
        Me.TextBox28.Location = New System.Drawing.Point(344, 216)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(56, 27)
        Me.TextBox28.TabIndex = 552
        Me.TextBox28.Text = ""
        Me.TextBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox29
        '
        Me.TextBox29.ForeColor = System.Drawing.Color.Black
        Me.TextBox29.Location = New System.Drawing.Point(152, 216)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(56, 27)
        Me.TextBox29.TabIndex = 549
        Me.TextBox29.Text = ""
        Me.TextBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox33
        '
        Me.TextBox33.ForeColor = System.Drawing.Color.Black
        Me.TextBox33.Location = New System.Drawing.Point(408, 216)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(56, 27)
        Me.TextBox33.TabIndex = 553
        Me.TextBox33.Text = ""
        Me.TextBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox19
        '
        Me.TextBox19.ForeColor = System.Drawing.Color.Black
        Me.TextBox19.Location = New System.Drawing.Point(472, 184)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(56, 27)
        Me.TextBox19.TabIndex = 546
        Me.TextBox19.Text = ""
        Me.TextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox21
        '
        Me.TextBox21.ForeColor = System.Drawing.Color.Black
        Me.TextBox21.Location = New System.Drawing.Point(536, 184)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(56, 27)
        Me.TextBox21.TabIndex = 547
        Me.TextBox21.Text = ""
        Me.TextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox22
        '
        Me.TextBox22.ForeColor = System.Drawing.Color.Black
        Me.TextBox22.Location = New System.Drawing.Point(600, 184)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(56, 27)
        Me.TextBox22.TabIndex = 548
        Me.TextBox22.Text = ""
        Me.TextBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox14
        '
        Me.TextBox14.ForeColor = System.Drawing.Color.Black
        Me.TextBox14.Location = New System.Drawing.Point(216, 184)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(56, 27)
        Me.TextBox14.TabIndex = 540
        Me.TextBox14.Text = ""
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox15
        '
        Me.TextBox15.ForeColor = System.Drawing.Color.Black
        Me.TextBox15.Location = New System.Drawing.Point(280, 184)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(56, 27)
        Me.TextBox15.TabIndex = 541
        Me.TextBox15.Text = ""
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox16
        '
        Me.TextBox16.ForeColor = System.Drawing.Color.Black
        Me.TextBox16.Location = New System.Drawing.Point(344, 184)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(56, 27)
        Me.TextBox16.TabIndex = 542
        Me.TextBox16.Text = ""
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox17
        '
        Me.TextBox17.ForeColor = System.Drawing.Color.Black
        Me.TextBox17.Location = New System.Drawing.Point(152, 184)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(56, 27)
        Me.TextBox17.TabIndex = 539
        Me.TextBox17.Text = ""
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox18
        '
        Me.TextBox18.ForeColor = System.Drawing.Color.Black
        Me.TextBox18.Location = New System.Drawing.Point(408, 184)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(56, 27)
        Me.TextBox18.TabIndex = 543
        Me.TextBox18.Text = ""
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(8, 216)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(88, 22)
        Me.Label24.TabIndex = 545
        Me.Label24.Text = "Anteil in %"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Black
        Me.Label37.Location = New System.Drawing.Point(8, 184)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(128, 23)
        Me.Label37.TabIndex = 544
        Me.Label37.Text = "Volumen in cm�"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(8, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(400, 23)
        Me.Label6.TabIndex = 538
        Me.Label6.Text = "Ausgew�hlte Partikelgr��en und ihre Verteilung"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(296, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 40)
        Me.Label5.TabIndex = 537
        Me.Label5.Text = "Hohlraumanteil        %"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(192, 24)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(64, 38)
        Me.Label16.TabIndex = 534
        Me.Label16.Text = "c               J/(kg K)"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(112, 24)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 38)
        Me.Label14.TabIndex = 533
        Me.Label14.Text = "Lambda                 W/(m K)"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(48, 24)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(64, 38)
        Me.Label13.TabIndex = 532
        Me.Label13.Text = "Rho                 kg/m�"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'TextBox3
        '
        Me.TextBox3.ForeColor = System.Drawing.Color.Black
        Me.TextBox3.Location = New System.Drawing.Point(120, 64)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(56, 27)
        Me.TextBox3.TabIndex = 484
        Me.TextBox3.Text = ""
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox5
        '
        Me.TextBox5.ForeColor = System.Drawing.Color.Black
        Me.TextBox5.Location = New System.Drawing.Point(192, 64)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(56, 27)
        Me.TextBox5.TabIndex = 486
        Me.TextBox5.Text = ""
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox2
        '
        Me.TextBox2.ForeColor = System.Drawing.Color.Black
        Me.TextBox2.Location = New System.Drawing.Point(48, 64)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(56, 27)
        Me.TextBox2.TabIndex = 483
        Me.TextBox2.Text = ""
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox32
        '
        Me.TextBox32.ForeColor = System.Drawing.Color.Black
        Me.TextBox32.Location = New System.Drawing.Point(336, 64)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(56, 27)
        Me.TextBox32.TabIndex = 531
        Me.TextBox32.Text = ""
        Me.TextBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.Blue
        Me.Button4.Location = New System.Drawing.Point(56, 272)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(416, 32)
        Me.Button4.TabIndex = 586
        Me.Button4.Text = "Diagrammanzeige nach erfolgter Simulation"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.GroupBox1.Controls.Add(Me.Label34)
        Me.GroupBox1.Controls.Add(Me.Label56)
        Me.GroupBox1.Controls.Add(Me.Label40)
        Me.GroupBox1.Controls.Add(Me.Label55)
        Me.GroupBox1.Controls.Add(Me.Label41)
        Me.GroupBox1.Controls.Add(Me.TextBox9)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.Label39)
        Me.GroupBox1.Controls.Add(Me.Label42)
        Me.GroupBox1.Controls.Add(Me.TextBox51)
        Me.GroupBox1.Controls.Add(Me.Label54)
        Me.GroupBox1.Controls.Add(Me.TextBox52)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(736, 416)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(496, 312)
        Me.GroupBox1.TabIndex = 646
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Spezielle Untersuchungen zum Zustand l�ngs des Speichers"
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Black
        Me.Label34.Location = New System.Drawing.Point(170, 168)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(288, 32)
        Me.Label34.TabIndex = 651
        Me.Label34.Text = "Temperatur an der Partikeloberfl�che                        t(s, p, i=1, j=jmax, " & _
        "k=1)"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label56
        '
        Me.Label56.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.ForeColor = System.Drawing.Color.Black
        Me.Label56.Location = New System.Drawing.Point(168, 144)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(320, 23)
        Me.Label56.TabIndex = 650
        Me.Label56.Text = "Temperatur in Partikelmitte t(s, p, i=1, j=1, k=1)"
        Me.Label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label40
        '
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Black
        Me.Label40.Location = New System.Drawing.Point(16, 144)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(144, 23)
        Me.Label40.TabIndex = 648
        Me.Label40.Text = "Gespeichert werden: "
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label55
        '
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.ForeColor = System.Drawing.Color.Black
        Me.Label55.Location = New System.Drawing.Point(168, 88)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(320, 23)
        Me.Label55.TabIndex = 647
        Me.Label55.Text = "Abs. Luftfeuchte f�r alle Speicherabschnitte s"
        Me.Label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label41
        '
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Black
        Me.Label41.Location = New System.Drawing.Point(168, 64)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(320, 23)
        Me.Label41.TabIndex = 646
        Me.Label41.Text = "Lufttemperatur f�r alle Speicherabschnitte s"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox9
        '
        Me.TextBox9.ForeColor = System.Drawing.Color.Blue
        Me.TextBox9.Location = New System.Drawing.Point(16, 232)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(472, 27)
        Me.TextBox9.TabIndex = 645
        Me.TextBox9.Text = ""
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(16, 208)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(288, 23)
        Me.Label28.TabIndex = 644
        Me.Label28.Text = "Speicherung der Ergebnisse in der Datei:"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label39
        '
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Black
        Me.Label39.Location = New System.Drawing.Point(16, 112)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(424, 24)
        Me.Label39.TabIndex = 641
        Me.Label39.Text = "Spezielle Betrachtung des Partikels (Eingabewert p = 1 ... pmax)"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label42
        '
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(16, 64)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(144, 23)
        Me.Label42.TabIndex = 638
        Me.Label42.Text = "Gespeichert werden: "
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox51
        '
        Me.TextBox51.ForeColor = System.Drawing.Color.Blue
        Me.TextBox51.Location = New System.Drawing.Point(440, 32)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(48, 27)
        Me.TextBox51.TabIndex = 535
        Me.TextBox51.Text = ""
        Me.TextBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label54
        '
        Me.Label54.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.ForeColor = System.Drawing.Color.Black
        Me.Label54.Location = New System.Drawing.Point(16, 32)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(376, 23)
        Me.Label54.TabIndex = 531
        Me.Label54.Text = "Zustand am Ende der Betriebsstunde (Eingabewert > 0)"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox52
        '
        Me.TextBox52.ForeColor = System.Drawing.Color.Blue
        Me.TextBox52.Location = New System.Drawing.Point(440, 112)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(48, 27)
        Me.TextBox52.TabIndex = 563
        Me.TextBox52.Text = ""
        Me.TextBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 20)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.ClientSize = New System.Drawing.Size(1254, 859)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.TextBox131)
        Me.Controls.Add(Me.TextBox130)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Label71)
        Me.Controls.Add(Me.Label73)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label69)
        Me.Controls.Add(Me.Label74)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Label48)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.Label72)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Hauptprogramm"
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim message, title, defaultValue As String
        StartOK = 0
        'Programm starten
        'Felder leeren
        TextBox130.Text = ""
        TextBox131.Text = ""
        message = "Bitte den Pfad mit Ordner eingeben!                                 Nicht die Datei benennen!"
        title = "Wichtige Eingabe:"
        If Objektbezeichnung <> "" Then
            defaultValue = Objektbezeichnung
        Else
            defaultValue = "F:\SD\FE_WHZ\Schotter\Beispiel_1\"
        End If
        Objektbezeichnung = InputBox(message, title, defaultValue, 600, 600)
        TextBox131.Text = Objektbezeichnung
        If Objektbezeichnung = "" Then
            TextBox131.Text = "Pfadangabe und Ordner fehlen!"
            GoTo Label_End
        End If
        Call NULLEINTRAG()
        StartOK = 1
Label_End:
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'Vorhandene Datei laden
        TextBox130.Text = ""
        If StartOK = 0 Then TextBox130.Text = "Bitte erst STARTEN!" : GoTo Label3_End
        Call EINGABELADUNG1()
        Call EINTRAG1()
Label3_End:
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        'Aufbereitung der Eingabewerte
        TextBox130.Text = ""
        If StartOK = 0 Then TextBox130.Text = "Bitte erst STARTEN!" : GoTo Label5_End
        Call MASKELESEN()
        'Eingabenkontrolle
        ooo = ""
        If rho = 0 Then ooo = "Rho fehlt!"
        If lam = 0 Then ooo = "Lambda fehlt!"
        If c = 0 Then ooo = "c fehlt!"
        If PSI = 0 Then ooo = "Hohlraumanteil fehlt!"
        For p = 1 To 10
            If V(1) <= 0 Or V(2) <= 0 Or V(3) <= 0 Or V(4) <= 0 Then ooo = "Weniger als 4 Partikel!"
        Next p
        Sum = 0
        For p = 1 To 10
            Sum = Sum + Anteil(p)
        Next p
        If Sum < 100 Or Sum > 100 Then ooo = "Anteile falsch!"
        If Fak = 0 Then ooo = "Korrelation falsch!"
        If Exp = 0 Then ooo = "Korrelation falsch!"
        If Hoehe <= 0 Then ooo = "H�he falsch!"
        If Breite <= 0 Then ooo = "Breite falsch!"
        If Laenge <= 0 Then ooo = "L�nge falsch!"
        If smax <= 10 Then ooo = "Speicherunterteilung ungen�gend!"
        If BSmax < 1 Then ooo = "Simulationsstunden falsch!"
        If Uhrbeginn >= 24 Then ooo = "Simulationsbeginn falsch!"
        If Dtau < 1 Then ooo = "Zeitschrittweite falsch!"
        If Vh <= 0 Then ooo = "Volumenstrom falsch!"
        If ETagfix > 20 Then ooo = "Entwurfstag falsch!"
        If dK = 0 Then ooo = "F�llk�rperdurchmesser fehlt!"
        If tStart = -273 And Speicherfeld = "" Then ooo = "Datei f�r Temperaturverteilung benennen!"
        If ooo <> "" Then TextBox130.Text = ooo : GoTo Label5_End
        If tStart > -273 Then TextBox8.Text = ""
        'Berechnung der Basiswerte
        Call Berechnung_Basis()
        'Datenspeicherung
        Call EINGABESPEICHERUNG1()
Label5_End:
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        'Zeitverlauf der w�rmetechnischen Randbedingungen
        TextBox130.Text = ""
        If StartOK = 0 Then TextBox130.Text = "Bitte erst STARTEN!" : GoTo Label10_End
        Dim f As New Form2
        f.TextBox14.Text = Objektbezeichnung + "ZVerlauf.dat"
        f.Objektbezeichnung = Objektbezeichnung
        f.Show()
Label10_End:
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        'Druck der Eingabedaten
        TextBox130.Text = ""
        If StartOK = 0 Then TextBox130.Text = "Bitte erst STARTEN!" : GoTo Label7_End
        Call EINGABELADUNG1()
        Call EINTRAG1()
        Call Druck_Eingabe()
Label7_End:
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        'Druck der Ergebnisse
        TextBox130.Text = ""
        If StartOK = 0 Then TextBox130.Text = "Bitte erst STARTEN!" : GoTo Label8_End
        Call EINGABELADUNG1()
        Call EINTRAG1()
        Call ERGEBNISLADUNG()
        Call Druck_Ergebnis()
Label8_End:
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        'Diagrammdarstellung
        TextBox130.Text = ""
        If StartOK = 0 Then TextBox130.Text = "Bitte erst STARTEN!" : GoTo Label9_End
        Dim f As New Form4
        f.TextBox14.Text = Objektbezeichnung + "ZVerlauf.dat + Ergebnis.dat"
        f.Objektbezeichnung = Objektbezeichnung
        f.Show()
Label9_End:
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        'Berechnung
        TextBox130.Text = ""
        If StartOK = 0 Then TextBox130.Text = "Bitte erst STARTEN!" : GoTo Label6_End
        ooo = ""
        Call EINGABELADUNG1()
        Call EINGABELADUNG2()
        Call Berechnung_Instat()
        If ooo = "" Then
        Else
            TextBox130.Text = ooo
            GoTo Label6_End
        End If
        Call ERGEBNISSPEICHERUNG()
Label6_End:
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        'Diagrammdarstellung der Zustandsverl�ufe l�ngs des Speichers
        TextBox130.Text = ""
        If StartOK = 0 Then TextBox130.Text = "Bitte erst STARTEN!" : GoTo Label7_End
        Dim f As New Form5
        f.TextBox14.Text = Objektbezeichnung + "Speicherverlauf.dat"
        f.Objektbezeichnung = Objektbezeichnung
        f.Show()
Label7_End:
    End Sub

    Sub Berechnung_Basis()
        'Nullsetzen der zu berechnenden Partikelgr��en
        For p = 1 To 10
            a1(p) = 0
            b1(p) = 0
            a2(p) = 0
            b2(p) = 0
            a(p) = 0
            b(p) = 0
            O(p) = 0
            jmax(p) = 0
            kmax(p) = 0
            imax(p) = 0
            Dx(p) = 0
            Dy(p) = 0
            jmax1(p) = 0
            kmax1(p) = 0
            imax1(p) = 0
            Dx1(p) = 0
            Dy1(p) = 0
            jmax2(p) = 0
            kmax2(p) = 0
            imax2(p) = 0
            Dx2(p) = 0
            Dy2(p) = 0
            VTyp(p) = 0
            ZP(p) = 0
            DtauPartikel(p) = 0
            DtauPartikel1(p) = 0
            DtauPartikel2(p) = 0
        Next p

        'Temperaturleitf�higkeit
        aFaehigkeit = lam / rho / c

        'Abmessungen eines Ersatzquaders a(p) * a(p) * b(p) f�r jeden ausgew�hlten Partikel p bestimmen
        'Alle Abmessungen in cm, Volumina in cm� und Oberfl�chen in cm� 
        For p = 1 To 10
            If V(p) > 0 Then
                O(p) = Fak * V(p) ^ Exp
                'L�sen einer kubischen Gleichung mittels regula falsi 
                Rest = 0
                y1 = 0
                For x = 0.1 To 100 Step 0.1
                    Rest0 = Rest
                    Rest = 2 * x * x + 4 * V(p) / x - O(p)
                    If Rest = 0 Then
                        x1 = x
                        y1 = V(p) / x1 / x1
                        If y1 > 0 Then
                            If a1(p) = 0 Then
                                'L�sung1
                                a1(p) = x1
                                b1(p) = y1
                                Rest = 0
                            Else
                                'L�sung2
                                a2(p) = x1
                                b2(p) = y1
                                GoTo Loesung
                            End If
                        End If
                    ElseIf (Rest0 / Rest) < 0 Then
                        x1 = x - 0.1 * Rest / (Rest - Rest0)
                        y1 = V(p) / x1 / x1
                        If y1 > 0 Then
                            If a1(p) = 0 Then
                                'L�sung1
                                a1(p) = x1
                                b1(p) = y1
                                Rest = 0
                            Else
                                'L�sung2
                                a2(p) = x1
                                b2(p) = y1
                                GoTo Loesung
                            End If
                        End If
                    End If
                Next x
Loesung:
                pmax = p
            End If
        Next p

        'Begrenzungen der Simulationsgebiete jmax(p) und imax(p) und Abmessungen der Volumenelemente Dx(p) und Dy(p) 
        For p = 1 To pmax
            'L�sungsgegen�berstellung 
            'Variante 1
            If a1(p) > 0 Then
                x = a1(p) / 2
                y = b1(p) / 2
                'Begrenzungen
                jmax1(p) = Int(x)
                If jmax1(p) < 1 Then jmax1(p) = 1
                imax1(p) = Int(y)
                If imax1(p) < 1 Then imax1(p) = 1
                'Abmessungen in m
                a1(p) = a1(p) / 100
                b1(p) = b1(p) / 100
                Dx1(p) = x / jmax1(p) / 100
                Dy1(p) = y / imax1(p) / 100
                DtauPartikel1(p) = (2 * aFaehigkeit * (2 / (Dx1(p) ^ 2) + 1 / (Dy1(p) ^ 2))) ^ -1
            End If
            'Variante 2
            If a2(p) > 0 Then
                x = a2(p) / 2
                y = b2(p) / 2
                'Begrenzungen
                jmax2(p) = Int(x)
                If jmax2(p) < 1 Then jmax2(p) = 1
                imax2(p) = Int(y)
                If imax2(p) < 1 Then imax2(p) = 1
                'Abmessungen in m
                a2(p) = a2(p) / 100
                b2(p) = b2(p) / 100
                Dx2(p) = x / jmax2(p) / 100
                Dy2(p) = y / imax2(p) / 100
                DtauPartikel2(p) = (2 * aFaehigkeit * (2 / (Dx2(p) ^ 2) + 1 / (Dy2(p) ^ 2))) ^ -1
            End If
            'L�sungsauswahl
            If DtauPartikel1(p) > DtauPartikel2(p) Then
                DtauPartikel(p) = DtauPartikel1(p)
                jmax(p) = jmax1(p)
                kmax(p) = jmax1(p)
                imax(p) = imax1(p)
                Dx(p) = Dx1(p)
                Dy(p) = Dy1(p)
                a(p) = a1(p)
                b(p) = b1(p)
            Else
                DtauPartikel(p) = DtauPartikel2(p)
                jmax(p) = jmax2(p)
                kmax(p) = jmax2(p)
                imax(p) = imax2(p)
                Dx(p) = Dx2(p)
                Dy(p) = Dy2(p)
                a(p) = a2(p)
                b(p) = b2(p)
            End If
        Next p

        'Volumen des Feststoffes (Volumen aller Partikel im Speicher)
        Vfest = (1 - PSI / 100) * Hoehe * Breite * Laenge

        'Masse des Schotters
        mfest = Vfest * rho

        'Gesamtvolumen VTyp(p) der Partikeltypen p und Partikelzahlen ZP(p) pro Partikeltyp p
        For p = 1 To pmax
            VTyp(p) = Anteil(p) / 100 * Vfest
            ZP(p) = VTyp(p) / V(p) * 1000000
        Next p

        'Anteile der Partikeloberfl�chen Oanteil(p) an der Gesamtoberfl�che des Schottermaterials
        Sum = 0
        For p = 1 To pmax
            Sum = Sum + O(p) * ZP(p)
        Next p
        For p = 1 To pmax
            Oanteil(p) = O(p) * ZP(p) / Sum
        Next p

        'Luftvolumen im Schotter
        VLuft = PSI / 100 * Hoehe * Breite * Laenge

        'Minimale Zeitschrittweite bezogen auf den approximierten Partikeltyp
        Dtaumax = 1000000
        For p = 1 To pmax
            If DtauPartikel(p) < Dtaumax Then Dtaumax = DtauPartikel(p)
        Next p
        Dtaumax = Int(Dtaumax)

        'Ermittlung des Zeitschrittes, der durch 3600 s ganzzahlig teilbar ist
        DtauVorschlag = Dtaumax
        Zahl = -1
        Do Until 3600 / DtauVorschlag = Int(3600 / DtauVorschlag)
            Zahl = Zahl + 1
            DtauVorschlag = DtauVorschlag - Zahl
        Loop
    End Sub

    Sub Berechnung_Instat()
        'Werte f�r Konstante
        pL = 100000                  'Luftdruck
        FF = Breite * Hoehe * PSI / 100 'Freie Querschnittsfl�che

        '�berpr�fung von Dtau < DtauVorschlag 
        ooo = ""
        If Dtau > DtauVorschlag Then
            ooo = "Dtau ist zu gro�!"
            GoTo Label_Inst
        End If
        If Int(3600 / Dtau) <> 3600 / Dtau Then
            ooo = "Dtau nicht ganzzahlig in 3600!"
            GoTo Label_Inst
        End If

        'Zusammenstellung der Elementdaten (Fl�chen * Dtau, Volumen, Speicherkapazit�t, Widerst�nde, Leitwerte)
        For p = 1 To pmax
            AEi(p) = Dx(p) * Dx(p) * Dtau
            AE(p) = Dx(p) * Dy(p) * Dtau
            VE(p) = Dx(p) * Dx(p) * Dy(p)
            CE(p) = VE(p) * rho * c
            REi(p) = Dy(p) / 2 / lam
            RE(p) = Dx(p) / 2 / lam
            LEi(p) = lam / Dy(p) * AEi(p)
            LE(p) = lam / Dx(p) * AE(p)
        Next p

        'F�llung mit Starttemperatur
        If tStart > -273 Then
            For s = 1 To smax
                For p = 1 To pmax
                    For i = 1 To imax(p)
                        For j = 1 To jmax(p)
                            For k = 1 To kmax(p)
                                t(s, p, i, j, k) = tStart
                            Next k
                        Next j
                    Next i
                Next p
            Next s
        Else
            FileOpen(1, Speicherfeld, OpenMode.Input)
            For s = 1 To smax
                For p = 1 To pmax
                    For i = 1 To imax(p)
                        For j = 1 To jmax(p)
                            For k = 1 To kmax(p)
                                Input(1, t(s, p, i, j, k))
                            Next k
                        Next j
                    Next i
                Next p
            Next s
            FileClose(1)
        End If
       
        'Nullsetzen der st�ndlichen Speicherwerte zu Beginn der Berechnung
        For BS = 0 To BSmax
            Tagesstunde(BS) = 0
            RichtungBS(BS) = 0
            QSpeicher(BS) = 0
            QMedium(BS) = 0
            tLein(BS) = 0
            tLaus(BS) = 0
            xLein(BS) = 0
            xLaus(BS) = 0
            phiLein(BS) = 0
            phiLaus(BS) = 0
            Kondensatmenge(BS) = 0
        Next BS

        'Abarbeitung der Zeitschritte
        Zeitmax = BSmax / Dtau * 3600%
        Intervallmax = 3600 / Dtau
        Intervall = 0
        Tagesstunde(0) = Uhrbeginn

        'Beginn der Zeitschleife
        For Zeit = 0 To Zeitmax
            'Simulationsstunde tau als Dezimale
            tau = Zeit * Dtau / 3600%

            'Ermittlung der Uhrzeit (tauUhr Tagesstunde als Dezimale)
            tauUhr = tau + Uhrbeginn
            Do Until tauUhr < 24
                tauUhr = tauUhr - 24
            Loop

            GanzeStunde = 0
            'Anzeige ganzer Simulationsstunde
            If tau = Int(tau) Then
                'Steuerung der Ausschrift zum Berechnungsstand
                GanzeStunde = 1
                'Ermittlung der Betriebsstunde
                BS = Int(tau + 1)
                'Grundlage f�r die Steuerung des Berechnungsablaufes
                Stunde = Int(tauUhr)
                Stunde1 = Stunde + 1
                Richtung = R(ETagfix, Stunde)
                If BS = BSmax + 1 Then GanzeStunde = 10
                Call Zeitmitteilung()
                'Intervallz�hlung
                Intervall = 0
            End If
            Intervall = Intervall + 1
            If Richtung = 0 Then
            Else
                Rest = tauUhr - Stunde
                'INTERPOLATION DER ZEITVERL�UFE (Temperaturvorgaben)zwischen den Stunden-St�tzstellen
                'Eingaben gelten stets zur vollen Stunde, Zwischenwerte werden interpoliert
                'Aktuelle Lufttemperatur tLa am Eintritt
                tx = tLETag(ETagfix, Stunde)
                tx1 = tLETag(ETagfix, Stunde1)
                tLa = tx + Rest * (tx1 - tx)

                'Aktuelle Luftfeuchte xLa
                xx = xLETag(ETagfix, Stunde)
                xx1 = xLETag(ETagfix, Stunde1)
                xLa = (xx + Rest * (xx1 - xx)) / 1000

                'Aktueller Luftmassestrom mL
                tstern = tLa
                xstern = xLa
                Call ZUSTAND()
                hein = hstern
                phiein = phistern
                vein = (xLa + 0.6222) * 461.4 * (tLa + 273) / pL
                mLmax = Vh / 3600 / vein
                'Luftmasse durch den Speicher 
                mL = mLmax * VLanteil(ETagfix, Stunde)
            End If

            'BERECHNUNG IN RICHTUNG DES LUFTDURCHGANGES 
            'Abarbeitung der Schichten s = 1 bis s = smax oder s = smax bis s = 1)
            If Richtung = 1 Then
                sBeginn = 1
                sEnde = smax
                sStep = 1
                tL(1) = tLa
                xL(1) = xLa
                hL(1) = hein
                phiL(1) = phiein
            ElseIf Richtung = -1 Then
                sBeginn = smax
                sEnde = 1
                sStep = -1
                tL(smax) = tLa
                xL(smax) = xLa
                hL(smax) = hein
                phiL(smax) = phiein
            Else
                sBeginn = 1
                sEnde = smax
                sStep = 1
                tL(1) = -273
                xL(1) = 0
            End If

            If tau = 0 Then
                'W�rme im Speicher beim Simulationsstart
                'QSpeicher(BS) Bezug auf aktuelle Lufteintrittstemperatur
                Sum = 0
                For s = 1 To smax
                    For p = 1 To pmax
                        For i = 1 To imax(p)
                            For j = 1 To jmax(p)
                                For k = 1 To kmax(p)
                                    Sum = Sum + CE(p) * (t(s, p, i, j, k) - tLa) * 8 * ZP(p) / smax
                                Next k
                            Next j
                        Next i
                    Next p
                Next s
                'Speicherung der Startwerte
                QSpeicher(0) = Sum
                Tagesstunde(0) = tauUhr
                RichtungBS(0) = Richtung
                If Richtung = 1 Then
                    tLein(0) = tL(1)
                    xLein(0) = xL(1)
                    phiLein(0) = phiL(1)
                    tLaus(0) = -273
                    xLaus(0) = -273
                    phiLaus(0) = -273
                ElseIf Richtung = -1 Then
                    tLein(0) = tL(smax)
                    xLein(0) = xL(smax)
                    phiLein(0) = phiL(smax)
                    tLaus(0) = -273
                    xLaus(0) = -273
                    phiLaus(0) = -273
                Else
                    tLein(0) = -273
                    xLein(0) = -273
                    phiLein(0) = -273
                    tLaus(0) = -273
                    xLaus(0) = -273
                    phiLaus(0) = -273
                End If
            End If

            'Betrachtung der Speicherabschnitte
            For s = sBeginn To sEnde Step sStep
                'Stoffwerte der Luft
                tx = tL(s)
                xx = xL(s)
                If Richtung = 0 Then
                Else
                    rhoM = rhoL(tx, xx)
                    cM = cL(tx, xx)
                    nyM = nyL(tx, xx, rhoM)
                    lamM = lamL(tx, xx)
                    PrM = nyM * rhoM * cM / lamM
                End If

                'Berechnung des W�rme�bergangskoeffizienten
                If Richtung = 0 Then
                Else
                    w = mL / rhoM / FF
                    ReZ = w * dK / nyM
                    NuZ = 2 + (0.441 * ReZ * PrM ^ 0.667 + ReZ ^ 1.6 * PrM ^ 2 / (27.027 + 66.027 * ReZ ^ -0.1 * (PrM ^ 0.667 - 1)) ^ 2) ^ 0.5
                    NuZ = NuZ * 1.6
                    alphaL = NuZ * lamM / dK
                End If

                'Berechnung der W�rmestr�me in und aus den Volumenelementen
                QL(s) = 0
                For p = 1 To pmax
                    For i = 1 To imax(p)
                        For j = 1 To jmax(p)
                            For k = 1 To j
                                tE = t(s, p, i, j, k)
                                QE = 0
                                If i = 1 Then
                                    Qiein = 0
                                Else
                                    Qiein = LEi(p) * (t(s, p, i - 1, j, k) - tE)
                                End If
                                If i = imax(p) Then
                                    If Richtung = 0 Then Qiaus = 0 Else Qiaus = (REi(p) + 1 / alphaL) ^ -1 * AEi(p) * (tE - tL(s))
                                    If j = k Then
                                        QL(s) = QL(s) + Qiaus * 8 * ZP(p) / smax
                                    Else
                                        QL(s) = QL(s) + Qiaus * 16 * ZP(p) / smax
                                    End If
                                Else
                                    Qiaus = LEi(p) * (tE - t(s, p, i + 1, j, k))
                                End If

                                If j = 1 Then
                                    Qjein = 0
                                Else
                                    Qjein = LE(p) * (t(s, p, i, j - 1, k) - tE)
                                End If
                                If j = jmax(p) Then
                                    If Richtung = 0 Then Qjaus = 0 Else Qjaus = (RE(p) + 1 / alphaL) ^ -1 * AE(p) * (tE - tL(s))
                                    QL(s) = QL(s) + Qjaus * 16 * ZP(p) / smax
                                Else
                                    Qjaus = LE(p) * (tE - t(s, p, i, j + 1, k))
                                End If

                                If k = 1 Then
                                    Qkein = 0
                                Else
                                    Qkein = LE(p) * (t(s, p, i, j, k - 1) - tE)
                                End If
                                If k = kmax(p) Then
                                    If Richtung = 0 Then Qkaus = 0 Else Qkaus = (RE(p) + 1 / alphaL) ^ -1 * AE(p) * (tE - tL(s))
                                Else
                                    Qkaus = LE(p) * (tE - t(s, p, i, j, k + 1))
                                End If

                                'W�rmezunahme im Element
                                QE = Qiein + Qjein + Qkein - Qiaus - Qjaus - Qkaus

                                'Neuer thermischer Zustand durch Elementw�rme
                                tn(s, p, i, j, k) = tE + QE / CE(p)
                            Next k
                        Next j
                        'Spiegelung an der 45�-Symmetrielinie im Quadratquerschnitt
                        For j = 1 To jmax(p)
                            For k = (j + 1) To kmax(p)
                                tn(s, p, i, j, k) = tn(s, p, i, k, j)
                            Next k
                        Next j
                    Next i
                Next p

                'Angen�herte mittlere Partikeloberfl�chentemperatur im Abschnitt s 
                tmittel = 0
                For p = 1 To pmax
                    tmittel = tmittel + t(s, p, 1, jmax(p), 1) * Oanteil(p)
                Next p

                'Temperatur des Luftvolumenstromes am Ende des Abschnittes
                If Richtung = 1 Then
                    hL(s + 1) = hL(s) + QL(s) / Dtau / mL / 1000
                    hstern = hL(s + 1)
                    xstern = xL(s)
                    Call ZUSTANDH()
                    tL(s + 1) = tstern
                    xL(s + 1) = xstern
                    phiL(s + 1) = phistern
                    Kondensat(s) = mL * (xL(s + 1) - xL(s))
                    'Stabilit�tstest f�r die numerische Rechnung
                    If QL(s) > 0 And tL(s + 1) > tmittel Then tL(s + 1) = tmittel
                    If QL(s) < 0 And tL(s + 1) < tmittel Then tL(s + 1) = tmittel
                ElseIf Richtung = -1 Then
                    hL(s - 1) = hL(s) + QL(s) / Dtau / mL / 1000
                    hstern = hL(s - 1)
                    xstern = xL(s)
                    Call ZUSTANDH()
                    tL(s - 1) = tstern
                    xL(s - 1) = xstern
                    phiL(s - 1) = phistern
                    Kondensat(s) = mL * (xL(s - 1) - xL(s))
                    'Stabilit�tstest f�r die numerische Rechnung
                    If QL(s) > 0 And tL(s - 1) > tmittel Then tL(s - 1) = tmittel
                    If QL(s) < 0 And tL(s - 1) < tmittel Then tL(s - 1) = tmittel
                Else
                    tL(s) = -273
                    xL(s) = 0
                    Kondensat(s) = 0
                End If
                QMedium(BS) = QMedium(BS) + QL(s)
                Kondensatmenge(BS) = Kondensatmenge(BS) + Kondensat(s) * Dtau
            Next s

            'Medientemperaturen zum Speichern am Ende der Betriebsstunde BS
            If Intervall = Intervallmax Then
                RichtungBS(BS) = Richtung
                Tagesstunde(BS) = tauUhr
                If Richtung = 1 Then
                    tLein(BS) = tL(1)
                    xLein(BS) = xL(1)
                    phiLein(BS) = phiL(1)
                    tLaus(BS) = tL(smax + 1)
                    xLaus(BS) = xL(smax + 1)
                    phiLaus(BS) = phiL(smax + 1)
                ElseIf Richtung = -1 Then
                    tLein(BS) = tL(smax)
                    xLein(BS) = xL(smax)
                    phiLein(BS) = phiL(smax)
                    tLaus(BS) = tL(0)
                    xLaus(BS) = xL(0)
                    phiLaus(BS) = phiL(0)
                Else
                    tLein(BS) = -273
                    xLein(BS) = -273
                    phiLein(BS) = -273
                    tLaus(BS) = -273
                    xLaus(BS) = -273
                    phiLaus(BS) = -273
                End If

                'W�rme im Speicher am Ende der Betriebsstunde (Intervall = Intervallmax)
                'QSpeicher(BS) Bezug auf aktuelle Lufteintrittstemperatur
                Sum = 0
                For s = 1 To smax
                    For p = 1 To pmax
                        For i = 1 To imax(p)
                            For j = 1 To jmax(p)
                                For k = 1 To kmax(p)
                                    Sum = Sum + CE(p) * (tn(s, p, i, j, k) - tLa) * 8 * ZP(p) / smax
                                Next k
                            Next j
                        Next i
                    Next p
                Next s
                QSpeicher(BS) = Sum

                'Dateierzeugung "Speicherfeld.dat" - Speicherzustand der Abschnitte s
                If BS = BSTest And BSTest > 0 Then
                    Verlauf = Objektbezeichnung + "Speicherverlauf.dat"
                    FileOpen(1, Verlauf, OpenMode.Output)
                    Write(1, BSTest)
                    Write(1, pTest)
                    Write(1, smax)
                    Write(1, Richtung)
                    For s = 0 To smax + 1
                        'Verlauf der abschnittsweisen Lufttemperatur
                        Write(1, tL(s))
                        'Verlauf der abschnittsweisen Luftfeuchte
                        Write(1, xL(s))
                        'Verlauf der abschnittsweisen Kerntemperatur des Partikels pTest
                        Write(1, tn(s, pTest, 1, 1, 1))
                        'Verlauf der abschnittsweisen Oberfl�chentemperatur des Partikels pTest
                        Write(1, tn(s, pTest, 1, jmax(pTest), 1))
                    Next s
                    FileClose(1)
                End If
            End If

            'Umspeichern des Temperaturfeldes
            For s = 1 To smax
                For p = 1 To pmax
                    For i = 1 To imax(p)
                        For j = 1 To jmax(p)
                            For k = 1 To kmax(p)
                                t(s, p, i, j, k) = tn(s, p, i, j, k)
                            Next k
                        Next j
                    Next i
                Next p
            Next s

            'Dateiausschrift des letzten Temperaturfeldes f�r die simulierte Stunde
            If BS = BSmax And Intervall = Intervallmax Then
                Feld = Objektbezeichnung + "Speicherfeld.dat"
                FileOpen(1, Feld, OpenMode.Output)
                For s = 1 To smax
                    For p = 1 To pmax
                        For i = 1 To imax(p)
                            For j = 1 To jmax(p)
                                For k = 1 To kmax(p)
                                    Write(1, t(s, p, i, j, k))
                                Next k
                            Next j
                        Next i
                    Next p
                Next s
                FileClose(1)
            End If
        Next Zeit
        'Mitteilungen zum Berechnungsende
        GanzeStunde = 10
        Call Zeitmitteilung()
Label_Inst:
    End Sub

    Sub ERGEBNISSPEICHERUNG()
        Datei = Objektbezeichnung + "Ergebnis.dat"
        FileOpen(1, Datei, OpenMode.Output)
        Write(1, BSmax)
        For BS = 0 To BSmax
            Write(1, Tagesstunde(BS))
            Write(1, tLein(BS))
            Write(1, tLaus(BS))
            Write(1, xLein(BS))
            Write(1, xLaus(BS))
            Write(1, phiLein(BS))
            Write(1, phiLaus(BS))
            Write(1, Kondensatmenge(BS))            'in kg/h
            Write(1, QMedium(BS) / 3600000)         'in kW
            Write(1, QSpeicher(BS) / 3600000)       'in kWh
            Write(1, RichtungBS(BS))
            Write(1, Feld)
        Next BS
        FileClose(1)
    End Sub

    Sub ERGEBNISLADUNG()
        Datei = Objektbezeichnung + "Ergebnis.dat"
        FileOpen(1, Datei, OpenMode.Input)
        Input(1, BSmax)
        For BS = 0 To BSmax
            Input(1, Tagesstunde(BS))
            Input(1, tLein(BS))
            Input(1, tLaus(BS))
            Input(1, xLein(BS))
            Input(1, xLaus(BS))
            Input(1, phiLein(BS))
            Input(1, phiLaus(BS))
            Input(1, Kondensatmenge(BS))
            Input(1, QMedium(BS))
            Input(1, QSpeicher(BS))
            Input(1, RichtungBS(BS))
            Input(1, Feld)
        Next BS
        FileClose(1)
    End Sub

    Function cL(ByVal t, ByVal x)
        Dim cLL, cWL As Single
        cLL = 1.0065 + 0.000005309587 * t + 0.0000004758596 * t ^ 2 - 0.0000000001136145 * t ^ 3
        If t < 0 Then
            cL = cLL * 1000
        Else
            cWL = 1.863 + 0.0002680862 * t + 0.0000006794704 * t ^ 2 - 0.0000000002641422 * t ^ 3
            cL = (cLL + x * cWL) / (1 + x) * 1000
        End If
    End Function

    Function lamL(ByVal t, ByVal x)
        Dim lamLL, lamWL, PHIW As Single
        lamLL = 0.024178 + 0.00007634878 * t - 0.00000004663859 * t ^ 2 + 0.00000000004612639 * t ^ 3
        If t < 0 Then
            lamL = lamLL
        Else
            lamWL = 0.016976 + 0.000057535 * t + 0.0000001277125 * t ^ 2 - 0.00000000008951228 * t ^ 3
            PHIW = x / (0.6222 + x)
            lamL = (1 - PHIW) * lamLL + PHIW * lamWL
        End If
    End Function

    Function nyL(ByVal t, ByVal x, ByVal rhoL)
        Dim etaLL, etaWL, PHIW As Single
        etaLL = 0.0000172436 + 0.0000000504587 * t - 0.00000000003923361 * t ^ 2 + 0.00000000000004046118 * t ^ 3
        If t < 0 Then
            nyL = etaLL / rhoL
        Else
            etaWL = 0.0000091435 + 0.0000000281979 * t + 0.00000000004486993 * t ^ 2 - 0.00000000000004928814 * t ^ 3
            PHIW = x / (0.6222 + x)
            nyL = ((1 - PHIW) * etaLL + PHIW * etaWL) / rhoL
        End If
    End Function

    Function rhoL(ByVal t, ByVal x)
        rhoL = (1 + x) / (x + 0.6222) * pL / (273 + t) / 461.4
    End Function

    Function PSA(ByVal xx)
        'Verdampfungskurve
        If 0.01 <= xx And xx <= 100 Then
            PSA = 611 * Math.Exp(-0.000191275 + 0.07258 * xx - 0.0002939 * xx ^ 2 + 0.0000009841 * xx ^ 3 - 0.00000000192 * xx ^ 4)
            'Sublimationskurve
        ElseIf -20 <= xx And xx < 0.01 Then
            PSA = 611 * Math.Exp(-0.0004909965 + 0.08183197 * xx - 0.0005552967 * xx ^ 2 - 0.00002228376 * xx ^ 3 - 0.0000006211808 * xx ^ 4)
        End If
    End Function

    Function TS(ByVal xx)
        Dim Y As Single
        Y = Math.Log(xx)
        'Verdampfungskurve
        If 611 <= xx And xx <= 101320 Then
            TS = -63.16113 + 5.36859 * Y + 0.973587 * Y ^ 2 - 0.0738636 * Y ^ 3 + 0.00481832 * Y ^ 4
            'Sublimationskurve
        ElseIf 103 <= xx And xx < 611 Then
            TS = -61.125785# + 8.1386 * Y - 0.07422003 * Y ^ 2 + 0.06283721# * Y ^ 3 - 0.0027237063# * Y ^ 4
        End If
    End Function

    Sub ZUSTAND()
        Dim pS, pW, xW, deltah As Single
        pS = PSA(tstern)
        pW = xstern * pL / (0.6222 + xstern)
        xS = 0.6222 * pS / (pL - pS)
        If pS - pW >= -0.00001 Then
            xW = xstern
            phistern = pW / pS * 100
            deltah = 0
        Else
            xW = xS
            If tstern > 0 Then
                deltah = (xstern - xS) * 4.19 * tstern
                phistern = 200
            Else
                deltah = (xstern - xS) * (-334 + 2.09 * tstern)
                phistern = 300
            End If
        End If
        hstern = 1.01 * tstern + xW * (2501 + 1.86 * tstern) + deltah
    End Sub

    Sub ZUSTANDH()
        Dim pS, pW, xW, deltah, hv, ttau, htau, hr As Single
        phistern = 0
        hv = hstern : xS = xstern
        pS = xstern * pL / (0.6222 + xstern)
        If pS > 100 Then
            ttau = TS(pS)
            htau = 1.01 * ttau + xstern * (2501 + 1.86 * ttau)
            If hv < htau Then
                tstern = Int(ttau + 1)
                Do
                    hr = hstern
                    tstern = tstern - 1
                    pS = PSA(tstern)
                    xS = 0.6222 * pS / (pL - pS)
                    hstern = 1.01 * tstern + xS * (2501 + 1.86 * tstern)
                    If tstern > 0 Then
                        hstern = hstern + (xstern - xS) * 4.19 * tstern
                    Else
                        hstern = hstern + (xstern - xS) * (-334 + 2.09 * tstern)
                    End If
                Loop While hv < hstern
                If hv = hr Then
                    tstern = tstern + (ttau - tstern) * (hv - hstern) / (htau - hstern)
                Else
                    tstern = tstern + (hv - hstern) / (hr - hstern)
                End If
                'Annahme: Kondensation mit der Austrittsfeuchte von 100 %
                hstern = hv
                pS = PSA(tstern)
                xS = 0.6222 * pS / (pL - pS)
                If xS < xstern Then xstern = xS
                phistern = 100
            Else
                tstern = (hv - xstern * 2501) / (1.01 + xstern * 1.86)
            End If
        Else
            tstern = (hv - xstern * 2501) / (1.01 + xstern * 1.86)
        End If
        If phistern < 100 Then
            pW = xstern * pL / (0.6222 + xstern)
            pS = PSA(tstern)
            phistern = pW / pS * 100
        End If
    End Sub

    Sub MASKELESEN()
        'Lesen der Maskenfelder
        rho = CType(TextBox2.Text, Single)
        lam = CType(TextBox3.Text, Single)
        c = CType(TextBox5.Text, Single)
        PSI = CType(TextBox32.Text, Single)
        V(1) = CType(TextBox17.Text, Single)
        V(2) = CType(TextBox14.Text, Single)
        V(3) = CType(TextBox15.Text, Single)
        V(4) = CType(TextBox16.Text, Single)
        V(5) = CType(TextBox18.Text, Single)
        V(6) = CType(TextBox19.Text, Single)
        V(7) = CType(TextBox21.Text, Single)
        V(8) = CType(TextBox22.Text, Single)
        V(9) = CType(TextBox39.Text, Single)
        V(10) = CType(TextBox40.Text, Single)
        Anteil(1) = CType(TextBox29.Text, Single)
        Anteil(2) = CType(TextBox26.Text, Single)
        Anteil(3) = CType(TextBox27.Text, Single)
        Anteil(4) = CType(TextBox28.Text, Single)
        Anteil(5) = CType(TextBox33.Text, Single)
        Anteil(6) = CType(TextBox23.Text, Single)
        Anteil(7) = CType(TextBox24.Text, Single)
        Anteil(8) = CType(TextBox25.Text, Single)
        Anteil(9) = CType(TextBox1.Text, Single)
        Anteil(10) = CType(TextBox34.Text, Single)
        Fak = CType(TextBox45.Text, Single)
        Exp = CType(TextBox50.Text, Single)
        Hoehe = CType(TextBox13.Text, Single)
        Breite = CType(TextBox11.Text, Single)
        Laenge = CType(TextBox12.Text, Single)
        Vh = CType(TextBox155.Text, Single)
        BSmax = CType(TextBox41.Text, Integer)
        Uhrbeginn = CType(TextBox42.Text, Integer)
        Dtau = CType(TextBox43.Text, Integer)
        tStart = CType(TextBox44.Text, Single)
        ETagfix = CType(TextBox4.Text, Integer)
        smax = CType(TextBox6.Text, Integer)
        dK = CType(TextBox7.Text, Single)
        dK = dK / 1000
        If tStart = -273 Then Speicherfeld = CType(TextBox8.Text, String)
        BSTest = CType(TextBox51.Text, Integer)
        pTest = CType(TextBox52.Text, Integer)
    End Sub

    Sub EINTRAG1()
        'Eintragen in Maskenfelder
        TextBox2.Text = rho.ToString
        TextBox3.Text = lam.ToString
        TextBox5.Text = c.ToString
        TextBox32.Text = PSI.ToString
        TextBox17.Text = V(1).ToString
        TextBox14.Text = V(2).ToString
        TextBox15.Text = V(3).ToString
        TextBox16.Text = V(4).ToString
        TextBox18.Text = V(5).ToString
        TextBox19.Text = V(6).ToString
        TextBox21.Text = V(7).ToString
        TextBox22.Text = V(8).ToString
        TextBox39.Text = V(9).ToString
        TextBox40.Text = V(10).ToString
        TextBox29.Text = Anteil(1).ToString
        TextBox26.Text = Anteil(2).ToString
        TextBox27.Text = Anteil(3).ToString
        TextBox28.Text = Anteil(4).ToString
        TextBox33.Text = Anteil(5).ToString
        TextBox23.Text = Anteil(6).ToString
        TextBox24.Text = Anteil(7).ToString
        TextBox25.Text = Anteil(8).ToString
        TextBox1.Text = Anteil(9).ToString
        TextBox34.Text = Anteil(10).ToString
        TextBox45.Text = Fak.ToString
        TextBox50.Text = Exp.ToString
        TextBox13.Text = Hoehe.ToString
        TextBox11.Text = Breite.ToString
        TextBox12.Text = Laenge.ToString
        TextBox155.Text = Vh.ToString
        TextBox41.Text = BSmax.ToString
        TextBox42.Text = Uhrbeginn.ToString
        TextBox43.Text = Dtau.ToString
        TextBox44.Text = tStart.ToString
        TextBox4.Text = ETagfix.ToString
        TextBox6.Text = smax.ToString
        TextBox7.Text = (dK * 1000).ToString
        If tStart = -273 Then TextBox8.Text = Speicherfeld.ToString Else TextBox8.Text = ""
        TextBox51.Text = BSTest.ToString
        TextBox52.Text = pTest.ToString
        Verlauf = Objektbezeichnung + "Speicherverlauf.dat"
        If BSTest > 0 Then TextBox9.Text = Verlauf.ToString Else TextBox9.Text = ""
    End Sub

    Sub NULLEINTRAG()
        'Eintragen in Maskenfelder
        TextBox2.Text = 0.ToString
        TextBox3.Text = 0.ToString
        TextBox5.Text = 0.ToString
        TextBox32.Text = 0.ToString
        TextBox17.Text = 0.ToString
        TextBox14.Text = 0.ToString
        TextBox15.Text = 0.ToString
        TextBox16.Text = 0.ToString
        TextBox18.Text = 0.ToString
        TextBox19.Text = 0.ToString
        TextBox21.Text = 0.ToString
        TextBox22.Text = 0.ToString
        TextBox39.Text = 0.ToString
        TextBox40.Text = 0.ToString
        TextBox29.Text = 0.ToString
        TextBox26.Text = 0.ToString
        TextBox27.Text = 0.ToString
        TextBox28.Text = 0.ToString
        TextBox33.Text = 0.ToString
        TextBox23.Text = 0.ToString
        TextBox24.Text = 0.ToString
        TextBox25.Text = 0.ToString
        TextBox1.Text = 0.ToString
        TextBox34.Text = 0.ToString
        TextBox45.Text = 0.ToString
        TextBox50.Text = 0.ToString
        TextBox13.Text = 0.ToString
        TextBox11.Text = 0.ToString
        TextBox12.Text = 0.ToString
        TextBox155.Text = 0.ToString
        TextBox41.Text = 72.ToString
        TextBox42.Text = 0.ToString
        TextBox43.Text = 0.ToString
        TextBox44.Text = 10.ToString
        TextBox4.Text = 1.ToString
        TextBox6.Text = 10.ToString
        TextBox7.Text = 0.ToString
        TextBox8.Text = "".ToString
        TextBox51.Text = 0.ToString
        TextBox52.Text = 0.ToString
        TextBox9.Text = "".ToString
    End Sub

    Sub EINGABESPEICHERUNG1()
        Datei = Objektbezeichnung + "Eingabe.dat"
        FileOpen(1, Datei, OpenMode.Output)
        Write(1, rho)
        Write(1, lam)
        Write(1, c)
        Write(1, PSI)
        For p = 1 To 10
            Write(1, V(p))
            Write(1, Anteil(p))
            Write(1, O(p))
            Write(1, a(p))
            Write(1, b(p))
            Write(1, jmax(p))
            Write(1, kmax(p))
            Write(1, imax(p))
            Write(1, Dx(p))
            Write(1, Dy(p))
            Write(1, VTyp(p))
            Write(1, ZP(p))
            Write(1, DtauPartikel(p))
            Write(1, Oanteil(p))
        Next p
        Write(1, Fak)
        Write(1, Exp)
        Write(1, Hoehe)
        Write(1, Breite)
        Write(1, Laenge)
        Write(1, Vh)
        Write(1, pmax)
        Write(1, Vfest)
        Write(1, mfest)
        Write(1, VLuft)
        Write(1, aFaehigkeit)
        Write(1, Dtaumax)
        Write(1, DtauVorschlag)
        Write(1, Dtau)
        Write(1, BSmax)
        Write(1, Uhrbeginn)
        Write(1, tStart)
        Write(1, ETagfix)
        Write(1, smax)
        Write(1, dK)
        Write(1, Speicherfeld)
        Write(1, BSTest)
        Write(1, pTest)
        FileClose(1)
    End Sub

    Sub EINGABELADUNG1()
        Datei = Objektbezeichnung + "Eingabe.dat"
        FileOpen(1, Datei, OpenMode.Input)
        Input(1, rho)
        Input(1, lam)
        Input(1, c)
        Input(1, PSI)
        For p = 1 To 10
            Input(1, V(p))
            Input(1, Anteil(p))
            Input(1, O(p))
            Input(1, a(p))
            Input(1, b(p))
            Input(1, jmax(p))
            Input(1, kmax(p))
            Input(1, imax(p))
            Input(1, Dx(p))
            Input(1, Dy(p))
            Input(1, VTyp(p))
            Input(1, ZP(p))
            Input(1, DtauPartikel(p))
            Input(1, Oanteil(p))
        Next p
        Input(1, Fak)
        Input(1, Exp)
        Input(1, Hoehe)
        Input(1, Breite)
        Input(1, Laenge)
        Input(1, Vh)
        Input(1, pmax)
        Input(1, Vfest)
        Input(1, mfest)
        Input(1, VLuft)
        Input(1, aFaehigkeit)
        Input(1, Dtaumax)
        Input(1, DtauVorschlag)
        Input(1, Dtau)
        Input(1, BSmax)
        Input(1, Uhrbeginn)
        Input(1, tStart)
        Input(1, ETagfix)
        Input(1, smax)
        Input(1, dK)
        Input(1, Speicherfeld)
        Input(1, BSTest)
        Input(1, pTest)
        FileClose(1)
    End Sub

    Public Sub EINGABELADUNG2()
        Datei = Objektbezeichnung + "ZVerlauf.dat"
        FileOpen(1, Datei, OpenMode.Input)
        For ETag = 1 To 20
            For Stunde = 0 To 24
                Input(1, VLanteil(ETag, Stunde))
                Input(1, R(ETag, Stunde))
                Input(1, tLETag(ETag, Stunde))
                Input(1, xLETag(ETag, Stunde))
                Input(1, phiETag(ETag, Stunde))
            Next Stunde
        Next ETag
        FileClose(1)
    End Sub

    Public Sub Zeitmitteilung()
        Dim fx As New Form3
        If GanzeStunde = 10 Then TextBox130.Text = "Simulationszyklus beendet!"
        fx.GanzeStunde = GanzeStunde
        fx.tauStunde = BS
        fx.Show()
    End Sub

    Public Sub Druck_Eingabe()
        Dim wordapp As Object
        Dim Zeile, fo0, fo1, fo2, fo3, fo4, fo5, fo6, fo7, fo8, fo9, fo10, fo11, fo12, fo13, fo14, fo15 As String
        Dim Hilf As Single
        wordapp = CreateObject("Word.Application")         'Variable initialisieren
        If wordapp Is Nothing Then
            MsgBox("Konnte keine Verbindung zu Word herstellen!", 16, "Problem")
            Exit Sub
        End If
        With wordapp
            .Visible = True
            .Documents.Add()
            If .ActiveWindow.View.SplitSpecial <> 0 Then .ActiveWindow.Panes(2).Close()
            If .ActiveWindow.ActivePane.View.Type = 1 Or .ActiveWindow. _
                  ActivePane.View.Type = 2 Or .ActiveWindow.ActivePane.View.Type _
                   = 5 Then .ActiveWindow.ActivePane.View.Type = 3
            .ActiveWindow.ActivePane.View.SeekView = 0
            With .Selection.Font
                .Name = "Balloon Bd BT"
                .Size = 11
                .Bold = False
            End With
            .Selection.TypeText(Text:="Objektbezeichnung:  " + Objektbezeichnung)
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 12
                .Bold = True
            End With
            .Selection.TypeText(Text:="Schotterspeicher mit Luftdurchstr�mung")
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 12
                .Bold = False
            End With
            .Selection.TypeText(Text:="Speicherabmessungen und Luftvolumenstrom:")
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Courier New"
                .Size = 9
                .Bold = False
            End With
            .Selection.TypeText(Text:="_______________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="  H�he     Breite     L�nge    Luftvolumenstrom")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="    m         m         m             m�/h")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_______________________________________________")
            .Selection.TypeParagraph()
            fo1 = fo33(Hoehe)
            fo2 = fo33(Breite)
            fo3 = fo33(Laenge)
            fo4 = fo51(Vh)
            Zeile = fo1 + "   " + fo2 + "   " + fo3 + "         " + fo4
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_______________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 12
                .Bold = False
            End With
            .Selection.TypeText(Text:="Daten des Speichermaterials:")
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Courier New"
                .Size = 9
                .Bold = False
            End With
            .Selection.TypeText(Text:="____________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="   Rho     Lambda        c       Hohlraumanteil     �quivalenter Durchmesser")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="  kg/m�    W/(m K)    J/(kg K)         %                       mm")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="____________________________________________________________________________")
            .Selection.TypeParagraph()
            fo1 = fo51(rho)
            fo2 = fo33(lam)
            fo3 = fo33(c)
            fo4 = fo51(PSI)
            fo5 = fo52(1000 * dK)
            Zeile = fo1 + "   " + fo2 + "     " + fo3 + "     " + fo4 + "                  " + fo5
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="____________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_______________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="Schottervolumen    Schottermasse    Luftvolumen")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="       m�                kg               m�")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_______________________________________________")
            .Selection.TypeParagraph()
            fo1 = fo52(Vfest)
            fo2 = fo33(mfest)
            fo3 = fo52(VLuft)

            Zeile = "  " + fo1 + "         " + fo2 + "        " + fo3
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_______________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 12
                .Bold = False
            End With
            .Selection.TypeText(Text:="Partikeldaten:")
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Courier New"
                .Size = 9
                .Bold = False
            End With
            .Selection.TypeText(Text:="_________________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                                   Partikeltyp p")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="     1       2       3       4       5       6       7       8       9      10")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_________________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                              Partikelvolumina in cm�")
            .Selection.TypeParagraph()
            fo1 = fo52(V(1))
            fo2 = fo52(V(2))
            fo3 = fo52(V(3))
            fo4 = fo52(V(4))
            fo5 = fo52(V(5))
            fo6 = fo52(V(6))
            fo7 = fo52(V(7))
            fo8 = fo52(V(8))
            fo9 = fo52(V(9))
            fo10 = fo52(V(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                                Partikelanteile in %")
            .Selection.TypeParagraph()
            fo1 = fo52(Anteil(1))
            fo2 = fo52(Anteil(2))
            fo3 = fo52(Anteil(3))
            fo4 = fo52(Anteil(4))
            fo5 = fo52(Anteil(5))
            fo6 = fo52(Anteil(6))
            fo7 = fo52(Anteil(7))
            fo8 = fo52(Anteil(8))
            fo9 = fo52(Anteil(9))
            fo10 = fo52(Anteil(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                             Partikeloberfl�chen in cm�")
            .Selection.TypeParagraph()
            fo1 = fo52(O(1))
            fo2 = fo52(O(2))
            fo3 = fo52(O(3))
            fo4 = fo52(O(4))
            fo5 = fo52(O(5))
            fo6 = fo52(O(6))
            fo7 = fo52(O(7))
            fo8 = fo52(O(8))
            fo9 = fo52(O(9))
            fo10 = fo52(O(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                     Approximierte Partikelquadratseite in cm")
            .Selection.TypeParagraph()
            fo1 = fo52(100 * a(1))
            fo2 = fo52(100 * a(2))
            fo3 = fo52(100 * a(3))
            fo4 = fo52(100 * a(4))
            fo5 = fo52(100 * a(5))
            fo6 = fo52(100 * a(6))
            fo7 = fo52(100 * a(7))
            fo8 = fo52(100 * a(8))
            fo9 = fo52(100 * a(9))
            fo10 = fo52(100 * a(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                         Approximierte Partikell�nge in cm")
            .Selection.TypeParagraph()
            fo1 = fo52(100 * b(1))
            fo2 = fo52(100 * b(2))
            fo3 = fo52(100 * b(3))
            fo4 = fo52(100 * b(4))
            fo5 = fo52(100 * b(5))
            fo6 = fo52(100 * b(6))
            fo7 = fo52(100 * b(7))
            fo8 = fo52(100 * b(8))
            fo9 = fo52(100 * b(9))
            fo10 = fo52(100 * b(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                   Gesamtvolumen der approximierten Partikel in m�")
            .Selection.TypeParagraph()
            fo1 = fo52(VTyp(1))
            fo2 = fo52(VTyp(2))
            fo3 = fo52(VTyp(3))
            fo4 = fo52(VTyp(4))
            fo5 = fo52(VTyp(5))
            fo6 = fo52(VTyp(6))
            fo7 = fo52(VTyp(7))
            fo8 = fo52(VTyp(8))
            fo9 = fo52(VTyp(9))
            fo10 = fo52(VTyp(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                         Anzahl der approximierten Partikel")
            .Selection.TypeParagraph()
            fo1 = fo80(ZP(1))
            fo2 = fo80(ZP(2))
            fo3 = fo80(ZP(3))
            fo4 = fo80(ZP(4))
            fo5 = fo80(ZP(5))
            fo6 = fo80(ZP(6))
            fo7 = fo80(ZP(7))
            fo8 = fo80(ZP(8))
            fo9 = fo80(ZP(9))
            fo10 = fo80(ZP(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="        Anteile der Partikeloberfl�chen an der Gesamtoberfl�che in %")
            .Selection.TypeParagraph()
            fo1 = fo52(100 * Oanteil(1))
            fo2 = fo52(100 * Oanteil(2))
            fo3 = fo52(100 * Oanteil(3))
            fo4 = fo52(100 * Oanteil(4))
            fo5 = fo52(100 * Oanteil(5))
            fo6 = fo52(100 * Oanteil(6))
            fo7 = fo52(100 * Oanteil(7))
            fo8 = fo52(100 * Oanteil(8))
            fo9 = fo52(100 * Oanteil(9))
            fo10 = fo52(100 * Oanteil(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_________________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 12
                .Bold = False
            End With
            .Selection.TypeText(Text:="Gitterdarstellung der Partikel und Ermittlung des maximalen Zeitschrittes:")
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Courier New"
                .Size = 9
                .Bold = False
            End With
            .Selection.TypeText(Text:="_________________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                                   Partikeltyp p")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="     1       2       3       4       5       6       7       8       9      10")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_________________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                 Unterteilung der halben Quadratseite: Dx(p) in cm")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                      Maximale Gitternummer: jmax(p) = kmax(p)")
            .Selection.TypeParagraph()
            fo1 = fo52(100 * Dx(1))
            fo2 = fo52(100 * Dx(2))
            fo3 = fo52(100 * Dx(3))
            fo4 = fo52(100 * Dx(4))
            fo5 = fo52(100 * Dx(5))
            fo6 = fo52(100 * Dx(6))
            fo7 = fo52(100 * Dx(7))
            fo8 = fo52(100 * Dx(8))
            fo9 = fo52(100 * Dx(9))
            fo10 = fo52(100 * Dx(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            fo1 = fo50(jmax(1))
            fo2 = fo50(jmax(2))
            fo3 = fo50(jmax(3))
            fo4 = fo50(jmax(4))
            fo5 = fo50(jmax(5))
            fo6 = fo50(jmax(6))
            fo7 = fo50(jmax(7))
            fo8 = fo50(jmax(8))
            fo9 = fo50(jmax(9))
            fo10 = fo50(jmax(10))
            Zeile = fo1 + "   " + fo2 + "   " + fo3 + "   " + fo4 + "   " + fo5 + "   " + fo6 + "   " + fo7 + "   " + fo8 + "   " + fo9 + "   " + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                 Unterteilung der halben Quaderl�nge: Dy(p) in cm")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="                          Maximale Gitternummer: imax(p)")
            .Selection.TypeParagraph()
            fo1 = fo52(100 * Dy(1))
            fo2 = fo52(100 * Dy(2))
            fo3 = fo52(100 * Dy(3))
            fo4 = fo52(100 * Dy(4))
            fo5 = fo52(100 * Dy(5))
            fo6 = fo52(100 * Dy(6))
            fo7 = fo52(100 * Dy(7))
            fo8 = fo52(100 * Dy(8))
            fo9 = fo52(100 * Dy(9))
            fo10 = fo52(100 * Dy(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            fo1 = fo50(imax(1))
            fo2 = fo50(imax(2))
            fo3 = fo50(imax(3))
            fo4 = fo50(imax(4))
            fo5 = fo50(imax(5))
            fo6 = fo50(imax(6))
            fo7 = fo50(imax(7))
            fo8 = fo50(imax(8))
            fo9 = fo50(imax(9))
            fo10 = fo50(imax(10))
            Zeile = fo1 + "   " + fo2 + "   " + fo3 + "   " + fo4 + "   " + fo5 + "   " + fo6 + "   " + fo7 + "   " + fo8 + "   " + fo9 + "   " + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="  Maximale Zeitschrittweite f�r die Partikelapproximation: DtauPartikel(p) in s")
            .Selection.TypeParagraph()
            fo1 = fo52(DtauPartikel(1))
            fo2 = fo52(DtauPartikel(2))
            fo3 = fo52(DtauPartikel(3))
            fo4 = fo52(DtauPartikel(4))
            fo5 = fo52(DtauPartikel(5))
            fo6 = fo52(DtauPartikel(6))
            fo7 = fo52(DtauPartikel(7))
            fo8 = fo52(DtauPartikel(8))
            fo9 = fo52(DtauPartikel(9))
            fo10 = fo52(DtauPartikel(10))
            Zeile = fo1 + "" + fo2 + "" + fo3 + "" + fo4 + "" + fo5 + "" + fo6 + "" + fo7 + "" + fo8 + "" + fo9 + "" + fo10
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_________________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            fo1 = fo50(Dtaumax)
            Zeile = "Maximal w�hlbare Zeitschrittweite:   " + fo1 + " s"
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            fo1 = fo50(DtauVorschlag)
            Zeile = "Vorgeschlagene Zeitschrittweite:     " + fo1 + " s  (ganzzahlig in 3600 s enthalten)"
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 12
                .Bold = False
            End With
            .Selection.TypeText(Text:="Daten zum Simulationsablauf:")
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Courier New"
                .Size = 9
                .Bold = False
            End With
            .Selection.TypeText(Text:="_______________________________________________")
            .Selection.TypeParagraph()
            fo1 = fo50(BSmax)
            Zeile = "Simulationsstunden:                 " + fo1 + " h"
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            fo1 = fo50(Uhrbeginn)
            Zeile = "Tagesstartzeit:                     " + fo1 + " Uhr"
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            fo1 = fo50(Dtau)
            Zeile = "Gew�hlte Zeitschrittweite:          " + fo1 + " s"
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            fo1 = fo50(ETagfix)
            Zeile = "Betriebsablauf nach Entwurfstag:    " + fo1
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            fo1 = fo50(smax)
            Zeile = "Anzahl der Speicherunterteilungen:  " + fo1
            .Selection.TypeText(Text:=Zeile)
            .Selection.TypeParagraph()
            If tStart > -273 Then
                fo1 = fo31(tStart)
                Zeile = "Starttemperatur:                    " + fo1 + " �C"
                .Selection.TypeText(Text:=Zeile)
                .Selection.TypeParagraph()
            Else
                Zeile = "Start mit bekannter Temperaturfeldeingabe:"
                .Selection.TypeText(Text:=Zeile)
                .Selection.TypeParagraph()
                Zeile = Speicherfeld
                .Selection.TypeText(Text:=Zeile)
                .Selection.TypeParagraph()
            End If
            .Selection.TypeText(Text:="_______________________________________________")
            .Selection.TypeParagraph()
        End With
    End Sub

    Public Sub Druck_Ergebnis()
        Dim wordapp, ccc As Object
        Dim Zeile, fo0, fo1, fo2, fo3, fo4, fo5, fo6, fo7, fo8, fo9, fo10, fo11, fo12, fo13, fo14, fo15 As String
        Dim k As Integer
        wordapp = CreateObject("Word.Application")         'Variable initialisieren
        If wordapp Is Nothing Then
            MsgBox("Konnte keine Verbindung zu Word herstellen!", 16, "Problem")
            Exit Sub
        End If
        With wordapp
            .Visible = True
            .Documents.Add()
            If .ActiveWindow.View.SplitSpecial <> 0 Then .ActiveWindow.Panes(2).Close()
            If .ActiveWindow.ActivePane.View.Type = 1 Or .ActiveWindow. _
                  ActivePane.View.Type = 2 Or .ActiveWindow.ActivePane.View.Type _
                   = 5 Then .ActiveWindow.ActivePane.View.Type = 3
            .ActiveWindow.ActivePane.View.SeekView = 0
            With .Selection.Font
                .Name = "Balloon Bd BT"
                .Size = 11
                .Bold = False
            End With
            .Selection.TypeText(Text:="Objektbezeichnung:  " + Objektbezeichnung)
            .Selection.TypeParagraph()

            'Kontrollausgabe f�r allgemeine Eingaben
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 12
                .Bold = True
            End With
            .Selection.TypeText(Text:="Schotterspeicher mit Luftdurchstr�mung")
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 12
                .Bold = False
            End With
            .Selection.TypeText(Text:="Simulationsergebnisse als Stundenwerte:")
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Courier New"
                .Size = 9
                .Bold = False
            End With
            .Selection.TypeText(Text:="___________________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="BS/Tages- tLein   tLaus   xLein   xLaus  phiLein  phiLaus  mKon   QLuft   QSpeicher")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="stunde     �C      �C     g/kg    g/kg      %        %     kg/h    kW        kWh")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="___________________________________________________________________________________")
            .Selection.TypeParagraph()
            For BS = 0 To BSmax
                fo0 = fo30(BS)
                fo1 = fo20(Tagesstunde(BS))
                If RichtungBS(BS) = 0 Or tLein(BS) = -273 Then fo2 = "    -" Else fo2 = fo31(tLein(BS))
                If RichtungBS(BS) = 0 Or tLaus(BS) = -273 Then fo3 = "    -" Else fo3 = fo31(tLaus(BS))
                If RichtungBS(BS) = 0 Or xLein(BS) = -273 Then fo4 = "    -" Else fo4 = fo31(xLein(BS) * 1000)
                If RichtungBS(BS) = 0 Or xLaus(BS) = -273 Then fo5 = "    -" Else fo5 = fo31(xLaus(BS) * 1000)
                If RichtungBS(BS) = 0 Or phiLein(BS) = -273 Then fo6 = "    -" Else fo6 = fo31(phiLein(BS))
                If RichtungBS(BS) = 0 Or phiLaus(BS) = -273 Then fo7 = "    -" Else fo7 = fo31(phiLaus(BS))
                If BS = 0 Then fo7 = "    -"
                If RichtungBS(BS) = 0 Then fo8 = "    -" Else fo8 = fo31(Kondensatmenge(BS))
                If BS = 0 Then fo8 = "    -"
                If RichtungBS(BS) = 0 Then fo9 = "      -" Else fo9 = fo51(QMedium(BS))
                If BS = 0 Then fo9 = "      -"
                If RichtungBS(BS) = 0 Then fo10 = "      -" Else fo10 = fo51(QSpeicher(BS))
                Zeile = fo0 + "/" + fo1 + "    " + fo2 + "   " + fo3 + "   " + fo4 + "   " + fo5 + "  " + fo6 + "    " + fo7 + "  " + fo8 + "  " + fo9 + "     " + fo10
                .Selection.TypeText(Text:=Zeile)
                .Selection.TypeParagraph()
            Next BS
            .Selection.TypeText(Text:="___________________________________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="Legende: {Ende der Betriebsstunde = 1 Zeitschritt vor Erreichen der vollen Stunde!}")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="BS         Simulationsstunde")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="tLein      Lufteintrittstemperatur am Ende der Betriebsstunde")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="tLaus      Luftaustrittstemperatur am Ende der Betriebsstunde")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="xLein      absolute Lufteintrittsfeuchte am Ende der Betriebsstunde")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="xLaus      absolute Luftaustrittsfeuchte am Ende der Betriebsstunde")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="phiLein    relative Lufteintrittsfeuchte am Ende der Betriebsstunde")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="phiLaus    relative Luftaustrittsfeuchte am Ende der Betriebsstunde")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="mKon       ausgefallener Kondensatmassestrom w�hrend der Betriebsstunde")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="QLuft      mittlerer W�rmestrom w�hrend der Betriebsstunde an die str�mende Luft")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="QSpeicher  Speicherw�rme im Schotter bezogen auf die Lufteintrittstemperatur")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="           am Ende der Betriebsstunde")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="Hinweis zu den Ergebnissen: - bedeutet Stillstand des Speichers")
            .Selection.TypeParagraph()
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="Das letzte Temperaturfeld ist gespeichert in der Datei:")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:=Feld)
            .Selection.TypeParagraph()
        End With
    End Sub

    'RUNDUNGSFUNKTIONEN
    Public Function fo80(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.5 And x >= 0 Then fo80 = Format$(HG, "       0")
        If HG < 9.5 And x < 0 Then fo80 = Format$(HG, "      -0")
        If HG >= 9.5 And x >= 0 Then fo80 = Format$(HG, "      00")
        If HG >= 9.5 And x < 0 Then fo80 = Format$(HG, "     -00")
        If HG >= 99.5 And x >= 0 Then fo80 = Format$(HG, "     000")
        If HG >= 99.5 And x < 0 Then fo80 = Format$(HG, "    -000")
        If HG >= 999.5 And x >= 0 Then fo80 = Format$(HG, "    0000")
        If HG >= 999.5 And x < 0 Then fo80 = Format$(HG, "   -0000")
        If HG >= 9999.5 And x >= 0 Then fo80 = Format$(HG, "   00000")
        If HG >= 9999.5 And x < 0 Then fo80 = Format$(HG, "  -00000")
        If HG >= 99999.5 And x >= 0 Then fo80 = Format$(HG, "  000000")
        If HG >= 99999.5 And x < 0 Then fo80 = Format$(HG, " -000000")
        If HG >= 999999.5 And x >= 0 Then fo80 = Format$(HG, " 0000000")
        If HG >= 999999.5 And x < 0 Then fo80 = Format$(HG, "-0000000")
        If HG >= 9999999.5 And x >= 0 Then fo80 = Format$(HG, "00000000")
    End Function

    Public Function fo32(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.995 And x >= 0 Then fo32 = Format$(HG, "  0.00")
        If HG < 9.995 And x < 0 Then fo32 = Format$(HG, " -0.00")
        If HG >= 9.995 And x >= 0 Then fo32 = Format$(HG, " 00.00")
        If HG >= 9.995 And x < 0 Then fo32 = Format$(HG, "-00.00")
        If HG >= 99.995 And x >= 0 Then fo32 = Format$(HG, "000.00")
    End Function

    Public Function fo51(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.95 And x >= 0 Then fo51 = Format$(HG, "    0.0")
        If HG < 9.95 And x < 0 Then fo51 = Format$(HG, "   -0.0")
        If HG >= 9.95 And x >= 0 Then fo51 = Format$(HG, "   00.0")
        If HG >= 9.95 And x < 0 Then fo51 = Format$(HG, "  -00.0")
        If HG >= 99.95 And x >= 0 Then fo51 = Format$(HG, "  000.0")
        If HG >= 99.95 And x < 0 Then fo51 = Format$(HG, " -000.0")
        If HG >= 999.95 And x >= 0 Then fo51 = Format$(HG, " 0000.0")
        If HG >= 999.95 And x < 0 Then fo51 = Format$(HG, "-0000.0")
        If HG >= 9999.95 And x >= 0 Then fo51 = Format$(HG, "00000.0")
    End Function

    Public Function fo52(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.95 And x >= 0 Then fo52 = Format$(HG, "    0.00")
        If HG < 9.95 And x < 0 Then fo52 = Format$(HG, "   -0.00")
        If HG >= 9.95 And x >= 0 Then fo52 = Format$(HG, "   00.00")
        If HG >= 9.95 And x < 0 Then fo52 = Format$(HG, "  -00.00")
        If HG >= 99.95 And x >= 0 Then fo52 = Format$(HG, "  000.00")
        If HG >= 99.95 And x < 0 Then fo52 = Format$(HG, " -000.00")
        If HG >= 999.95 And x >= 0 Then fo52 = Format$(HG, " 0000.00")
        If HG >= 999.95 And x < 0 Then fo52 = Format$(HG, "-0000.00")
        If HG >= 9999.95 And x >= 0 Then fo52 = Format$(HG, "00000.00")
    End Function

    Public Function fo50(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.5 And x >= 0 Then fo50 = Format$(HG, "    0")
        If HG < 9.5 And x < 0 Then fo50 = Format$(HG, "   -0")
        If HG >= 9.5 And x >= 0 Then fo50 = Format$(HG, "   00")
        If HG >= 9.5 And x < 0 Then fo50 = Format$(HG, "  -00")
        If HG >= 99.5 And x >= 0 Then fo50 = Format$(HG, "  000")
        If HG >= 99.5 And x < 0 Then fo50 = Format$(HG, " -000")
        If HG >= 999.5 And x >= 0 Then fo50 = Format$(HG, " 0000")
        If HG >= 999.5 And x < 0 Then fo50 = Format$(HG, "-0000")
        If HG >= 9999.5 And x >= 0 Then fo50 = Format$(HG, "00000")
    End Function

    Public Function fo60(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.5 And x >= 0 Then fo60 = Format$(HG, "     0")
        If HG < 9.5 And x < 0 Then fo60 = Format$(HG, "    -0")
        If HG >= 9.5 And x >= 0 Then fo60 = Format$(HG, "    00")
        If HG >= 9.5 And x < 0 Then fo60 = Format$(HG, "   -00")
        If HG >= 99.5 And x >= 0 Then fo60 = Format$(HG, "   000")
        If HG >= 99.5 And x < 0 Then fo60 = Format$(HG, "  -000")
        If HG >= 999.5 And x >= 0 Then fo60 = Format$(HG, "  0000")
        If HG >= 999.5 And x < 0 Then fo60 = Format$(HG, " -0000")
        If HG >= 9999.5 And x >= 0 Then fo60 = Format$(HG, " 00000")
        If HG >= 9999.5 And x < 0 Then fo60 = Format$(HG, "-00000")
        If HG >= 99999.5 And x >= 0 Then fo60 = Format$(HG, "000000")
    End Function

    Public Function fo41(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.95 And x >= 0 Then fo41 = Format$(HG, "   0.0")
        If HG < 9.95 And x < 0 Then fo41 = Format$(HG, "  -0.0")
        If HG >= 9.95 And x >= 0 Then fo41 = Format$(HG, "  00.0")
        If HG >= 9.95 And x < 0 Then fo41 = Format$(HG, " -00.0")
        If HG >= 99.95 And x >= 0 Then fo41 = Format$(HG, " 000.0")
        If HG >= 99.95 And x < 0 Then fo41 = Format$(HG, "-000.0")
        If HG >= 999.95 And x >= 0 Then fo41 = Format$(HG, "0000.0")
    End Function

    Public Function fo011(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.95 And x >= 0 Then fo011 = Format$(HG, "0.0")
    End Function

    Public Function fo20(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.5 And x >= 0 Then fo20 = Format$(HG, " 0")
        If HG < 9.5 And x < 0 Then fo20 = Format$(HG, "-0")
        If HG >= 9.5 And x >= 0 Then fo20 = Format$(HG, "00")
    End Function

    Public Function fo31(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.95 And x >= 0 Then fo31 = Format$(HG, "  0.0")
        If HG < 9.95 And x < 0 Then fo31 = Format$(HG, " -0.0")
        If HG >= 9.95 And x >= 0 Then fo31 = Format$(HG, " 00.0")
        If HG >= 9.95 And x < 0 Then fo31 = Format$(HG, "-00.0")
        If HG >= 99.95 And x >= 0 Then fo31 = Format$(HG, "000.0")
    End Function

    Public Function fo012(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.995 And x >= 0 Then fo012 = Format$(HG, "0.00")
    End Function

    Public Function fo33(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.9995 And x >= 0 Then fo33 = Format$(HG, "  0.000")
        If HG < 9.9995 And x < 0 Then fo33 = Format$(HG, " -0.000")
        If HG >= 9.9995 And x >= 0 Then fo33 = Format$(HG, " 00.000")
        If HG >= 9.9995 And x < 0 Then fo33 = Format$(HG, "-00.000")
        If HG >= 99.9995 And x >= 0 Then fo33 = Format$(HG, "000.000")
    End Function

    Public Function fo35(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.999995 And x >= 0 Then fo35 = Format$(HG, "  0.00000")
        If HG < 9.999995 And x < 0 Then fo35 = Format$(HG, " -0.00000")
        If HG >= 9.999995 And x >= 0 Then fo35 = Format$(HG, " 00.00000")
        If HG >= 9.999995 And x < 0 Then fo35 = Format$(HG, "-00.00000")
        If HG >= 99.999995 And x >= 0 Then fo35 = Format$(HG, "000.00000")
    End Function

    Public Function fo34(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.99995 And x >= 0 Then fo34 = Format$(HG, "  0.0000")
        If HG < 9.99995 And x < 0 Then fo34 = Format$(HG, " -0.0000")
        If HG >= 9.99995 And x >= 0 Then fo34 = Format$(HG, " 00.0000")
        If HG >= 9.99995 And x < 0 Then fo34 = Format$(HG, "-00.0000")
        If HG >= 99.99995 And x >= 0 Then fo34 = Format$(HG, "000.0000")
    End Function

    Public Function fo22(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.995 And x >= 0 Then fo22 = Format$(HG, " 0.00")
        If HG < 9.995 And x < 0 Then fo22 = Format$(HG, "-0.00")
        If HG >= 9.995 And x >= 0 Then fo22 = Format$(HG, "00.00")
    End Function

    Public Function fo23(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.9995 And x >= 0 Then fo23 = Format$(HG, " 0.000")
        If HG < 9.9995 And x < 0 Then fo23 = Format$(HG, "-0.000")
        If HG >= 9.9995 And x >= 0 Then fo23 = Format$(HG, "00.000")
    End Function

    Public Function fo24(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.99995 And x >= 0 Then fo24 = Format$(HG, " 0.0000")
        If HG < 9.99995 And x < 0 Then fo24 = Format$(HG, "-0.0000")
        If HG >= 9.99995 And x >= 0 Then fo24 = Format$(HG, "00.0000")
    End Function

    Public Function fo30(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.5 And x >= 0 Then fo30 = Format$(HG, "  0")
        If HG < 9.5 And x < 0 Then fo30 = Format$(HG, " -0")
        If HG >= 9.5 And x >= 0 Then fo30 = Format$(HG, " 00")
        If HG >= 9.5 And x < 0 Then fo30 = Format$(HG, "-00")
        If HG >= 99.5 And x >= 0 Then fo30 = Format$(HG, "000")
    End Function

    Public Sub Testdruck()
        'Testdruck wird nur zu speziellen, programmintern aufgerufenen Kontrollen verwendet
        Dim wordapp, ccc As Object
        Dim Zeile, fo00, fo0, fo1, fo2, fo3, fo4, fo5, fo6, fo7, fo8, fo9, fo10, fo11, fo12, fo13, fo14, fo15, fo16, fo17, fo18, fo19 As String
        Dim k As Integer
        wordapp = CreateObject("Word.Application")         'Variable initialisieren
        If wordapp Is Nothing Then
            MsgBox("Konnte keine Verbindung zu Word herstellen!", 16, "Problem")
            Exit Sub
        End If
        With wordapp
            .Visible = True
            .Documents.Add()
            If .ActiveWindow.View.SplitSpecial <> 0 Then .ActiveWindow.Panes(2).Close()
            If .ActiveWindow.ActivePane.View.Type = 1 Or .ActiveWindow. _
                  ActivePane.View.Type = 2 Or .ActiveWindow.ActivePane.View.Type _
                   = 5 Then .ActiveWindow.ActivePane.View.Type = 3
            .ActiveWindow.ActivePane.View.SeekView = 0
            With .Selection.Font
                .Name = "Balloon Bd BT"
                .Size = 11
                .Bold = False
            End With
            .Selection.TypeText(Text:="Objektbezeichnung:  " + Objektbezeichnung)
            .Selection.TypeParagraph()

            'Kontrollausgabe f�r Zustandsdaten nach jeder Stunde
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 10
                .Bold = False
            End With
            i = 2
            p = 9
            s = 50
            fo0 = fo31(tau)
            fo00 = fo20(p)
            fo1 = fo20(i)
            .Selection.TypeText(Text:="Feldtemperaturen im Querschnitt in �C zur Zeit " + fo0 + " Uhr f�r Partikel " + fo00 + " in der Ebene i = " + fo1)
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Courier New"
                .Size = 6
                .Bold = False
            End With

            .Selection.TypeText(Text:="___________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:=" j   k = 6   k = 5   k = 4   k = 3   k = 2   k = 1    ")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="___________________________________________________")
            .Selection.TypeParagraph()

            For j = 6 To 1 Step -1
                fo00 = fo30(j)
                fo1 = fo34(tn(s, p, i, j, 6))
                fo2 = fo34(tn(s, p, i, j, 5))
                fo3 = fo34(tn(s, p, i, j, 4))
                fo4 = fo34(tn(s, p, i, j, 3))
                fo5 = fo34(tn(s, p, i, j, 2))
                fo6 = fo34(tn(s, p, i, j, 1))

                Zeile = fo00 + fo1 + fo2 + fo3 + fo4 + fo5 + fo6
                .Selection.TypeText(Text:=Zeile)
                .Selection.TypeParagraph()
            Next j
        End With
    End Sub

End Class
