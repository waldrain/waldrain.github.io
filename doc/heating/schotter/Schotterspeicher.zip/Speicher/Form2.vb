Public Class Form2
    Inherits System.Windows.Forms.Form
    Public Datei As String
    Public Objektbezeichnung As Object
    Public Stunde, ETag, Kontrolle, R(21, 25) As Integer
    Public VLanteil(21, 25), tLETag(21, 25), xLETag(21, 25), phiETag(21, 25) As Single
    Public pL, tstern, xstern, phistern As Single

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox125 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox120 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox126 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox127 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox103 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox104 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox105 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox106 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox107 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox108 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox109 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox110 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox111 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox112 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox113 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox114 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox115 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox116 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox117 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox118 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox121 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox122 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox123 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox124 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox178 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox179 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox180 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox181 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox182 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox183 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox184 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox185 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox186 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox187 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox188 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox189 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox190 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox191 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox192 As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents TextBox193 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox195 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox196 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox197 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox198 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox199 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox200 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox201 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox202 As System.Windows.Forms.TextBox
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.TextBox37 = New System.Windows.Forms.TextBox
        Me.TextBox19 = New System.Windows.Forms.TextBox
        Me.TextBox20 = New System.Windows.Forms.TextBox
        Me.TextBox21 = New System.Windows.Forms.TextBox
        Me.TextBox24 = New System.Windows.Forms.TextBox
        Me.TextBox25 = New System.Windows.Forms.TextBox
        Me.TextBox26 = New System.Windows.Forms.TextBox
        Me.TextBox27 = New System.Windows.Forms.TextBox
        Me.TextBox28 = New System.Windows.Forms.TextBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.TextBox11 = New System.Windows.Forms.TextBox
        Me.TextBox18 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.TextBox12 = New System.Windows.Forms.TextBox
        Me.TextBox36 = New System.Windows.Forms.TextBox
        Me.TextBox29 = New System.Windows.Forms.TextBox
        Me.TextBox30 = New System.Windows.Forms.TextBox
        Me.TextBox31 = New System.Windows.Forms.TextBox
        Me.TextBox32 = New System.Windows.Forms.TextBox
        Me.TextBox33 = New System.Windows.Forms.TextBox
        Me.TextBox34 = New System.Windows.Forms.TextBox
        Me.TextBox35 = New System.Windows.Forms.TextBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.TextBox125 = New System.Windows.Forms.TextBox
        Me.TextBox120 = New System.Windows.Forms.TextBox
        Me.TextBox126 = New System.Windows.Forms.TextBox
        Me.TextBox127 = New System.Windows.Forms.TextBox
        Me.TextBox103 = New System.Windows.Forms.TextBox
        Me.TextBox104 = New System.Windows.Forms.TextBox
        Me.TextBox105 = New System.Windows.Forms.TextBox
        Me.TextBox106 = New System.Windows.Forms.TextBox
        Me.TextBox107 = New System.Windows.Forms.TextBox
        Me.TextBox109 = New System.Windows.Forms.TextBox
        Me.TextBox110 = New System.Windows.Forms.TextBox
        Me.TextBox111 = New System.Windows.Forms.TextBox
        Me.TextBox112 = New System.Windows.Forms.TextBox
        Me.TextBox113 = New System.Windows.Forms.TextBox
        Me.TextBox114 = New System.Windows.Forms.TextBox
        Me.TextBox115 = New System.Windows.Forms.TextBox
        Me.TextBox116 = New System.Windows.Forms.TextBox
        Me.TextBox117 = New System.Windows.Forms.TextBox
        Me.TextBox118 = New System.Windows.Forms.TextBox
        Me.TextBox121 = New System.Windows.Forms.TextBox
        Me.TextBox122 = New System.Windows.Forms.TextBox
        Me.TextBox123 = New System.Windows.Forms.TextBox
        Me.TextBox124 = New System.Windows.Forms.TextBox
        Me.TextBox108 = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.TextBox178 = New System.Windows.Forms.TextBox
        Me.TextBox179 = New System.Windows.Forms.TextBox
        Me.TextBox180 = New System.Windows.Forms.TextBox
        Me.TextBox181 = New System.Windows.Forms.TextBox
        Me.TextBox182 = New System.Windows.Forms.TextBox
        Me.TextBox183 = New System.Windows.Forms.TextBox
        Me.TextBox184 = New System.Windows.Forms.TextBox
        Me.TextBox185 = New System.Windows.Forms.TextBox
        Me.TextBox186 = New System.Windows.Forms.TextBox
        Me.TextBox187 = New System.Windows.Forms.TextBox
        Me.TextBox188 = New System.Windows.Forms.TextBox
        Me.TextBox189 = New System.Windows.Forms.TextBox
        Me.TextBox190 = New System.Windows.Forms.TextBox
        Me.TextBox191 = New System.Windows.Forms.TextBox
        Me.TextBox192 = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.TextBox193 = New System.Windows.Forms.TextBox
        Me.TextBox195 = New System.Windows.Forms.TextBox
        Me.TextBox196 = New System.Windows.Forms.TextBox
        Me.TextBox197 = New System.Windows.Forms.TextBox
        Me.TextBox198 = New System.Windows.Forms.TextBox
        Me.TextBox199 = New System.Windows.Forms.TextBox
        Me.TextBox200 = New System.Windows.Forms.TextBox
        Me.TextBox201 = New System.Windows.Forms.TextBox
        Me.TextBox202 = New System.Windows.Forms.TextBox
        Me.Button9 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.TextBox38 = New System.Windows.Forms.TextBox
        Me.TextBox39 = New System.Windows.Forms.TextBox
        Me.TextBox40 = New System.Windows.Forms.TextBox
        Me.TextBox41 = New System.Windows.Forms.TextBox
        Me.TextBox42 = New System.Windows.Forms.TextBox
        Me.TextBox43 = New System.Windows.Forms.TextBox
        Me.TextBox44 = New System.Windows.Forms.TextBox
        Me.TextBox45 = New System.Windows.Forms.TextBox
        Me.TextBox46 = New System.Windows.Forms.TextBox
        Me.TextBox47 = New System.Windows.Forms.TextBox
        Me.TextBox48 = New System.Windows.Forms.TextBox
        Me.TextBox49 = New System.Windows.Forms.TextBox
        Me.TextBox50 = New System.Windows.Forms.TextBox
        Me.TextBox51 = New System.Windows.Forms.TextBox
        Me.TextBox52 = New System.Windows.Forms.TextBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.TextBox53 = New System.Windows.Forms.TextBox
        Me.TextBox55 = New System.Windows.Forms.TextBox
        Me.TextBox56 = New System.Windows.Forms.TextBox
        Me.TextBox57 = New System.Windows.Forms.TextBox
        Me.TextBox58 = New System.Windows.Forms.TextBox
        Me.TextBox59 = New System.Windows.Forms.TextBox
        Me.TextBox60 = New System.Windows.Forms.TextBox
        Me.TextBox61 = New System.Windows.Forms.TextBox
        Me.TextBox62 = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox14 = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.TextBox15 = New System.Windows.Forms.TextBox
        Me.Button4 = New System.Windows.Forms.Button
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(808, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(408, 23)
        Me.Label2.TabIndex = 553
        Me.Label2.Text = "Pfad und vorhandener bzw. zuk�nftiger Dateiname:"
        '
        'Label27
        '
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(568, 184)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(112, 32)
        Me.Label27.TabIndex = 556
        Me.Label27.Text = "Tagesstunde"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(192, Byte))
        Me.GroupBox2.Controls.Add(Me.TextBox37)
        Me.GroupBox2.Controls.Add(Me.TextBox19)
        Me.GroupBox2.Controls.Add(Me.TextBox20)
        Me.GroupBox2.Controls.Add(Me.TextBox21)
        Me.GroupBox2.Controls.Add(Me.TextBox24)
        Me.GroupBox2.Controls.Add(Me.TextBox25)
        Me.GroupBox2.Controls.Add(Me.TextBox26)
        Me.GroupBox2.Controls.Add(Me.TextBox27)
        Me.GroupBox2.Controls.Add(Me.TextBox28)
        Me.GroupBox2.Controls.Add(Me.TextBox8)
        Me.GroupBox2.Controls.Add(Me.TextBox10)
        Me.GroupBox2.Controls.Add(Me.TextBox11)
        Me.GroupBox2.Controls.Add(Me.TextBox18)
        Me.GroupBox2.Controls.Add(Me.TextBox2)
        Me.GroupBox2.Controls.Add(Me.TextBox3)
        Me.GroupBox2.Controls.Add(Me.Label34)
        Me.GroupBox2.Controls.Add(Me.TextBox12)
        Me.GroupBox2.Controls.Add(Me.TextBox36)
        Me.GroupBox2.Controls.Add(Me.TextBox29)
        Me.GroupBox2.Controls.Add(Me.TextBox30)
        Me.GroupBox2.Controls.Add(Me.TextBox31)
        Me.GroupBox2.Controls.Add(Me.TextBox32)
        Me.GroupBox2.Controls.Add(Me.TextBox33)
        Me.GroupBox2.Controls.Add(Me.TextBox34)
        Me.GroupBox2.Controls.Add(Me.TextBox35)
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(8, 392)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1216, 56)
        Me.GroupBox2.TabIndex = 557
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "VLanteil   Anteile des Luftvolumenstromes bezogen auf den Maximalwert (Eingabe im" & _
        " Hauptprogramm)"
        '
        'TextBox37
        '
        Me.TextBox37.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox37.ForeColor = System.Drawing.Color.Black
        Me.TextBox37.Location = New System.Drawing.Point(1168, 24)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(40, 24)
        Me.TextBox37.TabIndex = 407
        Me.TextBox37.Text = ""
        Me.TextBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox19
        '
        Me.TextBox19.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox19.ForeColor = System.Drawing.Color.Black
        Me.TextBox19.Location = New System.Drawing.Point(736, 24)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(40, 24)
        Me.TextBox19.TabIndex = 359
        Me.TextBox19.Text = ""
        Me.TextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox20
        '
        Me.TextBox20.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.ForeColor = System.Drawing.Color.Black
        Me.TextBox20.Location = New System.Drawing.Point(688, 24)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(40, 24)
        Me.TextBox20.TabIndex = 358
        Me.TextBox20.Text = ""
        Me.TextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox21
        '
        Me.TextBox21.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox21.ForeColor = System.Drawing.Color.Black
        Me.TextBox21.Location = New System.Drawing.Point(640, 24)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(40, 24)
        Me.TextBox21.TabIndex = 357
        Me.TextBox21.Text = ""
        Me.TextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox24
        '
        Me.TextBox24.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox24.ForeColor = System.Drawing.Color.Black
        Me.TextBox24.Location = New System.Drawing.Point(592, 24)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(40, 24)
        Me.TextBox24.TabIndex = 356
        Me.TextBox24.Text = ""
        Me.TextBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox25
        '
        Me.TextBox25.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox25.ForeColor = System.Drawing.Color.Black
        Me.TextBox25.Location = New System.Drawing.Point(544, 24)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(40, 24)
        Me.TextBox25.TabIndex = 355
        Me.TextBox25.Text = ""
        Me.TextBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox26
        '
        Me.TextBox26.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox26.ForeColor = System.Drawing.Color.Black
        Me.TextBox26.Location = New System.Drawing.Point(496, 24)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(40, 24)
        Me.TextBox26.TabIndex = 354
        Me.TextBox26.Text = ""
        Me.TextBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox27
        '
        Me.TextBox27.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox27.ForeColor = System.Drawing.Color.Black
        Me.TextBox27.Location = New System.Drawing.Point(448, 24)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(40, 24)
        Me.TextBox27.TabIndex = 353
        Me.TextBox27.Text = ""
        Me.TextBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox28
        '
        Me.TextBox28.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox28.ForeColor = System.Drawing.Color.Black
        Me.TextBox28.Location = New System.Drawing.Point(400, 24)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(40, 24)
        Me.TextBox28.TabIndex = 352
        Me.TextBox28.Text = ""
        Me.TextBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox8
        '
        Me.TextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.ForeColor = System.Drawing.Color.Black
        Me.TextBox8.Location = New System.Drawing.Point(352, 24)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(40, 24)
        Me.TextBox8.TabIndex = 351
        Me.TextBox8.Text = ""
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox10
        '
        Me.TextBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.ForeColor = System.Drawing.Color.Black
        Me.TextBox10.Location = New System.Drawing.Point(304, 24)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(40, 24)
        Me.TextBox10.TabIndex = 350
        Me.TextBox10.Text = ""
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox11
        '
        Me.TextBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.ForeColor = System.Drawing.Color.Black
        Me.TextBox11.Location = New System.Drawing.Point(256, 24)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(40, 24)
        Me.TextBox11.TabIndex = 349
        Me.TextBox11.Text = ""
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox18
        '
        Me.TextBox18.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox18.ForeColor = System.Drawing.Color.Black
        Me.TextBox18.Location = New System.Drawing.Point(208, 24)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(40, 24)
        Me.TextBox18.TabIndex = 348
        Me.TextBox18.Text = ""
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.Color.Black
        Me.TextBox2.Location = New System.Drawing.Point(160, 24)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(40, 24)
        Me.TextBox2.TabIndex = 347
        Me.TextBox2.Text = ""
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.ForeColor = System.Drawing.Color.Black
        Me.TextBox3.Location = New System.Drawing.Point(112, 24)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(40, 24)
        Me.TextBox3.TabIndex = 346
        Me.TextBox3.Text = ""
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label34
        '
        Me.Label34.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Black
        Me.Label34.Location = New System.Drawing.Point(248, 24)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(688, 0)
        Me.Label34.TabIndex = 345
        Me.Label34.Text = "rhoSI(i)"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'TextBox12
        '
        Me.TextBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.ForeColor = System.Drawing.Color.Black
        Me.TextBox12.Location = New System.Drawing.Point(64, 24)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(40, 24)
        Me.TextBox12.TabIndex = 343
        Me.TextBox12.Text = ""
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox36
        '
        Me.TextBox36.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox36.ForeColor = System.Drawing.Color.Black
        Me.TextBox36.Location = New System.Drawing.Point(784, 24)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(40, 24)
        Me.TextBox36.TabIndex = 399
        Me.TextBox36.Text = ""
        Me.TextBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox29
        '
        Me.TextBox29.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox29.ForeColor = System.Drawing.Color.Black
        Me.TextBox29.Location = New System.Drawing.Point(1120, 24)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(40, 24)
        Me.TextBox29.TabIndex = 406
        Me.TextBox29.Text = ""
        Me.TextBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox30
        '
        Me.TextBox30.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox30.ForeColor = System.Drawing.Color.Black
        Me.TextBox30.Location = New System.Drawing.Point(1072, 24)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(40, 24)
        Me.TextBox30.TabIndex = 405
        Me.TextBox30.Text = ""
        Me.TextBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox31
        '
        Me.TextBox31.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox31.ForeColor = System.Drawing.Color.Black
        Me.TextBox31.Location = New System.Drawing.Point(1024, 24)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(40, 24)
        Me.TextBox31.TabIndex = 404
        Me.TextBox31.Text = ""
        Me.TextBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox32
        '
        Me.TextBox32.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox32.ForeColor = System.Drawing.Color.Black
        Me.TextBox32.Location = New System.Drawing.Point(976, 24)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(40, 24)
        Me.TextBox32.TabIndex = 403
        Me.TextBox32.Text = ""
        Me.TextBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox33
        '
        Me.TextBox33.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox33.ForeColor = System.Drawing.Color.Black
        Me.TextBox33.Location = New System.Drawing.Point(928, 24)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(40, 24)
        Me.TextBox33.TabIndex = 402
        Me.TextBox33.Text = ""
        Me.TextBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox34
        '
        Me.TextBox34.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox34.ForeColor = System.Drawing.Color.Black
        Me.TextBox34.Location = New System.Drawing.Point(880, 24)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(40, 24)
        Me.TextBox34.TabIndex = 401
        Me.TextBox34.Text = ""
        Me.TextBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox35
        '
        Me.TextBox35.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox35.ForeColor = System.Drawing.Color.Black
        Me.TextBox35.Location = New System.Drawing.Point(832, 24)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(40, 24)
        Me.TextBox35.TabIndex = 400
        Me.TextBox35.Text = ""
        Me.TextBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label37
        '
        Me.Label37.ForeColor = System.Drawing.Color.Black
        Me.Label37.Location = New System.Drawing.Point(1176, 216)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(40, 32)
        Me.Label37.TabIndex = 585
        Me.Label37.Text = "24"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label38
        '
        Me.Label38.ForeColor = System.Drawing.Color.Black
        Me.Label38.Location = New System.Drawing.Point(1128, 216)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(40, 32)
        Me.Label38.TabIndex = 584
        Me.Label38.Text = "23"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label39
        '
        Me.Label39.ForeColor = System.Drawing.Color.Black
        Me.Label39.Location = New System.Drawing.Point(1080, 216)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(40, 32)
        Me.Label39.TabIndex = 583
        Me.Label39.Text = "22"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(936, 216)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(40, 32)
        Me.Label25.TabIndex = 580
        Me.Label25.Text = "19"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label26
        '
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(888, 216)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(40, 32)
        Me.Label26.TabIndex = 579
        Me.Label26.Text = "18"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label40
        '
        Me.Label40.ForeColor = System.Drawing.Color.Black
        Me.Label40.Location = New System.Drawing.Point(1032, 216)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(40, 32)
        Me.Label40.TabIndex = 582
        Me.Label40.Text = "21"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label41
        '
        Me.Label41.ForeColor = System.Drawing.Color.Black
        Me.Label41.Location = New System.Drawing.Point(984, 216)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(40, 32)
        Me.Label41.TabIndex = 581
        Me.Label41.Text = "20"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.ForeColor = System.Drawing.Color.Black
        Me.Label29.Location = New System.Drawing.Point(840, 216)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(40, 32)
        Me.Label29.TabIndex = 578
        Me.Label29.Text = "17"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(360, 216)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(40, 32)
        Me.Label11.TabIndex = 566
        Me.Label11.Text = "7"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(408, 216)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(40, 32)
        Me.Label10.TabIndex = 567
        Me.Label10.Text = "8"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label32
        '
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(792, 216)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(40, 32)
        Me.Label32.TabIndex = 577
        Me.Label32.Text = "16"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label36
        '
        Me.Label36.ForeColor = System.Drawing.Color.Black
        Me.Label36.Location = New System.Drawing.Point(744, 216)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(40, 32)
        Me.Label36.TabIndex = 576
        Me.Label36.Text = "15"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(696, 216)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(40, 32)
        Me.Label20.TabIndex = 575
        Me.Label20.Text = "14"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(648, 216)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(40, 32)
        Me.Label21.TabIndex = 574
        Me.Label21.Text = "13"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(456, 216)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(40, 32)
        Me.Label8.TabIndex = 568
        Me.Label8.Text = "9"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label22
        '
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(600, 216)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(40, 32)
        Me.Label22.TabIndex = 572
        Me.Label22.Text = "12"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(552, 216)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(40, 32)
        Me.Label23.TabIndex = 571
        Me.Label23.Text = "11"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label24
        '
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(504, 216)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(40, 32)
        Me.Label24.TabIndex = 569
        Me.Label24.Text = "10"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(312, 216)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(40, 32)
        Me.Label12.TabIndex = 565
        Me.Label12.Text = "6"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(264, 216)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(40, 32)
        Me.Label19.TabIndex = 564
        Me.Label19.Text = "5"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(216, 216)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 32)
        Me.Label7.TabIndex = 563
        Me.Label7.Text = "4"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(168, 216)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 32)
        Me.Label6.TabIndex = 562
        Me.Label6.Text = "3"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(120, 216)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 32)
        Me.Label5.TabIndex = 561
        Me.Label5.Text = "2"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(72, 216)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 32)
        Me.Label4.TabIndex = 560
        Me.Label4.Text = "1"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.Magenta
        Me.Button5.Location = New System.Drawing.Point(488, 648)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(232, 32)
        Me.Button5.TabIndex = 592
        Me.Button5.Text = "KONTROLLDRUCK"
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.Magenta
        Me.Button6.Location = New System.Drawing.Point(744, 648)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(232, 32)
        Me.Button6.TabIndex = 593
        Me.Button6.Text = "KONTROLLGRAFIK"
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.Magenta
        Me.Button7.Location = New System.Drawing.Point(992, 648)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(224, 32)
        Me.Button7.TabIndex = 594
        Me.Button7.Text = "BEENDEN"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Magenta
        Me.Button1.Location = New System.Drawing.Point(8, 648)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(224, 32)
        Me.Button1.TabIndex = 591
        Me.Button1.Text = "ANZEIGEN"
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(192, Byte))
        Me.GroupBox6.Controls.Add(Me.TextBox125)
        Me.GroupBox6.Controls.Add(Me.TextBox120)
        Me.GroupBox6.Controls.Add(Me.TextBox126)
        Me.GroupBox6.Controls.Add(Me.TextBox127)
        Me.GroupBox6.Controls.Add(Me.TextBox103)
        Me.GroupBox6.Controls.Add(Me.TextBox104)
        Me.GroupBox6.Controls.Add(Me.TextBox105)
        Me.GroupBox6.Controls.Add(Me.TextBox106)
        Me.GroupBox6.Controls.Add(Me.TextBox107)
        Me.GroupBox6.Controls.Add(Me.TextBox109)
        Me.GroupBox6.Controls.Add(Me.TextBox110)
        Me.GroupBox6.Controls.Add(Me.TextBox111)
        Me.GroupBox6.Controls.Add(Me.TextBox112)
        Me.GroupBox6.Controls.Add(Me.TextBox113)
        Me.GroupBox6.Controls.Add(Me.TextBox114)
        Me.GroupBox6.Controls.Add(Me.TextBox115)
        Me.GroupBox6.Controls.Add(Me.TextBox116)
        Me.GroupBox6.Controls.Add(Me.TextBox117)
        Me.GroupBox6.Controls.Add(Me.TextBox118)
        Me.GroupBox6.Controls.Add(Me.TextBox121)
        Me.GroupBox6.Controls.Add(Me.TextBox122)
        Me.GroupBox6.Controls.Add(Me.TextBox123)
        Me.GroupBox6.Controls.Add(Me.TextBox124)
        Me.GroupBox6.Controls.Add(Me.TextBox108)
        Me.GroupBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.ForeColor = System.Drawing.Color.Black
        Me.GroupBox6.Location = New System.Drawing.Point(8, 256)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(1216, 64)
        Me.GroupBox6.TabIndex = 573
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = " tL  Temperaturverlauf des Luftvolumenstromes  in �C"
        '
        'TextBox125
        '
        Me.TextBox125.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox125.ForeColor = System.Drawing.Color.Black
        Me.TextBox125.Location = New System.Drawing.Point(928, 24)
        Me.TextBox125.Name = "TextBox125"
        Me.TextBox125.Size = New System.Drawing.Size(40, 24)
        Me.TextBox125.TabIndex = 402
        Me.TextBox125.Text = ""
        Me.TextBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox120
        '
        Me.TextBox120.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox120.ForeColor = System.Drawing.Color.Black
        Me.TextBox120.Location = New System.Drawing.Point(784, 24)
        Me.TextBox120.Name = "TextBox120"
        Me.TextBox120.Size = New System.Drawing.Size(40, 24)
        Me.TextBox120.TabIndex = 399
        Me.TextBox120.Text = ""
        Me.TextBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox126
        '
        Me.TextBox126.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox126.ForeColor = System.Drawing.Color.Black
        Me.TextBox126.Location = New System.Drawing.Point(880, 24)
        Me.TextBox126.Name = "TextBox126"
        Me.TextBox126.Size = New System.Drawing.Size(40, 24)
        Me.TextBox126.TabIndex = 401
        Me.TextBox126.Text = ""
        Me.TextBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox127
        '
        Me.TextBox127.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox127.ForeColor = System.Drawing.Color.Black
        Me.TextBox127.Location = New System.Drawing.Point(832, 24)
        Me.TextBox127.Name = "TextBox127"
        Me.TextBox127.Size = New System.Drawing.Size(40, 24)
        Me.TextBox127.TabIndex = 400
        Me.TextBox127.Text = ""
        Me.TextBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox103
        '
        Me.TextBox103.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox103.ForeColor = System.Drawing.Color.Black
        Me.TextBox103.Location = New System.Drawing.Point(1168, 24)
        Me.TextBox103.Name = "TextBox103"
        Me.TextBox103.Size = New System.Drawing.Size(40, 24)
        Me.TextBox103.TabIndex = 407
        Me.TextBox103.Text = ""
        Me.TextBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox104
        '
        Me.TextBox104.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox104.ForeColor = System.Drawing.Color.Black
        Me.TextBox104.Location = New System.Drawing.Point(736, 24)
        Me.TextBox104.Name = "TextBox104"
        Me.TextBox104.Size = New System.Drawing.Size(40, 24)
        Me.TextBox104.TabIndex = 359
        Me.TextBox104.Text = ""
        Me.TextBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox105
        '
        Me.TextBox105.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox105.ForeColor = System.Drawing.Color.Black
        Me.TextBox105.Location = New System.Drawing.Point(688, 24)
        Me.TextBox105.Name = "TextBox105"
        Me.TextBox105.Size = New System.Drawing.Size(40, 24)
        Me.TextBox105.TabIndex = 358
        Me.TextBox105.Text = ""
        Me.TextBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox106
        '
        Me.TextBox106.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox106.ForeColor = System.Drawing.Color.Black
        Me.TextBox106.Location = New System.Drawing.Point(640, 24)
        Me.TextBox106.Name = "TextBox106"
        Me.TextBox106.Size = New System.Drawing.Size(40, 24)
        Me.TextBox106.TabIndex = 357
        Me.TextBox106.Text = ""
        Me.TextBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox107
        '
        Me.TextBox107.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox107.ForeColor = System.Drawing.Color.Black
        Me.TextBox107.Location = New System.Drawing.Point(592, 24)
        Me.TextBox107.Name = "TextBox107"
        Me.TextBox107.Size = New System.Drawing.Size(40, 24)
        Me.TextBox107.TabIndex = 356
        Me.TextBox107.Text = ""
        Me.TextBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox109
        '
        Me.TextBox109.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox109.ForeColor = System.Drawing.Color.Black
        Me.TextBox109.Location = New System.Drawing.Point(496, 24)
        Me.TextBox109.Name = "TextBox109"
        Me.TextBox109.Size = New System.Drawing.Size(40, 24)
        Me.TextBox109.TabIndex = 354
        Me.TextBox109.Text = ""
        Me.TextBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox110
        '
        Me.TextBox110.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox110.ForeColor = System.Drawing.Color.Black
        Me.TextBox110.Location = New System.Drawing.Point(448, 24)
        Me.TextBox110.Name = "TextBox110"
        Me.TextBox110.Size = New System.Drawing.Size(40, 24)
        Me.TextBox110.TabIndex = 353
        Me.TextBox110.Text = ""
        Me.TextBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox111
        '
        Me.TextBox111.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox111.ForeColor = System.Drawing.Color.Black
        Me.TextBox111.Location = New System.Drawing.Point(400, 24)
        Me.TextBox111.Name = "TextBox111"
        Me.TextBox111.Size = New System.Drawing.Size(40, 24)
        Me.TextBox111.TabIndex = 352
        Me.TextBox111.Text = ""
        Me.TextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox112
        '
        Me.TextBox112.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox112.ForeColor = System.Drawing.Color.Black
        Me.TextBox112.Location = New System.Drawing.Point(352, 24)
        Me.TextBox112.Name = "TextBox112"
        Me.TextBox112.Size = New System.Drawing.Size(40, 24)
        Me.TextBox112.TabIndex = 351
        Me.TextBox112.Text = ""
        Me.TextBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox113
        '
        Me.TextBox113.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox113.ForeColor = System.Drawing.Color.Black
        Me.TextBox113.Location = New System.Drawing.Point(304, 24)
        Me.TextBox113.Name = "TextBox113"
        Me.TextBox113.Size = New System.Drawing.Size(40, 24)
        Me.TextBox113.TabIndex = 350
        Me.TextBox113.Text = ""
        Me.TextBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox114
        '
        Me.TextBox114.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox114.ForeColor = System.Drawing.Color.Black
        Me.TextBox114.Location = New System.Drawing.Point(256, 24)
        Me.TextBox114.Name = "TextBox114"
        Me.TextBox114.Size = New System.Drawing.Size(40, 24)
        Me.TextBox114.TabIndex = 349
        Me.TextBox114.Text = ""
        Me.TextBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox115
        '
        Me.TextBox115.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox115.ForeColor = System.Drawing.Color.Black
        Me.TextBox115.Location = New System.Drawing.Point(208, 24)
        Me.TextBox115.Name = "TextBox115"
        Me.TextBox115.Size = New System.Drawing.Size(40, 24)
        Me.TextBox115.TabIndex = 348
        Me.TextBox115.Text = ""
        Me.TextBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox116
        '
        Me.TextBox116.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox116.ForeColor = System.Drawing.Color.Black
        Me.TextBox116.Location = New System.Drawing.Point(160, 24)
        Me.TextBox116.Name = "TextBox116"
        Me.TextBox116.Size = New System.Drawing.Size(40, 24)
        Me.TextBox116.TabIndex = 347
        Me.TextBox116.Text = ""
        Me.TextBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox117
        '
        Me.TextBox117.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox117.ForeColor = System.Drawing.Color.Black
        Me.TextBox117.Location = New System.Drawing.Point(112, 24)
        Me.TextBox117.Name = "TextBox117"
        Me.TextBox117.Size = New System.Drawing.Size(40, 24)
        Me.TextBox117.TabIndex = 346
        Me.TextBox117.Text = ""
        Me.TextBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox118
        '
        Me.TextBox118.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox118.ForeColor = System.Drawing.Color.Black
        Me.TextBox118.Location = New System.Drawing.Point(64, 24)
        Me.TextBox118.Name = "TextBox118"
        Me.TextBox118.Size = New System.Drawing.Size(40, 24)
        Me.TextBox118.TabIndex = 343
        Me.TextBox118.Text = ""
        Me.TextBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox121
        '
        Me.TextBox121.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox121.ForeColor = System.Drawing.Color.Black
        Me.TextBox121.Location = New System.Drawing.Point(1120, 24)
        Me.TextBox121.Name = "TextBox121"
        Me.TextBox121.Size = New System.Drawing.Size(40, 24)
        Me.TextBox121.TabIndex = 406
        Me.TextBox121.Text = ""
        Me.TextBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox122
        '
        Me.TextBox122.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox122.ForeColor = System.Drawing.Color.Black
        Me.TextBox122.Location = New System.Drawing.Point(1072, 24)
        Me.TextBox122.Name = "TextBox122"
        Me.TextBox122.Size = New System.Drawing.Size(40, 24)
        Me.TextBox122.TabIndex = 405
        Me.TextBox122.Text = ""
        Me.TextBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox123
        '
        Me.TextBox123.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox123.ForeColor = System.Drawing.Color.Black
        Me.TextBox123.Location = New System.Drawing.Point(1024, 24)
        Me.TextBox123.Name = "TextBox123"
        Me.TextBox123.Size = New System.Drawing.Size(40, 24)
        Me.TextBox123.TabIndex = 404
        Me.TextBox123.Text = ""
        Me.TextBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox124
        '
        Me.TextBox124.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox124.ForeColor = System.Drawing.Color.Black
        Me.TextBox124.Location = New System.Drawing.Point(976, 24)
        Me.TextBox124.Name = "TextBox124"
        Me.TextBox124.Size = New System.Drawing.Size(40, 24)
        Me.TextBox124.TabIndex = 403
        Me.TextBox124.Text = ""
        Me.TextBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox108
        '
        Me.TextBox108.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox108.ForeColor = System.Drawing.Color.Black
        Me.TextBox108.Location = New System.Drawing.Point(544, 24)
        Me.TextBox108.Name = "TextBox108"
        Me.TextBox108.Size = New System.Drawing.Size(40, 24)
        Me.TextBox108.TabIndex = 355
        Me.TextBox108.Text = ""
        Me.TextBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Label18.Location = New System.Drawing.Point(16, 560)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(568, 56)
        Me.Label18.TabIndex = 590
        Me.Label18.Text = "ANZEIGEN dr�cken!   Daten �berschreiben (nur Zahlen, Komma, Minuszeichen)!       " & _
        "       DATENSPEICHERUNG dr�cken!                                                " & _
        "                                          Evtl. KONTROLLDRUCK und/oder KONTROLLG" & _
        "RAFIK erzeugen!"
        '
        'GroupBox9
        '
        Me.GroupBox9.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(192, Byte))
        Me.GroupBox9.Controls.Add(Me.TextBox178)
        Me.GroupBox9.Controls.Add(Me.TextBox179)
        Me.GroupBox9.Controls.Add(Me.TextBox180)
        Me.GroupBox9.Controls.Add(Me.TextBox181)
        Me.GroupBox9.Controls.Add(Me.TextBox182)
        Me.GroupBox9.Controls.Add(Me.TextBox183)
        Me.GroupBox9.Controls.Add(Me.TextBox184)
        Me.GroupBox9.Controls.Add(Me.TextBox185)
        Me.GroupBox9.Controls.Add(Me.TextBox186)
        Me.GroupBox9.Controls.Add(Me.TextBox187)
        Me.GroupBox9.Controls.Add(Me.TextBox188)
        Me.GroupBox9.Controls.Add(Me.TextBox189)
        Me.GroupBox9.Controls.Add(Me.TextBox190)
        Me.GroupBox9.Controls.Add(Me.TextBox191)
        Me.GroupBox9.Controls.Add(Me.TextBox192)
        Me.GroupBox9.Controls.Add(Me.Label35)
        Me.GroupBox9.Controls.Add(Me.TextBox193)
        Me.GroupBox9.Controls.Add(Me.TextBox195)
        Me.GroupBox9.Controls.Add(Me.TextBox196)
        Me.GroupBox9.Controls.Add(Me.TextBox197)
        Me.GroupBox9.Controls.Add(Me.TextBox198)
        Me.GroupBox9.Controls.Add(Me.TextBox199)
        Me.GroupBox9.Controls.Add(Me.TextBox200)
        Me.GroupBox9.Controls.Add(Me.TextBox201)
        Me.GroupBox9.Controls.Add(Me.TextBox202)
        Me.GroupBox9.ForeColor = System.Drawing.Color.Black
        Me.GroupBox9.Location = New System.Drawing.Point(8, 328)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(1216, 56)
        Me.GroupBox9.TabIndex = 587
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "xL  Absolute Luftfeuchte des Luftvolumenstromes  in g_Wasser / kg_trockene Luft"
        '
        'TextBox178
        '
        Me.TextBox178.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox178.ForeColor = System.Drawing.Color.Black
        Me.TextBox178.Location = New System.Drawing.Point(1168, 24)
        Me.TextBox178.Name = "TextBox178"
        Me.TextBox178.Size = New System.Drawing.Size(40, 24)
        Me.TextBox178.TabIndex = 407
        Me.TextBox178.Text = ""
        Me.TextBox178.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox179
        '
        Me.TextBox179.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox179.ForeColor = System.Drawing.Color.Black
        Me.TextBox179.Location = New System.Drawing.Point(736, 24)
        Me.TextBox179.Name = "TextBox179"
        Me.TextBox179.Size = New System.Drawing.Size(40, 24)
        Me.TextBox179.TabIndex = 359
        Me.TextBox179.Text = ""
        Me.TextBox179.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox180
        '
        Me.TextBox180.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox180.ForeColor = System.Drawing.Color.Black
        Me.TextBox180.Location = New System.Drawing.Point(688, 24)
        Me.TextBox180.Name = "TextBox180"
        Me.TextBox180.Size = New System.Drawing.Size(40, 24)
        Me.TextBox180.TabIndex = 358
        Me.TextBox180.Text = ""
        Me.TextBox180.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox181
        '
        Me.TextBox181.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox181.ForeColor = System.Drawing.Color.Black
        Me.TextBox181.Location = New System.Drawing.Point(640, 24)
        Me.TextBox181.Name = "TextBox181"
        Me.TextBox181.Size = New System.Drawing.Size(40, 24)
        Me.TextBox181.TabIndex = 357
        Me.TextBox181.Text = ""
        Me.TextBox181.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox182
        '
        Me.TextBox182.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox182.ForeColor = System.Drawing.Color.Black
        Me.TextBox182.Location = New System.Drawing.Point(592, 24)
        Me.TextBox182.Name = "TextBox182"
        Me.TextBox182.Size = New System.Drawing.Size(40, 24)
        Me.TextBox182.TabIndex = 356
        Me.TextBox182.Text = ""
        Me.TextBox182.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox183
        '
        Me.TextBox183.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox183.ForeColor = System.Drawing.Color.Black
        Me.TextBox183.Location = New System.Drawing.Point(544, 24)
        Me.TextBox183.Name = "TextBox183"
        Me.TextBox183.Size = New System.Drawing.Size(40, 24)
        Me.TextBox183.TabIndex = 355
        Me.TextBox183.Text = ""
        Me.TextBox183.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox184
        '
        Me.TextBox184.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox184.ForeColor = System.Drawing.Color.Black
        Me.TextBox184.Location = New System.Drawing.Point(496, 24)
        Me.TextBox184.Name = "TextBox184"
        Me.TextBox184.Size = New System.Drawing.Size(40, 24)
        Me.TextBox184.TabIndex = 354
        Me.TextBox184.Text = ""
        Me.TextBox184.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox185
        '
        Me.TextBox185.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox185.ForeColor = System.Drawing.Color.Black
        Me.TextBox185.Location = New System.Drawing.Point(448, 24)
        Me.TextBox185.Name = "TextBox185"
        Me.TextBox185.Size = New System.Drawing.Size(40, 24)
        Me.TextBox185.TabIndex = 353
        Me.TextBox185.Text = ""
        Me.TextBox185.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox186
        '
        Me.TextBox186.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox186.ForeColor = System.Drawing.Color.Black
        Me.TextBox186.Location = New System.Drawing.Point(400, 24)
        Me.TextBox186.Name = "TextBox186"
        Me.TextBox186.Size = New System.Drawing.Size(40, 24)
        Me.TextBox186.TabIndex = 352
        Me.TextBox186.Text = ""
        Me.TextBox186.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox187
        '
        Me.TextBox187.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox187.ForeColor = System.Drawing.Color.Black
        Me.TextBox187.Location = New System.Drawing.Point(352, 24)
        Me.TextBox187.Name = "TextBox187"
        Me.TextBox187.Size = New System.Drawing.Size(40, 24)
        Me.TextBox187.TabIndex = 351
        Me.TextBox187.Text = ""
        Me.TextBox187.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox188
        '
        Me.TextBox188.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox188.ForeColor = System.Drawing.Color.Black
        Me.TextBox188.Location = New System.Drawing.Point(304, 24)
        Me.TextBox188.Name = "TextBox188"
        Me.TextBox188.Size = New System.Drawing.Size(40, 24)
        Me.TextBox188.TabIndex = 350
        Me.TextBox188.Text = ""
        Me.TextBox188.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox189
        '
        Me.TextBox189.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox189.ForeColor = System.Drawing.Color.Black
        Me.TextBox189.Location = New System.Drawing.Point(256, 24)
        Me.TextBox189.Name = "TextBox189"
        Me.TextBox189.Size = New System.Drawing.Size(40, 24)
        Me.TextBox189.TabIndex = 349
        Me.TextBox189.Text = ""
        Me.TextBox189.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox190
        '
        Me.TextBox190.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox190.ForeColor = System.Drawing.Color.Black
        Me.TextBox190.Location = New System.Drawing.Point(208, 24)
        Me.TextBox190.Name = "TextBox190"
        Me.TextBox190.Size = New System.Drawing.Size(40, 24)
        Me.TextBox190.TabIndex = 348
        Me.TextBox190.Text = ""
        Me.TextBox190.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox191
        '
        Me.TextBox191.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox191.ForeColor = System.Drawing.Color.Black
        Me.TextBox191.Location = New System.Drawing.Point(160, 24)
        Me.TextBox191.Name = "TextBox191"
        Me.TextBox191.Size = New System.Drawing.Size(40, 24)
        Me.TextBox191.TabIndex = 347
        Me.TextBox191.Text = ""
        Me.TextBox191.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox192
        '
        Me.TextBox192.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox192.ForeColor = System.Drawing.Color.Black
        Me.TextBox192.Location = New System.Drawing.Point(112, 24)
        Me.TextBox192.Name = "TextBox192"
        Me.TextBox192.Size = New System.Drawing.Size(40, 24)
        Me.TextBox192.TabIndex = 346
        Me.TextBox192.Text = ""
        Me.TextBox192.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label35
        '
        Me.Label35.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Black
        Me.Label35.Location = New System.Drawing.Point(256, 24)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(688, 0)
        Me.Label35.TabIndex = 345
        Me.Label35.Text = "rhoSI(i)"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'TextBox193
        '
        Me.TextBox193.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox193.ForeColor = System.Drawing.Color.Black
        Me.TextBox193.Location = New System.Drawing.Point(64, 24)
        Me.TextBox193.Name = "TextBox193"
        Me.TextBox193.Size = New System.Drawing.Size(40, 24)
        Me.TextBox193.TabIndex = 343
        Me.TextBox193.Text = ""
        Me.TextBox193.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox195
        '
        Me.TextBox195.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox195.ForeColor = System.Drawing.Color.Black
        Me.TextBox195.Location = New System.Drawing.Point(784, 24)
        Me.TextBox195.Name = "TextBox195"
        Me.TextBox195.Size = New System.Drawing.Size(40, 24)
        Me.TextBox195.TabIndex = 399
        Me.TextBox195.Text = ""
        Me.TextBox195.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox196
        '
        Me.TextBox196.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox196.ForeColor = System.Drawing.Color.Black
        Me.TextBox196.Location = New System.Drawing.Point(1120, 24)
        Me.TextBox196.Name = "TextBox196"
        Me.TextBox196.Size = New System.Drawing.Size(40, 24)
        Me.TextBox196.TabIndex = 406
        Me.TextBox196.Text = ""
        Me.TextBox196.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox197
        '
        Me.TextBox197.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox197.ForeColor = System.Drawing.Color.Black
        Me.TextBox197.Location = New System.Drawing.Point(1072, 24)
        Me.TextBox197.Name = "TextBox197"
        Me.TextBox197.Size = New System.Drawing.Size(40, 24)
        Me.TextBox197.TabIndex = 405
        Me.TextBox197.Text = ""
        Me.TextBox197.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox198
        '
        Me.TextBox198.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox198.ForeColor = System.Drawing.Color.Black
        Me.TextBox198.Location = New System.Drawing.Point(1024, 24)
        Me.TextBox198.Name = "TextBox198"
        Me.TextBox198.Size = New System.Drawing.Size(40, 24)
        Me.TextBox198.TabIndex = 404
        Me.TextBox198.Text = ""
        Me.TextBox198.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox199
        '
        Me.TextBox199.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox199.ForeColor = System.Drawing.Color.Black
        Me.TextBox199.Location = New System.Drawing.Point(976, 24)
        Me.TextBox199.Name = "TextBox199"
        Me.TextBox199.Size = New System.Drawing.Size(40, 24)
        Me.TextBox199.TabIndex = 403
        Me.TextBox199.Text = ""
        Me.TextBox199.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox200
        '
        Me.TextBox200.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox200.ForeColor = System.Drawing.Color.Black
        Me.TextBox200.Location = New System.Drawing.Point(928, 24)
        Me.TextBox200.Name = "TextBox200"
        Me.TextBox200.Size = New System.Drawing.Size(40, 24)
        Me.TextBox200.TabIndex = 402
        Me.TextBox200.Text = ""
        Me.TextBox200.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox201
        '
        Me.TextBox201.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox201.ForeColor = System.Drawing.Color.Black
        Me.TextBox201.Location = New System.Drawing.Point(880, 24)
        Me.TextBox201.Name = "TextBox201"
        Me.TextBox201.Size = New System.Drawing.Size(40, 24)
        Me.TextBox201.TabIndex = 401
        Me.TextBox201.Text = ""
        Me.TextBox201.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox202
        '
        Me.TextBox202.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox202.ForeColor = System.Drawing.Color.Black
        Me.TextBox202.Location = New System.Drawing.Point(832, 24)
        Me.TextBox202.Name = "TextBox202"
        Me.TextBox202.Size = New System.Drawing.Size(40, 24)
        Me.TextBox202.TabIndex = 400
        Me.TextBox202.Text = ""
        Me.TextBox202.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.Magenta
        Me.Button9.Location = New System.Drawing.Point(248, 648)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(224, 32)
        Me.Button9.TabIndex = 589
        Me.Button9.Text = "DATENSPEICHERUNG"
        '
        'Label1
        '
        Me.Label1.ForeColor = System.Drawing.Color.Magenta
        Me.Label1.Location = New System.Drawing.Point(8, 184)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 24)
        Me.Label1.TabIndex = 595
        Me.Label1.Text = "Entwurfstag"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.GroupBox3.Controls.Add(Me.TextBox38)
        Me.GroupBox3.Controls.Add(Me.TextBox39)
        Me.GroupBox3.Controls.Add(Me.TextBox40)
        Me.GroupBox3.Controls.Add(Me.TextBox41)
        Me.GroupBox3.Controls.Add(Me.TextBox42)
        Me.GroupBox3.Controls.Add(Me.TextBox43)
        Me.GroupBox3.Controls.Add(Me.TextBox44)
        Me.GroupBox3.Controls.Add(Me.TextBox45)
        Me.GroupBox3.Controls.Add(Me.TextBox46)
        Me.GroupBox3.Controls.Add(Me.TextBox47)
        Me.GroupBox3.Controls.Add(Me.TextBox48)
        Me.GroupBox3.Controls.Add(Me.TextBox49)
        Me.GroupBox3.Controls.Add(Me.TextBox50)
        Me.GroupBox3.Controls.Add(Me.TextBox51)
        Me.GroupBox3.Controls.Add(Me.TextBox52)
        Me.GroupBox3.Controls.Add(Me.Label42)
        Me.GroupBox3.Controls.Add(Me.TextBox53)
        Me.GroupBox3.Controls.Add(Me.TextBox55)
        Me.GroupBox3.Controls.Add(Me.TextBox56)
        Me.GroupBox3.Controls.Add(Me.TextBox57)
        Me.GroupBox3.Controls.Add(Me.TextBox58)
        Me.GroupBox3.Controls.Add(Me.TextBox59)
        Me.GroupBox3.Controls.Add(Me.TextBox60)
        Me.GroupBox3.Controls.Add(Me.TextBox61)
        Me.GroupBox3.Controls.Add(Me.TextBox62)
        Me.GroupBox3.ForeColor = System.Drawing.Color.Black
        Me.GroupBox3.Location = New System.Drawing.Point(8, 456)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(1216, 56)
        Me.GroupBox3.TabIndex = 570
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Richtung des Luftvolumenstromes durch den Schotterspeicher (Normalrichtung 1; Geg" & _
        "enrichtung -1; Stillstand 0)"
        '
        'TextBox38
        '
        Me.TextBox38.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox38.ForeColor = System.Drawing.Color.Black
        Me.TextBox38.Location = New System.Drawing.Point(1168, 24)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(40, 24)
        Me.TextBox38.TabIndex = 407
        Me.TextBox38.Text = ""
        Me.TextBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox39
        '
        Me.TextBox39.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox39.ForeColor = System.Drawing.Color.Black
        Me.TextBox39.Location = New System.Drawing.Point(736, 24)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(40, 24)
        Me.TextBox39.TabIndex = 359
        Me.TextBox39.Text = ""
        Me.TextBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox40
        '
        Me.TextBox40.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox40.ForeColor = System.Drawing.Color.Black
        Me.TextBox40.Location = New System.Drawing.Point(688, 24)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(40, 24)
        Me.TextBox40.TabIndex = 358
        Me.TextBox40.Text = ""
        Me.TextBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox41
        '
        Me.TextBox41.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox41.ForeColor = System.Drawing.Color.Black
        Me.TextBox41.Location = New System.Drawing.Point(640, 24)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(40, 24)
        Me.TextBox41.TabIndex = 357
        Me.TextBox41.Text = ""
        Me.TextBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox42
        '
        Me.TextBox42.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox42.ForeColor = System.Drawing.Color.Black
        Me.TextBox42.Location = New System.Drawing.Point(592, 24)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(40, 24)
        Me.TextBox42.TabIndex = 356
        Me.TextBox42.Text = ""
        Me.TextBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox43
        '
        Me.TextBox43.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox43.ForeColor = System.Drawing.Color.Black
        Me.TextBox43.Location = New System.Drawing.Point(544, 24)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(40, 24)
        Me.TextBox43.TabIndex = 355
        Me.TextBox43.Text = ""
        Me.TextBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox44
        '
        Me.TextBox44.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox44.ForeColor = System.Drawing.Color.Black
        Me.TextBox44.Location = New System.Drawing.Point(496, 24)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(40, 24)
        Me.TextBox44.TabIndex = 354
        Me.TextBox44.Text = ""
        Me.TextBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox45
        '
        Me.TextBox45.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox45.ForeColor = System.Drawing.Color.Black
        Me.TextBox45.Location = New System.Drawing.Point(448, 24)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(40, 24)
        Me.TextBox45.TabIndex = 353
        Me.TextBox45.Text = ""
        Me.TextBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox46
        '
        Me.TextBox46.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox46.ForeColor = System.Drawing.Color.Black
        Me.TextBox46.Location = New System.Drawing.Point(400, 24)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(40, 24)
        Me.TextBox46.TabIndex = 352
        Me.TextBox46.Text = ""
        Me.TextBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox47
        '
        Me.TextBox47.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox47.ForeColor = System.Drawing.Color.Black
        Me.TextBox47.Location = New System.Drawing.Point(352, 24)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(40, 24)
        Me.TextBox47.TabIndex = 351
        Me.TextBox47.Text = ""
        Me.TextBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox48
        '
        Me.TextBox48.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox48.ForeColor = System.Drawing.Color.Black
        Me.TextBox48.Location = New System.Drawing.Point(304, 24)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(40, 24)
        Me.TextBox48.TabIndex = 350
        Me.TextBox48.Text = ""
        Me.TextBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox49
        '
        Me.TextBox49.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox49.ForeColor = System.Drawing.Color.Black
        Me.TextBox49.Location = New System.Drawing.Point(256, 24)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(40, 24)
        Me.TextBox49.TabIndex = 349
        Me.TextBox49.Text = ""
        Me.TextBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox50
        '
        Me.TextBox50.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox50.ForeColor = System.Drawing.Color.Black
        Me.TextBox50.Location = New System.Drawing.Point(208, 24)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(40, 24)
        Me.TextBox50.TabIndex = 348
        Me.TextBox50.Text = ""
        Me.TextBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox51
        '
        Me.TextBox51.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox51.ForeColor = System.Drawing.Color.Black
        Me.TextBox51.Location = New System.Drawing.Point(160, 24)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(40, 24)
        Me.TextBox51.TabIndex = 347
        Me.TextBox51.Text = ""
        Me.TextBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox52
        '
        Me.TextBox52.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox52.ForeColor = System.Drawing.Color.Black
        Me.TextBox52.Location = New System.Drawing.Point(112, 24)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(40, 24)
        Me.TextBox52.TabIndex = 346
        Me.TextBox52.Text = ""
        Me.TextBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label42
        '
        Me.Label42.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label42.BackColor = System.Drawing.SystemColors.Window
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(256, 24)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(688, 0)
        Me.Label42.TabIndex = 345
        Me.Label42.Text = "rhoSI(i)"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'TextBox53
        '
        Me.TextBox53.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox53.ForeColor = System.Drawing.Color.Black
        Me.TextBox53.Location = New System.Drawing.Point(64, 24)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(40, 24)
        Me.TextBox53.TabIndex = 343
        Me.TextBox53.Text = ""
        Me.TextBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox55
        '
        Me.TextBox55.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox55.ForeColor = System.Drawing.Color.Black
        Me.TextBox55.Location = New System.Drawing.Point(784, 24)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(40, 24)
        Me.TextBox55.TabIndex = 399
        Me.TextBox55.Text = ""
        Me.TextBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox56
        '
        Me.TextBox56.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox56.ForeColor = System.Drawing.Color.Black
        Me.TextBox56.Location = New System.Drawing.Point(1120, 24)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(40, 24)
        Me.TextBox56.TabIndex = 406
        Me.TextBox56.Text = ""
        Me.TextBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox57
        '
        Me.TextBox57.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox57.ForeColor = System.Drawing.Color.Black
        Me.TextBox57.Location = New System.Drawing.Point(1072, 24)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(40, 24)
        Me.TextBox57.TabIndex = 405
        Me.TextBox57.Text = ""
        Me.TextBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox58
        '
        Me.TextBox58.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox58.ForeColor = System.Drawing.Color.Black
        Me.TextBox58.Location = New System.Drawing.Point(1024, 24)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(40, 24)
        Me.TextBox58.TabIndex = 404
        Me.TextBox58.Text = ""
        Me.TextBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox59
        '
        Me.TextBox59.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox59.ForeColor = System.Drawing.Color.Black
        Me.TextBox59.Location = New System.Drawing.Point(976, 24)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(40, 24)
        Me.TextBox59.TabIndex = 403
        Me.TextBox59.Text = ""
        Me.TextBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox60
        '
        Me.TextBox60.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox60.ForeColor = System.Drawing.Color.Black
        Me.TextBox60.Location = New System.Drawing.Point(928, 24)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(40, 24)
        Me.TextBox60.TabIndex = 402
        Me.TextBox60.Text = ""
        Me.TextBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox61
        '
        Me.TextBox61.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox61.ForeColor = System.Drawing.Color.Black
        Me.TextBox61.Location = New System.Drawing.Point(880, 24)
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(40, 24)
        Me.TextBox61.TabIndex = 401
        Me.TextBox61.Text = ""
        Me.TextBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox62
        '
        Me.TextBox62.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox62.ForeColor = System.Drawing.Color.Black
        Me.TextBox62.Location = New System.Drawing.Point(832, 24)
        Me.TextBox62.Name = "TextBox62"
        Me.TextBox62.Size = New System.Drawing.Size(40, 24)
        Me.TextBox62.TabIndex = 400
        Me.TextBox62.Text = ""
        Me.TextBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.Magenta
        Me.TextBox1.Location = New System.Drawing.Point(136, 184)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(40, 27)
        Me.TextBox1.TabIndex = 552
        Me.TextBox1.Text = ""
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(808, 56)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(408, 27)
        Me.TextBox14.TabIndex = 554
        Me.TextBox14.Text = ""
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Controls.Add(Me.TextBox15)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.ForeColor = System.Drawing.Color.Magenta
        Me.GroupBox1.Location = New System.Drawing.Point(8, 16)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(448, 120)
        Me.GroupBox1.TabIndex = 596
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Zielstellung"
        '
        'RadioButton2
        '
        Me.RadioButton2.Location = New System.Drawing.Point(8, 56)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(432, 24)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.Text = "Neueingabe der Daten (Datei noch nicht vorhanden)"
        '
        'RadioButton1
        '
        Me.RadioButton1.Location = New System.Drawing.Point(8, 24)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(280, 24)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "Kontrolle bzw. Datenerg�nzung "
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(8, 88)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(288, 27)
        Me.TextBox15.TabIndex = 53
        Me.TextBox15.Text = ""
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.Black
        Me.Button4.Location = New System.Drawing.Point(320, 80)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(96, 32)
        Me.Button4.TabIndex = 53
        Me.Button4.Text = "WEITER"
        '
        'Form2
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 20)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.ClientSize = New System.Drawing.Size(1230, 683)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TextBox14)
        Me.Name = "Form2"
        Me.Text = "Zeitverl�ufe bezogen auf die Entwurfstage"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox15.Text = "Bitte Button setzen!"
        Kontrolle = 0
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        'Steuerung der Datenneueingabe bzw. der Datenerg�nzung
        If RadioButton1.Checked = False And RadioButton2.Checked = False Then
            Me.Close()
        Else
            TextBox15.Text = ""
        End If
        If RadioButton1.Checked = True Then
            Call EINGABELADUNG2()
            TextBox1.Text = 1
        End If
        If RadioButton2.Checked = True Then Call NULLEINTRAG2()
        Kontrolle = 1
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Datenanzeige
        If Kontrolle = 0 Then GoTo Label1_End
        ETag = CType(TextBox1.Text, Integer)
        Call EINTRAG2()
Label1_End:
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        'Datenspeicherung
        If Kontrolle = 0 Then GoTo Label9_End
        Call MASKELESEN2()
        'Werte f�r Konstante
        pL = 100000                  'Luftdruck
        For ETag = 1 To 20
            For Stunde = 1 To 24
                tstern = tLETag(ETag, Stunde)
                If tstern = -273 Then
                    phiETag(ETag, Stunde) = 0
                Else
                    xstern = xLETag(ETag, Stunde) / 1000
                    Call ZUSTAND()
                    phiETag(ETag, Stunde) = phistern
                End If
            Next Stunde
        Next ETag
        Call EINGABESPEICHERUNG2()
Label9_End:
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        'Ausgabe der Temperaturverl�ufe
        If Kontrolle = 0 Then GoTo Label6_End
        Dim f As New Form4
        f.TextBox14.Text = Objektbezeichnung + "ZVerlauf.dat + ERGEBNIS.dat"
        f.Objektbezeichnung = Objektbezeichnung
        f.Show()
Label6_End:
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        'Erzeugen eines Kontrolldruckes
        If Kontrolle = 0 Then GoTo Label5_End
        Call EINGABELADUNG2()
        ETag = CType(TextBox1.Text, Single)
        Call Kontrolldruck()
Label5_End:
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Me.Close()
    End Sub

    Private Sub EINTRAG2()
        TextBox1.Text = ETag
        TextBox12.Text = VLanteil(ETag, 1).ToString()
        TextBox3.Text = VLanteil(ETag, 2).ToString()
        TextBox2.Text = VLanteil(ETag, 3).ToString()
        TextBox18.Text = VLanteil(ETag, 4).ToString()
        TextBox11.Text = VLanteil(ETag, 5).ToString()
        TextBox10.Text = VLanteil(ETag, 6).ToString()
        TextBox8.Text = VLanteil(ETag, 7).ToString()
        TextBox28.Text = VLanteil(ETag, 8).ToString()
        TextBox27.Text = VLanteil(ETag, 9).ToString()
        TextBox26.Text = VLanteil(ETag, 10).ToString()
        TextBox25.Text = VLanteil(ETag, 11).ToString()
        TextBox24.Text = VLanteil(ETag, 12).ToString()
        TextBox21.Text = VLanteil(ETag, 13).ToString()
        TextBox20.Text = VLanteil(ETag, 14).ToString()
        TextBox19.Text = VLanteil(ETag, 15).ToString()
        TextBox36.Text = VLanteil(ETag, 16).ToString()
        TextBox35.Text = VLanteil(ETag, 17).ToString()
        TextBox34.Text = VLanteil(ETag, 18).ToString()
        TextBox33.Text = VLanteil(ETag, 19).ToString()
        TextBox32.Text = VLanteil(ETag, 20).ToString()
        TextBox31.Text = VLanteil(ETag, 21).ToString()
        TextBox30.Text = VLanteil(ETag, 22).ToString()
        TextBox29.Text = VLanteil(ETag, 23).ToString()
        TextBox37.Text = VLanteil(ETag, 24).ToString()

        TextBox53.Text = R(ETag, 1).ToString()
        TextBox52.Text = R(ETag, 2).ToString()
        TextBox51.Text = R(ETag, 3).ToString()
        TextBox50.Text = R(ETag, 4).ToString()
        TextBox49.Text = R(ETag, 5).ToString()
        TextBox48.Text = R(ETag, 6).ToString()
        TextBox47.Text = R(ETag, 7).ToString()
        TextBox46.Text = R(ETag, 8).ToString()
        TextBox45.Text = R(ETag, 9).ToString()
        TextBox44.Text = R(ETag, 10).ToString()
        TextBox43.Text = R(ETag, 11).ToString()
        TextBox42.Text = R(ETag, 12).ToString()
        TextBox41.Text = R(ETag, 13).ToString()
        TextBox40.Text = R(ETag, 14).ToString()
        TextBox39.Text = R(ETag, 15).ToString()
        TextBox55.Text = R(ETag, 16).ToString()
        TextBox62.Text = R(ETag, 17).ToString()
        TextBox61.Text = R(ETag, 18).ToString()
        TextBox60.Text = R(ETag, 19).ToString()
        TextBox59.Text = R(ETag, 20).ToString()
        TextBox58.Text = R(ETag, 21).ToString()
        TextBox57.Text = R(ETag, 22).ToString()
        TextBox56.Text = R(ETag, 23).ToString()
        TextBox38.Text = R(ETag, 24).ToString()

        TextBox118.Text = tLETag(ETag, 1).ToString()
        TextBox117.Text = tLETag(ETag, 2).ToString()
        TextBox116.Text = tLETag(ETag, 3).ToString()
        TextBox115.Text = tLETag(ETag, 4).ToString()
        TextBox114.Text = tLETag(ETag, 5).ToString()
        TextBox113.Text = tLETag(ETag, 6).ToString()
        TextBox112.Text = tLETag(ETag, 7).ToString()
        TextBox111.Text = tLETag(ETag, 8).ToString()
        TextBox110.Text = tLETag(ETag, 9).ToString()
        TextBox109.Text = tLETag(ETag, 10).ToString()
        TextBox108.Text = tLETag(ETag, 11).ToString()
        TextBox107.Text = tLETag(ETag, 12).ToString()
        TextBox106.Text = tLETag(ETag, 13).ToString()
        TextBox105.Text = tLETag(ETag, 14).ToString()
        TextBox104.Text = tLETag(ETag, 15).ToString()
        TextBox120.Text = tLETag(ETag, 16).ToString()
        TextBox127.Text = tLETag(ETag, 17).ToString()
        TextBox126.Text = tLETag(ETag, 18).ToString()
        TextBox125.Text = tLETag(ETag, 19).ToString()
        TextBox124.Text = tLETag(ETag, 20).ToString()
        TextBox123.Text = tLETag(ETag, 21).ToString()
        TextBox122.Text = tLETag(ETag, 22).ToString()
        TextBox121.Text = tLETag(ETag, 23).ToString()
        TextBox103.Text = tLETag(ETag, 24).ToString()

        TextBox193.Text = xLETag(ETag, 1).ToString()
        TextBox192.Text = xLETag(ETag, 2).ToString()
        TextBox191.Text = xLETag(ETag, 3).ToString()
        TextBox190.Text = xLETag(ETag, 4).ToString()
        TextBox189.Text = xLETag(ETag, 5).ToString()
        TextBox188.Text = xLETag(ETag, 6).ToString()
        TextBox187.Text = xLETag(ETag, 7).ToString()
        TextBox186.Text = xLETag(ETag, 8).ToString()
        TextBox185.Text = xLETag(ETag, 9).ToString()
        TextBox184.Text = xLETag(ETag, 10).ToString()
        TextBox183.Text = xLETag(ETag, 11).ToString()
        TextBox182.Text = xLETag(ETag, 12).ToString()
        TextBox181.Text = xLETag(ETag, 13).ToString()
        TextBox180.Text = xLETag(ETag, 14).ToString()
        TextBox179.Text = xLETag(ETag, 15).ToString()
        TextBox195.Text = xLETag(ETag, 16).ToString()
        TextBox202.Text = xLETag(ETag, 17).ToString()
        TextBox201.Text = xLETag(ETag, 18).ToString()
        TextBox200.Text = xLETag(ETag, 19).ToString()
        TextBox199.Text = xLETag(ETag, 20).ToString()
        TextBox198.Text = xLETag(ETag, 21).ToString()
        TextBox197.Text = xLETag(ETag, 22).ToString()
        TextBox196.Text = xLETag(ETag, 23).ToString()
        TextBox178.Text = xLETag(ETag, 24).ToString()
    End Sub

    Sub MASKELESEN2()
        ETag = CType(TextBox1.Text, Single)
        VLanteil(ETag, 1) = CType(TextBox12.Text, Single)
        VLanteil(ETag, 2) = CType(TextBox3.Text, Single)
        VLanteil(ETag, 3) = CType(TextBox2.Text, Single)
        VLanteil(ETag, 4) = CType(TextBox18.Text, Single)
        VLanteil(ETag, 5) = CType(TextBox11.Text, Single)
        VLanteil(ETag, 6) = CType(TextBox10.Text, Single)
        VLanteil(ETag, 7) = CType(TextBox8.Text, Single)
        VLanteil(ETag, 8) = CType(TextBox28.Text, Single)
        VLanteil(ETag, 9) = CType(TextBox27.Text, Single)
        VLanteil(ETag, 10) = CType(TextBox26.Text, Single)
        VLanteil(ETag, 11) = CType(TextBox25.Text, Single)
        VLanteil(ETag, 12) = CType(TextBox24.Text, Single)
        VLanteil(ETag, 13) = CType(TextBox21.Text, Single)
        VLanteil(ETag, 14) = CType(TextBox20.Text, Single)
        VLanteil(ETag, 15) = CType(TextBox19.Text, Single)
        VLanteil(ETag, 16) = CType(TextBox36.Text, Single)
        VLanteil(ETag, 17) = CType(TextBox35.Text, Single)
        VLanteil(ETag, 18) = CType(TextBox34.Text, Single)
        VLanteil(ETag, 19) = CType(TextBox33.Text, Single)
        VLanteil(ETag, 20) = CType(TextBox32.Text, Single)
        VLanteil(ETag, 21) = CType(TextBox31.Text, Single)
        VLanteil(ETag, 22) = CType(TextBox30.Text, Single)
        VLanteil(ETag, 23) = CType(TextBox29.Text, Single)
        VLanteil(ETag, 24) = CType(TextBox37.Text, Single)

        R(ETag, 1) = CType(TextBox53.Text, Integer)
        R(ETag, 2) = CType(TextBox52.Text, Integer)
        R(ETag, 3) = CType(TextBox51.Text, Integer)
        R(ETag, 4) = CType(TextBox50.Text, Integer)
        R(ETag, 5) = CType(TextBox49.Text, Integer)
        R(ETag, 6) = CType(TextBox48.Text, Integer)
        R(ETag, 7) = CType(TextBox47.Text, Integer)
        R(ETag, 8) = CType(TextBox46.Text, Integer)
        R(ETag, 9) = CType(TextBox45.Text, Integer)
        R(ETag, 10) = CType(TextBox44.Text, Integer)
        R(ETag, 11) = CType(TextBox43.Text, Integer)
        R(ETag, 12) = CType(TextBox42.Text, Integer)
        R(ETag, 13) = CType(TextBox41.Text, Integer)
        R(ETag, 14) = CType(TextBox40.Text, Integer)
        R(ETag, 15) = CType(TextBox39.Text, Integer)
        R(ETag, 16) = CType(TextBox55.Text, Integer)
        R(ETag, 17) = CType(TextBox62.Text, Integer)
        R(ETag, 18) = CType(TextBox61.Text, Integer)
        R(ETag, 19) = CType(TextBox60.Text, Integer)
        R(ETag, 20) = CType(TextBox59.Text, Integer)
        R(ETag, 21) = CType(TextBox58.Text, Integer)
        R(ETag, 22) = CType(TextBox57.Text, Integer)
        R(ETag, 23) = CType(TextBox56.Text, Integer)
        R(ETag, 24) = CType(TextBox38.Text, Integer)

        tLETag(ETag, 1) = CType(TextBox118.Text, Single)
        tLETag(ETag, 2) = CType(TextBox117.Text, Single)
        tLETag(ETag, 3) = CType(TextBox116.Text, Single)
        tLETag(ETag, 4) = CType(TextBox115.Text, Single)
        tLETag(ETag, 5) = CType(TextBox114.Text, Single)
        tLETag(ETag, 6) = CType(TextBox113.Text, Single)
        tLETag(ETag, 7) = CType(TextBox112.Text, Single)
        tLETag(ETag, 8) = CType(TextBox111.Text, Single)
        tLETag(ETag, 9) = CType(TextBox110.Text, Single)
        tLETag(ETag, 10) = CType(TextBox109.Text, Single)
        tLETag(ETag, 11) = CType(TextBox108.Text, Single)
        tLETag(ETag, 12) = CType(TextBox107.Text, Single)
        tLETag(ETag, 13) = CType(TextBox106.Text, Single)
        tLETag(ETag, 14) = CType(TextBox105.Text, Single)
        tLETag(ETag, 15) = CType(TextBox104.Text, Single)
        tLETag(ETag, 16) = CType(TextBox120.Text, Single)
        tLETag(ETag, 17) = CType(TextBox127.Text, Single)
        tLETag(ETag, 18) = CType(TextBox126.Text, Single)
        tLETag(ETag, 19) = CType(TextBox125.Text, Single)
        tLETag(ETag, 20) = CType(TextBox124.Text, Single)
        tLETag(ETag, 21) = CType(TextBox123.Text, Single)
        tLETag(ETag, 22) = CType(TextBox122.Text, Single)
        tLETag(ETag, 23) = CType(TextBox121.Text, Single)
        tLETag(ETag, 24) = CType(TextBox103.Text, Single)

        xLETag(ETag, 1) = CType(TextBox193.Text, Single)
        xLETag(ETag, 2) = CType(TextBox192.Text, Single)
        xLETag(ETag, 3) = CType(TextBox191.Text, Single)
        xLETag(ETag, 4) = CType(TextBox190.Text, Single)
        xLETag(ETag, 5) = CType(TextBox189.Text, Single)
        xLETag(ETag, 6) = CType(TextBox188.Text, Single)
        xLETag(ETag, 7) = CType(TextBox187.Text, Single)
        xLETag(ETag, 8) = CType(TextBox186.Text, Single)
        xLETag(ETag, 9) = CType(TextBox185.Text, Single)
        xLETag(ETag, 10) = CType(TextBox184.Text, Single)
        xLETag(ETag, 11) = CType(TextBox183.Text, Single)
        xLETag(ETag, 12) = CType(TextBox182.Text, Single)
        xLETag(ETag, 13) = CType(TextBox181.Text, Single)
        xLETag(ETag, 14) = CType(TextBox180.Text, Single)
        xLETag(ETag, 15) = CType(TextBox179.Text, Single)
        xLETag(ETag, 16) = CType(TextBox195.Text, Single)
        xLETag(ETag, 17) = CType(TextBox202.Text, Single)
        xLETag(ETag, 18) = CType(TextBox201.Text, Single)
        xLETag(ETag, 19) = CType(TextBox200.Text, Single)
        xLETag(ETag, 20) = CType(TextBox199.Text, Single)
        xLETag(ETag, 21) = CType(TextBox198.Text, Single)
        xLETag(ETag, 22) = CType(TextBox197.Text, Single)
        xLETag(ETag, 23) = CType(TextBox196.Text, Single)
        xLETag(ETag, 24) = CType(TextBox178.Text, Single)
    End Sub

    Sub ZUSTAND()
        Dim pS, pW, xW, xS As Single
        pS = PSA(tstern)
        pW = xstern * pL / (0.6222 + xstern)
        xS = 0.6222 * pS / (pL - pS)
        If pS - pW >= -0.00001 Then
            xW = xstern
            phistern = pW / pS * 100
        Else
            xW = xS
            If tstern > 0 Then
                phistern = 200
            Else
                phistern = 300
            End If
        End If
    End Sub

    Function PSA(ByVal xx)
        'Verdampfungskurve
        If 0.01 <= xx And xx <= 100 Then
            PSA = 611 * Math.Exp(-0.000191275 + 0.07258 * xx - 0.0002939 * xx ^ 2 + 0.0000009841 * xx ^ 3 - 0.00000000192 * xx ^ 4)
            'Sublimationskurve
        ElseIf -20 <= xx And xx < 0.01 Then
            PSA = 611 * Math.Exp(-0.0004909965 + 0.08183197 * xx - 0.0005552967 * xx ^ 2 - 0.00002228376 * xx ^ 3 - 0.0000006211808 * xx ^ 4)
        End If
    End Function

    Public Sub EINGABELADUNG2()
        Datei = Objektbezeichnung + "ZVERLAUF.dat"
        FileOpen(1, Datei, OpenMode.Input)
        For ETag = 1 To 20
            For Stunde = 0 To 24
                Input(1, VLanteil(ETag, Stunde))
                Input(1, R(ETag, Stunde))
                Input(1, tLETag(ETag, Stunde))
                Input(1, xLETag(ETag, Stunde))
                Input(1, phiETag(ETag, Stunde))
            Next Stunde
        Next ETag
        FileClose(1)
    End Sub

    Public Sub EINGABESPEICHERUNG2()
        Datei = Objektbezeichnung + "ZVERLAUF.dat"
        FileOpen(1, Datei, OpenMode.Output)
        For ETag = 1 To 20
            VLanteil(ETag, 0) = VLanteil(ETag, 24)
            R(ETag, 0) = R(ETag, 24)
            tLETag(ETag, 0) = tLETag(ETag, 24)
            xLETag(ETag, 0) = xLETag(ETag, 24)
            phiETag(ETag, 0) = phiETag(ETag, 24)
            For Stunde = 0 To 24
                Write(1, VLanteil(ETag, Stunde))
                Write(1, R(ETag, Stunde))
                Write(1, tLETag(ETag, Stunde))
                Write(1, xLETag(ETag, Stunde))
                Write(1, phiETag(ETag, Stunde))
            Next Stunde
        Next ETag
        FileClose(1)
    End Sub

    Sub NULLEINTRAG2()
        For ETag = 1 To 20
            For Stunde = 1 To 24
                VLanteil(ETag, Stunde) = 1
                R(ETag, Stunde) = 1
                tLETag(ETag, Stunde) = -273
                xLETag(ETag, Stunde) = 0
            Next Stunde
        Next ETag
        ETag = 1
        Call EINTRAG2()
    End Sub

    Public Sub Kontrolldruck()
        Dim wordapp, ccc As Object
        Dim Zeile, fo0, fo1, fo2, fo3, fo4, fo5, fo6, fo7, fo8, fo9, fo10, fo11, fo12, fo13, fo14, fo15 As String
        Dim k As Integer
        wordapp = CreateObject("Word.Application")         'Variable initialisieren
        If wordapp Is Nothing Then
            MsgBox("Konnte keine Verbindung zu Word herstellen!", 16, "Problem")
            Exit Sub
        End If
        With wordapp
            .Visible = True
            .Documents.Add()
            If .ActiveWindow.View.SplitSpecial <> 0 Then .ActiveWindow.Panes(2).Close()
            If .ActiveWindow.ActivePane.View.Type = 1 Or .ActiveWindow. _
                  ActivePane.View.Type = 2 Or .ActiveWindow.ActivePane.View.Type _
                   = 5 Then .ActiveWindow.ActivePane.View.Type = 3
            .ActiveWindow.ActivePane.View.SeekView = 0
            With .Selection.Font
                .Name = "Balloon Bd BT"
                .Size = 11
                .Bold = False
            End With
            .Selection.TypeText(Text:="Objektbezeichnung:  " + Objektbezeichnung)
            .Selection.TypeParagraph()

            'Kontrollausgabe f�r die Zeitverl�ufe
            With .Selection.Font
                .Name = "Times New Roman"
                .Size = 12
                .Bold = False
            End With
            fo0 = fo20(ETag)
            .Selection.TypeText(Text:="Zeitliche Temperaturverl�ufe (Randbedingungen) f�r Entwurfstag" + fo0 + ":")
            .Selection.TypeParagraph()
            With .Selection.Font
                .Name = "Courier New"
                .Size = 9
                .Bold = False
            End With
            .Selection.TypeText(Text:="_____________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="Tages-     tL       xL       phiL      VLanteil      Richtung")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="stunde     �C      g/kg        %           -             -          ")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="_____________________________________________________________")
            .Selection.TypeParagraph()

            For k = 1 To 24
                fo0 = fo30(k)
                fo1 = fo51(tLETag(ETag, k))
                fo2 = fo31(xLETag(ETag, k))
                fo3 = fo31(phiETag(ETag, k))
                fo4 = fo22(VLanteil(ETag, k))
                fo5 = fo30(R(ETag, k))
                Zeile = " " + fo0 + "   " + fo1 + "    " + fo2 + "     " + fo3 + "        " + fo4 + "         " + fo5
                .Selection.TypeText(Text:=Zeile)
                .Selection.TypeParagraph()
            Next k
            .Selection.TypeText(Text:="_____________________________________________________________")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="Legende:")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="tL       Temperaturverlauf des Luftvolumenstromes")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="xL       Verlauf der absoluten Feuchte des Luftvolumenstromes")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="phiL     Verlauf der relativen Feuchte des Luftvolumenstromes")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="VLanteil Anteil des Luftvolumenstromes vom Maximalwert")
            .Selection.TypeParagraph()
            .Selection.TypeText(Text:="Richtung Richtung des Luftstromes: Normalrichtung 1; Gegenrichtung -1, Stillstand 0")
            .Selection.TypeParagraph()

        End With
    End Sub

    Public Function fo51(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.95 And x >= 0 Then fo51 = Format$(HG, "    0.0")
        If HG < 9.95 And x < 0 Then fo51 = Format$(HG, "   -0.0")
        If HG >= 9.95 And x >= 0 Then fo51 = Format$(HG, "   00.0")
        If HG >= 9.95 And x < 0 Then fo51 = Format$(HG, "  -00.0")
        If HG >= 99.95 And x >= 0 Then fo51 = Format$(HG, "  000.0")
        If HG >= 99.95 And x < 0 Then fo51 = Format$(HG, " -000.0")
        If HG >= 999.95 And x >= 0 Then fo51 = Format$(HG, " 0000.0")
        If HG >= 999.95 And x < 0 Then fo51 = Format$(HG, "-0000.0")
        If HG >= 9999.95 And x >= 0 Then fo51 = Format$(HG, "00000.0")
    End Function

    Public Function fo30(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.5 And x >= 0 Then fo30 = Format$(HG, "  0")
        If HG < 9.5 And x < 0 Then fo30 = Format$(HG, " -0")
        If HG >= 9.5 And x >= 0 Then fo30 = Format$(HG, " 00")
        If HG >= 9.5 And x < 0 Then fo30 = Format$(HG, "-00")
        If HG >= 99.5 And x >= 0 Then fo30 = Format$(HG, "000")
    End Function

    Public Function fo20(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.5 And x >= 0 Then fo20 = Format$(HG, " 0")
        If HG < 9.5 And x < 0 Then fo20 = Format$(HG, "-0")
        If HG >= 9.5 And x >= 0 Then fo20 = Format$(HG, "00")
    End Function

    Public Function fo31(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.95 And x >= 0 Then fo31 = Format$(HG, "  0.0")
        If HG < 9.95 And x < 0 Then fo31 = Format$(HG, " -0.0")
        If HG >= 9.95 And x >= 0 Then fo31 = Format$(HG, " 00.0")
        If HG >= 9.95 And x < 0 Then fo31 = Format$(HG, "-00.0")
        If HG >= 99.95 And x >= 0 Then fo31 = Format$(HG, "000.0")
    End Function

    Public Function fo22(ByVal x)
        Dim HG As Single
        HG = Math.Abs(x)
        If HG < 9.995 And x >= 0 Then fo22 = Format$(HG, " 0.00")
        If HG < 9.995 And x < 0 Then fo22 = Format$(HG, "-0.00")
        If HG >= 9.995 And x >= 0 Then fo22 = Format$(HG, "00.00")
    End Function

End Class
