Public Class Form4
    Inherits System.Windows.Forms.Form
    Public Datei, cc1, cc2, cc3, cc4, cc1a, cc2a, cc3a, cc4a, ooo, Speicherfeld, Feld As String
    Public Objektbezeichnung As Object
    Public StartOK, T_Typ, Richtung, p, pmax, i, j, k, imax(12), jmax(12), kmax(12), Dtau, Tagesstunde(9000) As Integer
    Public imax1(12), jmax1(12), kmax1(12), imax2(12), jmax2(12), kmax2(12), s, smax, ETag As Integer
    Public BS, BSmax, Zeit, Zeitmax, GanzeStunde, Stunde, Stunde1, Uhrbeginn, ETagfix, R(26, 25) As Integer
    Public Zahl, sBeginn, sEnde, sStep, DtauVorschlag As Integer
    Public Korrekturzahl_TT, Korrekturzahl_BT, Korrekturzahl_BQ As Integer
    Public Teilung, Stundemin, Stundemax, Stundea, Stundeb, Stundec, Netz As Integer
    Public rho, lam, c, PSI, V(12), Anteil(12), O(12), Fak, Exp, Hoehe, Laenge, Breite, Vh, dK As Single
    Public Rest, Rest0, a(12), b(12), Dx(12), Dy(12), VTyp(12), Vfest, ZP(12), Oanteil(12) As Single
    Public Sum, mfest, VLuft, aFaehigkeit, DtauPartikel(12) As Single
    Public a1(12), a2(12), b1(12), b2(12), Dx1(12), Dy1(12), Dx2(12), Dy2(12), DtauPartikel1(12), DtauPartikel2(12) As Single
    Public AEi(12), AE(12), VE(12), CE(12), REi(12), RE(12), LEi(12), LE(12), tStart As Single
    Public t(120, 12, 10, 10, 10), tn(120, 12, 10, 10, 10) As Single
    Public QSpeicher(9000), QMedium(9000), tLein(9000), tLaus(9000), Kondensatmenge(9000) As Single
    Public xLein(9000), xLaus(9000), phiLein(9000), phiLaus(9000), RichtungBS(9000) As Single
    Public tau, tauUhr, Dtaumax, tLa, xLa, tLETag(21, 25), xLETag(21, 25), phiETag(21, 25), tL(25), xL(25) As Single
    Public QL(25) As Single
    Public mLmax, mL, VLanteil(21, 25), hL(25) As Single

    Public x, y, x1, x2, tmin, tmax, t1, t2 As Single
    Public dHH, tMittel, Stundeteil As Single

    Public x0, y0 As Double              'absolute Bezugskoordinaten
    Public LL, HH, xLL, yH As Single     'maximale Diagrammgr��e

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        'Start der Diagrammdarstellung
        Dim g As Graphics = Me.CreateGraphics
        g.Clear(Me.BackColor)        'Zeichnung l�schen
        Korrekturzahl_TT = 0
        Korrekturzahl_BT = 0
        Korrekturzahl_BQ = 0
    End Sub

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox18 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox17 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox23 As System.Windows.Forms.CheckBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox10 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox11 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox13 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox14 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox15 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox16 As System.Windows.Forms.CheckBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox19 = New System.Windows.Forms.TextBox
        Me.TextBox18 = New System.Windows.Forms.TextBox
        Me.TextBox14 = New System.Windows.Forms.TextBox
        Me.TextBox24 = New System.Windows.Forms.TextBox
        Me.TextBox20 = New System.Windows.Forms.TextBox
        Me.TextBox21 = New System.Windows.Forms.TextBox
        Me.TextBox22 = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.TextBox6 = New System.Windows.Forms.TextBox
        Me.TextBox5 = New System.Windows.Forms.TextBox
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.CheckBox18 = New System.Windows.Forms.CheckBox
        Me.CheckBox17 = New System.Windows.Forms.CheckBox
        Me.CheckBox23 = New System.Windows.Forms.CheckBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label75 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.TextBox17 = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.TextBox23 = New System.Windows.Forms.TextBox
        Me.TextBox15 = New System.Windows.Forms.TextBox
        Me.TextBox13 = New System.Windows.Forms.TextBox
        Me.TextBox16 = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.CheckBox5 = New System.Windows.Forms.CheckBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.CheckBox4 = New System.Windows.Forms.CheckBox
        Me.CheckBox3 = New System.Windows.Forms.CheckBox
        Me.CheckBox2 = New System.Windows.Forms.CheckBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.CheckBox10 = New System.Windows.Forms.CheckBox
        Me.CheckBox11 = New System.Windows.Forms.CheckBox
        Me.CheckBox13 = New System.Windows.Forms.CheckBox
        Me.CheckBox14 = New System.Windows.Forms.CheckBox
        Me.CheckBox15 = New System.Windows.Forms.CheckBox
        Me.CheckBox16 = New System.Windows.Forms.CheckBox
        Me.Button7 = New System.Windows.Forms.Button
        Me.TextBox12 = New System.Windows.Forms.TextBox
        Me.TextBox11 = New System.Windows.Forms.TextBox
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.TextBox25 = New System.Windows.Forms.TextBox
        Me.TextBox26 = New System.Windows.Forms.TextBox
        Me.TextBox27 = New System.Windows.Forms.TextBox
        Me.TextBox28 = New System.Windows.Forms.TextBox
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox19
        '
        Me.TextBox19.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox19.ForeColor = System.Drawing.Color.Black
        Me.TextBox19.Location = New System.Drawing.Point(768, 144)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(376, 26)
        Me.TextBox19.TabIndex = 580
        Me.TextBox19.Text = ""
        '
        'TextBox18
        '
        Me.TextBox18.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox18.Location = New System.Drawing.Point(8, 88)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(316, 26)
        Me.TextBox18.TabIndex = 576
        Me.TextBox18.Text = ""
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(768, 8)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(464, 27)
        Me.TextBox14.TabIndex = 552
        Me.TextBox14.Text = ""
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(1200, 680)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(48, 27)
        Me.TextBox24.TabIndex = 582
        Me.TextBox24.Text = ""
        Me.TextBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox20
        '
        Me.TextBox20.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.ForeColor = System.Drawing.Color.Green
        Me.TextBox20.Location = New System.Drawing.Point(768, 112)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(376, 26)
        Me.TextBox20.TabIndex = 579
        Me.TextBox20.Text = ""
        '
        'TextBox21
        '
        Me.TextBox21.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox21.ForeColor = System.Drawing.Color.Magenta
        Me.TextBox21.Location = New System.Drawing.Point(768, 48)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(376, 26)
        Me.TextBox21.TabIndex = 578
        Me.TextBox21.Text = ""
        '
        'TextBox22
        '
        Me.TextBox22.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox22.ForeColor = System.Drawing.Color.Blue
        Me.TextBox22.Location = New System.Drawing.Point(768, 80)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(376, 26)
        Me.TextBox22.TabIndex = 577
        Me.TextBox22.Text = ""
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.White
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(56, 712)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 16)
        Me.Label7.TabIndex = 583
        Me.Label7.Text = "Uhrzeit "
        '
        'TextBox7
        '
        Me.TextBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.ForeColor = System.Drawing.Color.Green
        Me.TextBox7.Location = New System.Drawing.Point(368, 112)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(376, 26)
        Me.TextBox7.TabIndex = 560
        Me.TextBox7.Text = ""
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.ForeColor = System.Drawing.Color.Magenta
        Me.TextBox6.Location = New System.Drawing.Point(368, 48)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(376, 26)
        Me.TextBox6.TabIndex = 559
        Me.TextBox6.Text = ""
        '
        'TextBox5
        '
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.ForeColor = System.Drawing.Color.Blue
        Me.TextBox5.Location = New System.Drawing.Point(368, 80)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(376, 26)
        Me.TextBox5.TabIndex = 558
        Me.TextBox5.Text = ""
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(192, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(24, 208)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(48, 23)
        Me.TextBox4.TabIndex = 557
        Me.TextBox4.Text = ""
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(8, 168)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(64, 27)
        Me.TextBox2.TabIndex = 553
        Me.TextBox2.Text = ""
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(8, 616)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(64, 27)
        Me.TextBox3.TabIndex = 554
        Me.TextBox3.Text = ""
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.883117!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(8, 48)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(316, 28)
        Me.TextBox1.TabIndex = 548
        Me.TextBox1.Text = ""
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button1.Location = New System.Drawing.Point(384, 680)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(248, 32)
        Me.Button1.TabIndex = 573
        Me.Button1.Text = "Betriebsverl�ufe - Luftstrom*"
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.Magenta
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Button5.Location = New System.Drawing.Point(160, 8)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(168, 32)
        Me.Button5.TabIndex = 555
        Me.Button5.Text = "Grenzwertbest�tigung"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.TopLeft
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button4.Location = New System.Drawing.Point(648, 680)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(328, 32)
        Me.Button4.TabIndex = 572
        Me.Button4.Text = "W�rmestrom- und Speicherverl�ufe*"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(224, Byte), CType(192, Byte))
        Me.GroupBox3.Controls.Add(Me.CheckBox18)
        Me.GroupBox3.Controls.Add(Me.CheckBox17)
        Me.GroupBox3.Controls.Add(Me.CheckBox23)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox3.Location = New System.Drawing.Point(648, 720)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(328, 96)
        Me.GroupBox3.TabIndex = 575
        Me.GroupBox3.TabStop = False
        '
        'CheckBox18
        '
        Me.CheckBox18.ForeColor = System.Drawing.Color.Black
        Me.CheckBox18.Location = New System.Drawing.Point(8, 48)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(304, 40)
        Me.CheckBox18.TabIndex = 142
        Me.CheckBox18.Text = "Speicherw�rme des Schotters bezogen auf tLein"
        '
        'CheckBox17
        '
        Me.CheckBox17.ForeColor = System.Drawing.Color.Black
        Me.CheckBox17.Location = New System.Drawing.Point(168, 16)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(152, 24)
        Me.CheckBox17.TabIndex = 141
        Me.CheckBox17.Text = "Kondensatstrom"
        '
        'CheckBox23
        '
        Me.CheckBox23.ForeColor = System.Drawing.Color.Black
        Me.CheckBox23.Location = New System.Drawing.Point(8, 16)
        Me.CheckBox23.Name = "CheckBox23"
        Me.CheckBox23.Size = New System.Drawing.Size(120, 24)
        Me.CheckBox23.TabIndex = 140
        Me.CheckBox23.Text = "Q_Luftstrom"
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(488, 8)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(280, 23)
        Me.Label23.TabIndex = 551
        Me.Label23.Text = "Pfad und vorhandener Dateiname:"
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button3.Location = New System.Drawing.Point(120, 680)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(248, 32)
        Me.Button3.TabIndex = 550
        Me.Button3.Text = "Tagesg�nge - Entwurfstage"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Magenta
        Me.Button2.Location = New System.Drawing.Point(1160, 776)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(88, 40)
        Me.Button2.TabIndex = 549
        Me.Button2.Text = "BEENDEN"
        '
        'Label75
        '
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label75.Location = New System.Drawing.Point(984, 720)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(168, 64)
        Me.Label75.TabIndex = 586
        Me.Label75.Text = "Zum Starten CheckBoxen anklicken und dar�ber befindlichen Button dr�cken!"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(1200, 712)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 16)
        Me.Label8.TabIndex = 584
        Me.Label8.Text = "Uhrzeit "
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(8, 392)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(64, 27)
        Me.TextBox17.TabIndex = 571
        Me.TextBox17.Text = ""
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label11.Location = New System.Drawing.Point(984, 784)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(168, 40)
        Me.Label11.TabIndex = 587
        Me.Label11.Text = "*Funktion erst nach erfolgter Berechnung aktiv!"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.White
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Magenta
        Me.Label9.Location = New System.Drawing.Point(8, 8)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(144, 23)
        Me.Label9.TabIndex = 585
        Me.Label9.Text = "Ma�stabs�nderung >"
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(56, 680)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(48, 27)
        Me.TextBox23.TabIndex = 581
        Me.TextBox23.Text = ""
        Me.TextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(1200, 648)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(48, 27)
        Me.TextBox15.TabIndex = 568
        Me.TextBox15.Text = ""
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(912, 648)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(48, 27)
        Me.TextBox13.TabIndex = 567
        Me.TextBox13.Text = ""
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox16
        '
        Me.TextBox16.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox16.ForeColor = System.Drawing.Color.Magenta
        Me.TextBox16.Location = New System.Drawing.Point(8, 792)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(48, 24)
        Me.TextBox16.TabIndex = 570
        Me.TextBox16.Text = ""
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.GroupBox2.Controls.Add(Me.CheckBox5)
        Me.GroupBox2.Controls.Add(Me.TextBox8)
        Me.GroupBox2.Controls.Add(Me.CheckBox4)
        Me.GroupBox2.Controls.Add(Me.CheckBox3)
        Me.GroupBox2.Controls.Add(Me.CheckBox2)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.CheckBox1)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox2.Location = New System.Drawing.Point(120, 720)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(248, 96)
        Me.GroupBox2.TabIndex = 562
        Me.GroupBox2.TabStop = False
        '
        'CheckBox5
        '
        Me.CheckBox5.ForeColor = System.Drawing.Color.Black
        Me.CheckBox5.Location = New System.Drawing.Point(8, 64)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(80, 24)
        Me.CheckBox5.TabIndex = 163
        Me.CheckBox5.Text = "phi_Luft"
        '
        'TextBox8
        '
        Me.TextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.ForeColor = System.Drawing.Color.Black
        Me.TextBox8.Location = New System.Drawing.Point(110, 64)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(32, 27)
        Me.TextBox8.TabIndex = 162
        Me.TextBox8.Text = ""
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'CheckBox4
        '
        Me.CheckBox4.ForeColor = System.Drawing.Color.Black
        Me.CheckBox4.Location = New System.Drawing.Point(128, 40)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(96, 24)
        Me.CheckBox4.TabIndex = 161
        Me.CheckBox4.Text = "Richtung"
        '
        'CheckBox3
        '
        Me.CheckBox3.ForeColor = System.Drawing.Color.Black
        Me.CheckBox3.Location = New System.Drawing.Point(128, 16)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(88, 24)
        Me.CheckBox3.TabIndex = 160
        Me.CheckBox3.Text = "V_Anteil"
        '
        'CheckBox2
        '
        Me.CheckBox2.ForeColor = System.Drawing.Color.Black
        Me.CheckBox2.Location = New System.Drawing.Point(8, 40)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(80, 24)
        Me.CheckBox2.TabIndex = 159
        Me.CheckBox2.Text = "x_Luft"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(144, 64)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(96, 23)
        Me.Label10.TabIndex = 158
        Me.Label10.Text = "Entwurfstag"
        '
        'CheckBox1
        '
        Me.CheckBox1.ForeColor = System.Drawing.Color.Black
        Me.CheckBox1.Location = New System.Drawing.Point(8, 16)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(80, 24)
        Me.CheckBox1.TabIndex = 140
        Me.CheckBox1.Text = "t_Luft"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(192, Byte))
        Me.GroupBox1.Controls.Add(Me.CheckBox10)
        Me.GroupBox1.Controls.Add(Me.CheckBox11)
        Me.GroupBox1.Controls.Add(Me.CheckBox13)
        Me.GroupBox1.Controls.Add(Me.CheckBox14)
        Me.GroupBox1.Controls.Add(Me.CheckBox15)
        Me.GroupBox1.Controls.Add(Me.CheckBox16)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox1.Location = New System.Drawing.Point(384, 720)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(248, 96)
        Me.GroupBox1.TabIndex = 574
        Me.GroupBox1.TabStop = False
        '
        'CheckBox10
        '
        Me.CheckBox10.ForeColor = System.Drawing.Color.Black
        Me.CheckBox10.Location = New System.Drawing.Point(160, 40)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(80, 24)
        Me.CheckBox10.TabIndex = 164
        Me.CheckBox10.Text = "phiLaus"
        '
        'CheckBox11
        '
        Me.CheckBox11.ForeColor = System.Drawing.Color.Black
        Me.CheckBox11.Location = New System.Drawing.Point(80, 40)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(72, 24)
        Me.CheckBox11.TabIndex = 163
        Me.CheckBox11.Text = "xLaus"
        '
        'CheckBox13
        '
        Me.CheckBox13.ForeColor = System.Drawing.Color.Black
        Me.CheckBox13.Location = New System.Drawing.Point(160, 16)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(80, 24)
        Me.CheckBox13.TabIndex = 160
        Me.CheckBox13.Text = "phiLein"
        '
        'CheckBox14
        '
        Me.CheckBox14.ForeColor = System.Drawing.Color.Black
        Me.CheckBox14.Location = New System.Drawing.Point(80, 16)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(72, 24)
        Me.CheckBox14.TabIndex = 159
        Me.CheckBox14.Text = "xLein"
        '
        'CheckBox15
        '
        Me.CheckBox15.ForeColor = System.Drawing.Color.Black
        Me.CheckBox15.Location = New System.Drawing.Point(8, 16)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(72, 24)
        Me.CheckBox15.TabIndex = 140
        Me.CheckBox15.Text = "tLein"
        '
        'CheckBox16
        '
        Me.CheckBox16.ForeColor = System.Drawing.Color.Black
        Me.CheckBox16.Location = New System.Drawing.Point(8, 40)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(72, 24)
        Me.CheckBox16.TabIndex = 162
        Me.CheckBox16.Text = "tLaus"
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.Magenta
        Me.Button7.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Button7.Location = New System.Drawing.Point(336, 8)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(128, 32)
        Me.Button7.TabIndex = 561
        Me.Button7.Text = "Originalma�stab"
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.TopLeft
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(624, 648)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(48, 27)
        Me.TextBox12.TabIndex = 566
        Me.TextBox12.Text = ""
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(336, 648)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(48, 27)
        Me.TextBox11.TabIndex = 565
        Me.TextBox11.Text = ""
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(56, 648)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(48, 27)
        Me.TextBox10.TabIndex = 564
        Me.TextBox10.Text = ""
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox9
        '
        Me.TextBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.ForeColor = System.Drawing.Color.Black
        Me.TextBox9.Location = New System.Drawing.Point(368, 144)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(376, 26)
        Me.TextBox9.TabIndex = 563
        Me.TextBox9.Text = ""
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Magenta
        Me.Label1.Location = New System.Drawing.Point(8, 760)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 32)
        Me.Label1.TabIndex = 569
        Me.Label1.Text = "Teilung der Ordinate:"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(1064, 648)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 24)
        Me.Label5.TabIndex = 556
        Me.Label5.Text = "Stunden"
        '
        'TextBox25
        '
        Me.TextBox25.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox25.ForeColor = System.Drawing.Color.Blue
        Me.TextBox25.Location = New System.Drawing.Point(24, 232)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(48, 23)
        Me.TextBox25.TabIndex = 588
        Me.TextBox25.Text = ""
        Me.TextBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox26
        '
        Me.TextBox26.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox26.ForeColor = System.Drawing.Color.Green
        Me.TextBox26.Location = New System.Drawing.Point(24, 280)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(48, 23)
        Me.TextBox26.TabIndex = 589
        Me.TextBox26.Text = ""
        Me.TextBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox27
        '
        Me.TextBox27.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox27.ForeColor = System.Drawing.Color.Black
        Me.TextBox27.Location = New System.Drawing.Point(24, 304)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(48, 23)
        Me.TextBox27.TabIndex = 590
        Me.TextBox27.Text = ""
        Me.TextBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox28
        '
        Me.TextBox28.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox28.ForeColor = System.Drawing.Color.Blue
        Me.TextBox28.Location = New System.Drawing.Point(24, 256)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(48, 23)
        Me.TextBox28.TabIndex = 591
        Me.TextBox28.Text = ""
        Me.TextBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Form4
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 20)
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1270, 827)
        Me.Controls.Add(Me.TextBox28)
        Me.Controls.Add(Me.TextBox27)
        Me.Controls.Add(Me.TextBox26)
        Me.Controls.Add(Me.TextBox25)
        Me.Controls.Add(Me.TextBox19)
        Me.Controls.Add(Me.TextBox18)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.TextBox24)
        Me.Controls.Add(Me.TextBox20)
        Me.Controls.Add(Me.TextBox21)
        Me.Controls.Add(Me.TextBox22)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TextBox17)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextBox23)
        Me.Controls.Add(Me.TextBox15)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label5)
        Me.Name = "Form4"
        Me.Text = "Zeitverl�ufe"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'Darstellung der Temperatur- und Steuerungs-Tagesg�nge f�r die Entwurfstage
        Dim g As Graphics = Me.CreateGraphics
        g.Clear(Me.BackColor)        'Zeichnung l�schen
        Call EINGABELADUNG2()
        If Korrekturzahl_TT = 0 Then
            tmin = -10
            tmax = 30
            Korrekturzahl_TT = 1
            Teilung = 4
        End If
        'Konstante x-Achse bei Tagesg�ngen 0...24 Uhr
        Stundemin = 0
        Stundemax = 24
        tMittel = (tmax + tmin) / 2
        tMittel = Int(tMittel)
        TextBox17.Text = tMittel.ToString
        Stundeteil = (Stundemax - Stundemin) / 4
        Stundea = Int(Stundemin + Stundeteil)
        Stundeb = Int(Stundemin + 2 * Stundeteil)
        Stundec = Int(Stundemin + 3 * Stundeteil)
        TextBox10.Text = Stundemin.ToString
        TextBox11.Text = Stundea.ToString
        TextBox12.Text = Stundeb.ToString
        TextBox13.Text = Stundec.ToString
        TextBox15.Text = Stundemax.ToString

        TextBox16.Text = Teilung.ToString()
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox9.Text = ""
        TextBox21.Text = ""
        TextBox22.Text = ""
        TextBox20.Text = ""
        TextBox19.Text = ""
        TextBox23.Text = ""
        TextBox24.Text = ""
        TextBox4.Text = ""
        TextBox25.Text = ""
        TextBox26.Text = ""
        TextBox27.Text = ""
        TextBox28.Text = ""

        ooo = CType(TextBox8.Text, String)
        If ooo = "" Then
            TextBox6.Text = "Bitte Entwurfstag angeben!"
            GoTo Label_TT
        End If
        ETag = CType(TextBox8.Text, Integer)
        TextBox1.Text = "Tagesg�nge nach Eingabe"
        TextBox2.Text = tmax.ToString()
        TextBox3.Text = tmin.ToString()
        TextBox18.Text = "Entwurfstag: " + ETag.ToString
        TextBox23.Text = 0.ToString()
        TextBox24.Text = 24.ToString()
        Call drawRahmen()
        'y-Achsteilung
        Netz = 10
        x = (Stundemax - Stundemin) / 100
        dHH = (tmax - tmin) / 5 / Teilung
        For k = 1 To (5 * Teilung)
            y = k * dHH
            If k / 5 = Int(k / 5) Then
                dwl(0, y, Stundemax - Stundemin, y)
            Else
                dwl(0, y, x, y)
            End If
        Next
        'x-Achsteilung
        Netz = 10
        y = (tmax - tmin) / 50
        For k = Stundemin To Stundemax
            If k = Stundea Or k = Stundeb Or k = Stundec Or k = Stundemax Then
                dwl(k - Stundemin, 0, k - Stundemin, tmax - tmin)
            Else
                dwl(k - Stundemin, 0, k - Stundemin, y)
            End If
        Next k

        'Temperaturtagesg�nge gem�� Eingabe
        cc1 = "" : cc2 = "" : cc3 = "" : cc4 = "" : cc2a = ""
        If CheckBox1.CheckState = 1 Then
            cc1 = "Lufttemperatur - magenta"
            TextBox4.Text = " �C"
            Netz = 1
            For Stunde = 1 To 24
                t1 = tLETag(ETag, Stunde - 1)
                t2 = tLETag(ETag, Stunde)
                dwl(Stunde - 1, t1 - tmin, Stunde, t2 - tmin)
            Next
        End If
        If CheckBox2.CheckState = 1 Then
            cc2 = "Abs. Luftfeuchte - blau"
            TextBox25.Text = " g/kg"
            Netz = 2
            For Stunde = 1 To 24
                t1 = xLETag(ETag, Stunde - 1)
                t2 = xLETag(ETag, Stunde)
                dwl(Stunde - 1, t1 - tmin, Stunde, t2 - tmin)
            Next
        End If
        If CheckBox3.CheckState = 1 Then
            cc3 = "Luftstromanteil - gr�n"
            TextBox26.Text = " -"
            Netz = 3
            For Stunde = 1 To 24
                t1 = VLanteil(ETag, Stunde - 1)
                t2 = VLanteil(ETag, Stunde)
                If t2 <> t1 Then t2 = t1
                dwl(Stunde - 1, t1 - tmin, Stunde, t2 - tmin)
            Next
        End If
        If CheckBox4.CheckState = 1 Then
            cc4 = "Luftrichtung - schwarz"
            TextBox27.Text = " -"
            Netz = 0
            For Stunde = 1 To 24
                t1 = R(ETag, Stunde - 1)
                t2 = R(ETag, Stunde)
                If t2 <> t1 Then t2 = t1
                dwl(Stunde - 1, t1 - tmin, Stunde, t2 - tmin)
            Next
        End If
        If CheckBox5.CheckState = 1 Then
            cc2a = "Rel. Luftfeuchte - blau mit Punkten"
            TextBox28.Text = " %"
            Netz = 2
            For Stunde = 1 To 24
                t1 = phiETag(ETag, Stunde - 1)
                t2 = phiETag(ETag, Stunde)
                dwl(Stunde - 1, t1 - tmin, Stunde, t2 - tmin)
                dwc(Stunde - 1, t1 - tmin, 2)
                dwc(Stunde, t2 - tmin, 2)
            Next
        End If
        TextBox6.Text = cc1
        TextBox5.Text = cc2
        TextBox7.Text = cc3
        TextBox9.Text = cc4
        TextBox22.Text = cc2a
Label_TT:
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Darstellung der Temperaturverl�ufe als Ergebnis der Simulation
        Dim g As Graphics = Me.CreateGraphics
        g.Clear(Me.BackColor)        'Zeichnung l�schen
        Call ERGEBNISLADUNG()
        Call EINGABELADUNG1()
        Call EINGABELADUNG2()
        If Korrekturzahl_BT = 0 Then
            tmin = -10
            tmax = 30
            Stundemin = 0
            Stundemax = 72
            Korrekturzahl_BT = 1
            Teilung = 4
        End If
        TextBox18.Text = ""
        tMittel = (tmax + tmin) / 2
        tMittel = Int(tMittel)
        TextBox17.Text = tMittel.ToString
        Stundeteil = (Stundemax - Stundemin) / 4
        Stundea = Int(Stundemin + Stundeteil)
        Stundeb = Int(Stundemin + 2 * Stundeteil)
        Stundec = Int(Stundemin + 3 * Stundeteil)
        TextBox10.Text = Stundemin.ToString
        TextBox11.Text = Stundea.ToString
        TextBox12.Text = Stundeb.ToString
        TextBox13.Text = Stundec.ToString
        TextBox15.Text = Stundemax.ToString

        TextBox16.Text = Teilung.ToString()
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox9.Text = ""
        TextBox21.Text = ""
        TextBox22.Text = ""
        TextBox20.Text = ""
        TextBox19.Text = ""
        TextBox23.Text = ""
        TextBox24.Text = ""
        TextBox4.Text = ""
        TextBox25.Text = ""
        TextBox26.Text = ""
        TextBox27.Text = ""
        TextBox28.Text = ""
        TextBox1.Text = "Betriebsverl�ufe"
        TextBox2.Text = tmax.ToString()
        TextBox3.Text = tmin.ToString()
        TextBox23.Text = Tagesstunde(Stundemin).ToString()
        TextBox24.Text = Tagesstunde(Stundemax).ToString()
        Call drawRahmen()
        'y-Achsteilung
        Netz = 10
        x = (Stundemax - Stundemin) / 100
        dHH = (tmax - tmin) / 5 / Teilung
        For k = 1 To (5 * Teilung)
            y = k * dHH
            If k / 5 = Int(k / 5) Then
                dwl(0, y, Stundemax - Stundemin, y)
            Else
                dwl(0, y, x, y)
            End If
        Next
        'x-Achsteilung
        Netz = 10
        y = (tmax - tmin) / 50
        For k = Stundemin To Stundemax
            If k = Stundea Or k = Stundeb Or k = Stundec Or k = Stundemax Then
                dwl(k - Stundemin, 0, k - Stundemin, tmax - tmin)
            Else
                dwl(k - Stundemin, 0, k - Stundemin, y)
            End If
        Next k

        'Temperaturverl�ufe nach Ergebnissen in Abh�ngigkeit der Betriebsstunden
        cc1 = "" : cc2 = "" : cc3 = "" : cc4 = ""
        cc1a = "" : cc2a = "" : cc3a = "" : cc4a = ""
        If CheckBox15.CheckState = 1 Then
            cc1 = "Lufttemperatureintritt - magenta"
            TextBox4.Text = " �C"
            Netz = 1
            For Stunde = Stundemin + 1 To Stundemax
                t1 = tLein(Stunde - 1)
                t2 = tLein(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If t1 > -273 And t2 > -273 Then
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                ElseIf t1 = -273 And t2 > -273 Then
                    t1 = tLETag(ETagfix, Tagesstunde(Stunde - 1))
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                End If
            Next
        End If
        If CheckBox16.CheckState = 1 Then
            cc1a = "Lufttemperaturaustritt - magenta mit Punkten"
            TextBox4.Text = " �C"
            Netz = 1
            For Stunde = Stundemin + 1 To Stundemax
                t1 = tLaus(Stunde - 1)
                t2 = tLaus(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If t1 > -273 And t2 > -273 Then
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                    dwc(x1, t1 - tmin, 2)
                    dwc(x2, t2 - tmin, 2)
                End If
            Next
        End If
        If CheckBox14.CheckState = 1 Then
            cc2 = "Abs. Luftfeuchteeintritt - blau"
            TextBox25.Text = " g/kg"
            Netz = 2
            For Stunde = Stundemin + 1 To Stundemax
                t1 = xLein(Stunde - 1)
                t2 = xLein(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If t1 > -273 And t2 > -273 Then
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                ElseIf t1 = -273 And t2 > -273 Then
                    t1 = xLETag(ETagfix, Tagesstunde(Stunde - 1))
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                End If
            Next
        End If
        If CheckBox11.CheckState = 1 Then
            cc2a = "Abs. Luftfeuchteaustritt - blau mit Punkten"
            TextBox25.Text = " g/kg"
            Netz = 2
            For Stunde = Stundemin + 1 To Stundemax
                t1 = xLaus(Stunde - 1)
                t2 = xLaus(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If t1 > -273 And t2 > -273 Then
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                    dwc(x1, t1 - tmin, 2)
                    dwc(x2, t2 - tmin, 2)
                End If
            Next
        End If
        If CheckBox13.CheckState = 1 Then
            cc3 = "Rel. Luftfeuchteeintritt - gr�n"
            TextBox26.Text = " %"
            Netz = 3
            For Stunde = Stundemin + 1 To Stundemax
                t1 = phiLein(Stunde - 1)
                t2 = phiLein(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If t1 > -273 And t2 > -273 Then
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                ElseIf t1 = -273 And t2 > -273 Then
                    t1 = phiETag(ETagfix, Tagesstunde(Stunde - 1))
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                End If
            Next
        End If
        If CheckBox10.CheckState = 1 Then
            cc3a = "Rel. Luftfeuchteaustritt - gr�n mit Punkten"
            TextBox26.Text = " %"
            Netz = 3
            For Stunde = Stundemin + 1 To Stundemax
                t1 = phiLaus(Stunde - 1)
                t2 = phiLaus(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If t1 > -273 And t2 > -273 Then
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                    dwc(x1, t1 - tmin, 2)
                    dwc(x2, t2 - tmin, 2)
                End If
            Next
        End If
        TextBox6.Text = cc1
        TextBox5.Text = cc2
        TextBox7.Text = cc3
        TextBox9.Text = cc4
        TextBox21.Text = cc1a
        TextBox22.Text = cc2a
        TextBox20.Text = cc3a
        TextBox19.Text = cc4a
Label_BT:
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        'Darstellung der W�rmestrom- und Speicherverl�ufe als Ergebnis der Simulation
        Dim g As Graphics = Me.CreateGraphics
        g.Clear(Me.BackColor)        'Zeichnung l�schen
        Call ERGEBNISLADUNG()
        If Korrekturzahl_BQ = 0 Then
            tmin = -100
            tmax = 300
            Stundemin = 0
            Stundemax = 72
            Korrekturzahl_BQ = 1
            Teilung = 4
        End If
        TextBox18.Text = ""
        tMittel = (tmax + tmin) / 2
        tMittel = Int(tMittel)
        TextBox17.Text = tMittel.ToString
        Stundeteil = (Stundemax - Stundemin) / 4
        Stundea = Int(Stundemin + Stundeteil)
        Stundeb = Int(Stundemin + 2 * Stundeteil)
        Stundec = Int(Stundemin + 3 * Stundeteil)
        TextBox10.Text = Stundemin.ToString
        TextBox11.Text = Stundea.ToString
        TextBox12.Text = Stundeb.ToString
        TextBox13.Text = Stundec.ToString
        TextBox15.Text = Stundemax.ToString

        TextBox16.Text = Teilung.ToString()
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox9.Text = ""
        TextBox21.Text = ""
        TextBox22.Text = ""
        TextBox20.Text = ""
        TextBox19.Text = ""
        TextBox23.Text = ""
        TextBox24.Text = ""
        TextBox4.Text = ""
        TextBox25.Text = ""
        TextBox26.Text = ""
        TextBox27.Text = ""
        TextBox28.Text = ""
        TextBox1.Text = "Leistungs- und Speicherverl�ufe"
        TextBox2.Text = tmax.ToString()
        TextBox3.Text = tmin.ToString()
        TextBox23.Text = Tagesstunde(Stundemin).ToString()
        TextBox24.Text = Tagesstunde(Stundemax).ToString()
        Call drawRahmen()
        'y-Achsteilung
        Netz = 10
        x = (Stundemax - Stundemin) / 100
        dHH = (tmax - tmin) / 5 / Teilung
        For k = 1 To (5 * Teilung)
            y = k * dHH
            If k / 5 = Int(k / 5) Then
                dwl(0, y, Stundemax - Stundemin, y)
            Else
                dwl(0, y, x, y)
            End If
        Next
        'x-Achsteilung
        Netz = 10
        y = (tmax - tmin) / 50
        For k = Stundemin To Stundemax
            If k = Stundea Or k = Stundeb Or k = Stundec Or k = Stundemax Then
                dwl(k - Stundemin, 0, k - Stundemin, tmax - tmin)
            Else
                dwl(k - Stundemin, 0, k - Stundemin, y)
            End If
        Next k

        'Leistungsverl�ufe nach Ergebnissen in Abh�ngigkeit der Betriebsstunden
        cc1 = "" : cc2 = "" : cc3 = "" : cc4 = ""
        cc1a = "" : cc2a = "" : cc3a = "" : cc4a = ""
        If CheckBox23.CheckState = 1 Then
            cc1 = "W�rmestrom an die Luft - magenta"
            TextBox4.Text = " kW"
            Netz = 1
            For Stunde = Stundemin + 1 To Stundemax
                t1 = QMedium(Stunde - 1)
                t2 = QMedium(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If tLaus(Stunde - 1) > -273 And tLaus(Stunde) > -273 Then
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                End If
            Next
        End If
        If CheckBox17.CheckState = 1 Then
            cc2 = "Kondensatstrom - blau"
            TextBox25.Text = "kg/h"
            Netz = 2
            For Stunde = Stundemin + 1 To Stundemax
                t1 = Kondensatmenge(Stunde - 1)
                t2 = Kondensatmenge(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If tLaus(Stunde - 1) > -273 And tLaus(Stunde) > -273 Then
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                End If
            Next
        End If
        If CheckBox18.CheckState = 1 Then
            cc3 = "Speicherw�rme - gr�n"
            TextBox26.Text = " kWh"
            Netz = 3
            For Stunde = Stundemin + 1 To Stundemax
                t1 = QSpeicher(Stunde - 1)
                t2 = QSpeicher(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                dwl(x1, t1 - tmin, x2, t2 - tmin)
            Next
        End If
        TextBox6.Text = cc1
        TextBox5.Text = cc2
        TextBox7.Text = cc3
        TextBox9.Text = cc4
        TextBox21.Text = cc1a
        TextBox22.Text = cc2a
        TextBox20.Text = cc3a
        TextBox19.Text = cc4a
Label_BT:
    End Sub

    Private Sub dwc(ByVal dx1 As Double, ByVal dy1 As Double, ByVal R As Double) ' zeichnet relative Linie
        Dim x1, y1 As Double
        x1 = x0 + dx1 * xLL
        y1 = y0 - dy1 * yH
        Dim x, y, d As Single   'Hilfsvariablen 
        ' Konvertierungen sind wegen strenger Typpr�fung erforderlich:
        x = Convert.ToSingle(x1 - R)            'linke obere Ecke
        y = Convert.ToSingle(y1 - R)
        d = Convert.ToSingle(2 * R)             'Durchmesser
        ' Kreis zeichnen:

        Dim p As New Pen(Color.Black, 2)
        Dim pm As New Pen(Color.Magenta, 2)
        Dim pb As New Pen(Color.Blue, 2)
        Dim pgr As New Pen(Color.Green, 2)
        Dim g As Graphics = Me.CreateGraphics()

        If Netz = 1 Then g.DrawEllipse(pm, x, y, d, d)
        If Netz = 2 Then g.DrawEllipse(pb, x, y, d, d)
        If Netz = 3 Then g.DrawEllipse(pgr, x, y, d, d)
        If Netz = 0 Then g.DrawEllipse(p, x, y, d, d)
        g.Dispose()

    End Sub

    Private Sub dwl(ByVal dx1 As Double, ByVal dy1 As Double, ByVal dx2 As Double, ByVal dy2 As Double) ' zeichnet relative Linie
        Dim x1, y1, x2, y2 As Double
        x1 = x0 + dx1 * xLL
        y1 = y0 - dy1 * yH
        x2 = x0 + dx2 * xLL
        y2 = y0 - dy2 * yH
        Dim xa, ya, xb, yb As Single   'Hilfsvariablen 
        ' Konvertierungen sind wegen strenger Typpr�fung erforderlich:
        xa = Convert.ToSingle(x1)              'Anfangspunkt
        ya = Convert.ToSingle(y1)
        xb = Convert.ToSingle(x2)              'Endpunkt
        yb = Convert.ToSingle(y2)
        ' Linie zeichnen:
        Dim p As New Pen(Color.Black, 2)
        Dim pm As New Pen(Color.Magenta, 2)
        Dim pb As New Pen(Color.Blue, 2)
        Dim pgr As New Pen(Color.Green, 2)
        Dim pg As New Pen(Color.Gray, 1)
        Dim g As Graphics = Me.CreateGraphics()
        If Netz = 0 Then
            g.DrawLine(p, xa, ya, xb, yb)
            g.Dispose()
        End If
        If Netz = 1 Then
            g.DrawLine(pm, xa, ya, xb, yb)
            g.Dispose()
        End If
        If Netz = 2 Then
            g.DrawLine(pb, xa, ya, xb, yb)
            g.Dispose()
        End If
        If Netz = 3 Then
            g.DrawLine(pgr, xa, ya, xb, yb)
            g.Dispose()
        End If
        If Netz = 10 Then
            g.DrawLine(pg, xa, ya, xb, yb)
            g.Dispose()
        End If
    End Sub
    Private Sub drawRahmen() 'Rahmen zeichnen
        Dim xp, yp As Single
        Dim g As Graphics = Me.CreateGraphics()
        g.Dispose()
        x0 = TextBox10.Left + TextBox10.Width / 2
        y0 = TextBox3.Top + TextBox3.Height / 2
        LL = TextBox15.Left + TextBox15.Width / 2 - x0
        HH = y0 - TextBox2.Top - TextBox2.Height / 2
        Netz = 0

        xLL = LL / (Stundemax - Stundemin)
        yH = HH / (tmax - tmin)
        'Achsen:
        Netz = 0
        dwl(0, 0, Stundemax - Stundemin, 0)
        dwl(0, 0, 0, tmax - tmin)
        If tmin < 0 And tmax > 0 Then
            dwl(0, -tmin, Stundemax - Stundemin, -tmin)
        End If
    End Sub

    Sub EINGABELADUNG1()
        Datei = Objektbezeichnung + "Eingabe.dat"
        FileOpen(1, Datei, OpenMode.Input)
        Input(1, rho)
        Input(1, lam)
        Input(1, c)
        Input(1, PSI)
        For p = 1 To 10
            Input(1, V(p))
            Input(1, Anteil(p))
            Input(1, O(p))
            Input(1, a(p))
            Input(1, b(p))
            Input(1, jmax(p))
            Input(1, kmax(p))
            Input(1, imax(p))
            Input(1, Dx(p))
            Input(1, Dy(p))
            Input(1, VTyp(p))
            Input(1, ZP(p))
            Input(1, DtauPartikel(p))
            Input(1, Oanteil(p))
        Next p
        Input(1, Fak)
        Input(1, Exp)
        Input(1, Hoehe)
        Input(1, Breite)
        Input(1, Laenge)
        Input(1, Vh)
        Input(1, pmax)
        Input(1, Vfest)
        Input(1, mfest)
        Input(1, VLuft)
        Input(1, aFaehigkeit)
        Input(1, Dtaumax)
        Input(1, DtauVorschlag)
        Input(1, Dtau)
        Input(1, BSmax)
        Input(1, Uhrbeginn)
        Input(1, tStart)
        Input(1, ETagfix)
        Input(1, smax)
        Input(1, dK)
        Input(1, Speicherfeld)
        FileClose(1)
    End Sub

    Public Sub EINGABELADUNG2()
        Datei = Objektbezeichnung + "ZVerlauf.dat"
        FileOpen(1, Datei, OpenMode.Input)
        For ETag = 1 To 20
            For Stunde = 0 To 24
                Input(1, VLanteil(ETag, Stunde))
                Input(1, R(ETag, Stunde))
                Input(1, tLETag(ETag, Stunde))
                Input(1, xLETag(ETag, Stunde))
                Input(1, phiETag(ETag, Stunde))
            Next Stunde
        Next ETag
        FileClose(1)
    End Sub

    Sub ERGEBNISLADUNG()
        Datei = Objektbezeichnung + "Ergebnis.dat"
        FileOpen(1, Datei, OpenMode.Input)
        Input(1, BSmax)
        For BS = 0 To BSmax
            Input(1, Tagesstunde(BS))
            Input(1, tLein(BS))
            Input(1, tLaus(BS))
            Input(1, xLein(BS))
            If xLein(BS) <> -273 Then xLein(BS) = xLein(BS) * 1000
            Input(1, xLaus(BS))
            If xLaus(BS) <> -273 Then xLaus(BS) = xLaus(BS) * 1000
            Input(1, phiLein(BS))
            Input(1, phiLaus(BS))
            Input(1, Kondensatmenge(BS))
            Input(1, QMedium(BS))
            Input(1, QSpeicher(BS))
            Input(1, RichtungBS(BS))
            Input(1, Feld)
        Next BS
        FileClose(1)
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        tmax = CType(TextBox2.Text, Single)
        tmin = CType(TextBox3.Text, Single)
        Stundemax = CType(TextBox15.Text, Integer)
        Stundemin = CType(TextBox10.Text, Integer)
        Teilung = CType(TextBox16.Text, Integer)
        If tmax > tmin + 2 And Stundemax > Stundemin + 2 And Teilung > 0 Then
        Else
            TextBox18.Text = "Falsche Ma�stabseingabe!"
        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Korrekturzahl_TT = 0
        Korrekturzahl_BT = 0
        Korrekturzahl_BQ = 0

    End Sub

End Class
