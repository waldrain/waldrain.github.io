Public Class Form5
    Inherits System.Windows.Forms.Form
    Public Datei, cc1, cc2, cc3, cc4, cc1a, cc2a, cc3a, cc4a, ooo, Verlauf, Feld As String
    Public Objektbezeichnung As Object
    Public StartOK, Richtung, k As Integer
    Public s, smax, Stunde As Integer
    Public BS, BSmax As Integer
    Public Korrekturzahl_TT, BSTest, pTest As Integer
    Public Teilung, Stundemin, Stundemax, Stundea, Stundeb, Stundec, Netz As Integer
    Public tOF(120), tK(120) As Single
    Public tL(120), xL(120) As Single

    Public x, y, x1, x2, tmin, tmax, t1, t2 As Single
    Public dHH, tMittel, Stundeteil As Single

    Public x0, y0 As Double              'absolute Bezugskoordinaten
    Public LL, HH, xLL, yH As Single     'maximale Diagrammgr��e

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        'Start der Diagrammdarstellung
        Dim g As Graphics = Me.CreateGraphics
        g.Clear(Me.BackColor)        'Zeichnung l�schen
        Korrekturzahl_TT = 0
    End Sub

#Region " Vom Windows Form Designer generierter Code "

    Public Sub New()
        MyBase.New()

        ' Dieser Aufruf ist f�r den Windows Form-Designer erforderlich.
        InitializeComponent()

        ' Initialisierungen nach dem Aufruf InitializeComponent() hinzuf�gen

    End Sub

    ' Die Form �berschreibt den L�schvorgang der Basisklasse, um Komponenten zu bereinigen.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' F�r Windows Form-Designer erforderlich
    Private components As System.ComponentModel.IContainer

    'HINWEIS: Die folgende Prozedur ist f�r den Windows Form-Designer erforderlich
    'Sie kann mit dem Windows Form-Designer modifiziert werden.
    'Verwenden Sie nicht den Code-Editor zur Bearbeitung.
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox10 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox13 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox14 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox15 As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox26 = New System.Windows.Forms.TextBox
        Me.TextBox25 = New System.Windows.Forms.TextBox
        Me.TextBox18 = New System.Windows.Forms.TextBox
        Me.TextBox14 = New System.Windows.Forms.TextBox
        Me.TextBox20 = New System.Windows.Forms.TextBox
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.TextBox6 = New System.Windows.Forms.TextBox
        Me.TextBox5 = New System.Windows.Forms.TextBox
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Label23 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label75 = New System.Windows.Forms.Label
        Me.TextBox17 = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.TextBox15 = New System.Windows.Forms.TextBox
        Me.TextBox13 = New System.Windows.Forms.TextBox
        Me.TextBox16 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBox12 = New System.Windows.Forms.TextBox
        Me.Button7 = New System.Windows.Forms.Button
        Me.TextBox11 = New System.Windows.Forms.TextBox
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.CheckBox10 = New System.Windows.Forms.CheckBox
        Me.CheckBox13 = New System.Windows.Forms.CheckBox
        Me.CheckBox14 = New System.Windows.Forms.CheckBox
        Me.CheckBox15 = New System.Windows.Forms.CheckBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox26
        '
        Me.TextBox26.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox26.ForeColor = System.Drawing.Color.Green
        Me.TextBox26.Location = New System.Drawing.Point(24, 256)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(48, 23)
        Me.TextBox26.TabIndex = 633
        Me.TextBox26.Text = ""
        Me.TextBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox25
        '
        Me.TextBox25.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox25.ForeColor = System.Drawing.Color.Blue
        Me.TextBox25.Location = New System.Drawing.Point(24, 232)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(48, 23)
        Me.TextBox25.TabIndex = 632
        Me.TextBox25.Text = ""
        Me.TextBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox18
        '
        Me.TextBox18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox18.Location = New System.Drawing.Point(8, 88)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(316, 27)
        Me.TextBox18.TabIndex = 620
        Me.TextBox18.Text = ""
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(768, 8)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(464, 27)
        Me.TextBox14.TabIndex = 596
        Me.TextBox14.Text = ""
        '
        'TextBox20
        '
        Me.TextBox20.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.ForeColor = System.Drawing.Color.Green
        Me.TextBox20.Location = New System.Drawing.Point(760, 80)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(376, 26)
        Me.TextBox20.TabIndex = 623
        Me.TextBox20.Text = ""
        '
        'TextBox7
        '
        Me.TextBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.ForeColor = System.Drawing.Color.Green
        Me.TextBox7.Location = New System.Drawing.Point(760, 48)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(376, 26)
        Me.TextBox7.TabIndex = 604
        Me.TextBox7.Text = ""
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.ForeColor = System.Drawing.Color.Magenta
        Me.TextBox6.Location = New System.Drawing.Point(368, 48)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(376, 26)
        Me.TextBox6.TabIndex = 603
        Me.TextBox6.Text = ""
        '
        'TextBox5
        '
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.948052!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.ForeColor = System.Drawing.Color.Blue
        Me.TextBox5.Location = New System.Drawing.Point(368, 80)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(376, 26)
        Me.TextBox5.TabIndex = 602
        Me.TextBox5.Text = ""
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(192, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(24, 208)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(48, 23)
        Me.TextBox4.TabIndex = 601
        Me.TextBox4.Text = ""
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(8, 168)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(64, 27)
        Me.TextBox2.TabIndex = 597
        Me.TextBox2.Text = ""
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(8, 616)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(64, 27)
        Me.TextBox3.TabIndex = 598
        Me.TextBox3.Text = ""
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.883117!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(8, 48)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(316, 28)
        Me.TextBox1.TabIndex = 592
        Me.TextBox1.Text = ""
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button1.Location = New System.Drawing.Point(528, 704)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(248, 32)
        Me.Button1.TabIndex = 617
        Me.Button1.Text = "Betriebsverl�ufe im Speicher*"
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.Magenta
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Button5.Location = New System.Drawing.Point(160, 8)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(168, 32)
        Me.Button5.TabIndex = 599
        Me.Button5.Text = "Grenzwertbest�tigung"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.TopLeft
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(488, 8)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(280, 23)
        Me.Label23.TabIndex = 595
        Me.Label23.Text = "Pfad und vorhandener Dateiname:"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Magenta
        Me.Button2.Location = New System.Drawing.Point(1160, 776)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(96, 40)
        Me.Button2.TabIndex = 593
        Me.Button2.Text = "BEENDEN"
        '
        'Label75
        '
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label75.Location = New System.Drawing.Point(960, 728)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(200, 48)
        Me.Label75.TabIndex = 630
        Me.Label75.Text = "Zum Starten CheckBoxen anklicken und dar�ber befindlichen Button dr�cken!"
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(8, 392)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(64, 27)
        Me.TextBox17.TabIndex = 615
        Me.TextBox17.Text = ""
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label11.Location = New System.Drawing.Point(960, 776)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(184, 32)
        Me.Label11.TabIndex = 631
        Me.Label11.Text = "*Funktion erst nach erfolgter Berechnung aktiv!"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.White
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Magenta
        Me.Label9.Location = New System.Drawing.Point(8, 8)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(144, 23)
        Me.Label9.TabIndex = 629
        Me.Label9.Text = "Ma�stabs�nderung >"
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(1200, 648)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(48, 27)
        Me.TextBox15.TabIndex = 612
        Me.TextBox15.Text = ""
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(912, 648)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(48, 27)
        Me.TextBox13.TabIndex = 611
        Me.TextBox13.Text = ""
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox16
        '
        Me.TextBox16.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox16.ForeColor = System.Drawing.Color.Magenta
        Me.TextBox16.Location = New System.Drawing.Point(8, 792)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(48, 24)
        Me.TextBox16.TabIndex = 614
        Me.TextBox16.Text = ""
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Magenta
        Me.Label1.Location = New System.Drawing.Point(8, 760)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 32)
        Me.Label1.TabIndex = 613
        Me.Label1.Text = "Teilung der Ordinate:"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(624, 648)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(48, 27)
        Me.TextBox12.TabIndex = 610
        Me.TextBox12.Text = ""
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.Magenta
        Me.Button7.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Button7.Location = New System.Drawing.Point(336, 8)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(128, 32)
        Me.Button7.TabIndex = 605
        Me.Button7.Text = "Originalma�stab"
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.TopLeft
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(336, 648)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(48, 27)
        Me.TextBox11.TabIndex = 609
        Me.TextBox11.Text = ""
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(56, 648)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(48, 27)
        Me.TextBox10.TabIndex = 608
        Me.TextBox10.Text = ""
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(192, Byte))
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.CheckBox10)
        Me.GroupBox1.Controls.Add(Me.CheckBox13)
        Me.GroupBox1.Controls.Add(Me.CheckBox14)
        Me.GroupBox1.Controls.Add(Me.CheckBox15)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.012987!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox1.Location = New System.Drawing.Point(376, 744)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(552, 64)
        Me.GroupBox1.TabIndex = 618
        Me.GroupBox1.TabStop = False
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(192, Byte))
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(208, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 23)
        Me.Label3.TabIndex = 631
        Me.Label3.Text = "Partikelzustand:"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(192, Byte))
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.765101!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 23)
        Me.Label2.TabIndex = 630
        Me.Label2.Text = "Luftzustand:"
        '
        'CheckBox10
        '
        Me.CheckBox10.ForeColor = System.Drawing.Color.Black
        Me.CheckBox10.Location = New System.Drawing.Point(336, 40)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(208, 24)
        Me.CheckBox10.TabIndex = 164
        Me.CheckBox10.Text = "Oberfl�chentemperatur"
        '
        'CheckBox13
        '
        Me.CheckBox13.ForeColor = System.Drawing.Color.Black
        Me.CheckBox13.Location = New System.Drawing.Point(336, 8)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(160, 24)
        Me.CheckBox13.TabIndex = 160
        Me.CheckBox13.Text = "Kerntemperatur "
        '
        'CheckBox14
        '
        Me.CheckBox14.ForeColor = System.Drawing.Color.Black
        Me.CheckBox14.Location = New System.Drawing.Point(120, 40)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(112, 24)
        Me.CheckBox14.TabIndex = 159
        Me.CheckBox14.Text = "x_Luft"
        '
        'CheckBox15
        '
        Me.CheckBox15.ForeColor = System.Drawing.Color.Black
        Me.CheckBox15.Location = New System.Drawing.Point(120, 8)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(96, 24)
        Me.CheckBox15.TabIndex = 140
        Me.CheckBox15.Text = "t_Luft"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(1024, 648)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 24)
        Me.Label5.TabIndex = 600
        Me.Label5.Text = "Abschnitt s"
        '
        'TextBox8
        '
        Me.TextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.214766!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.ForeColor = System.Drawing.Color.Blue
        Me.TextBox8.Location = New System.Drawing.Point(456, 144)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(384, 27)
        Me.TextBox8.TabIndex = 634
        Me.TextBox8.Text = ""
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label4.Location = New System.Drawing.Point(128, 744)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(232, 32)
        Me.Label4.TabIndex = 635
        Me.Label4.Text = "Hinweis: Der Abschnitt s=1 erstreckt sich von der Achsteilung 0 bis 1."
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.077922!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(0, Byte), CType(64, Byte))
        Me.Label6.Location = New System.Drawing.Point(128, 776)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(232, 32)
        Me.Label6.TabIndex = 636
        Me.Label6.Text = "Der Abschnitt s=100 erstreckt sich von der Achsteilung 99 bis 100 usw."
        '
        'Form5
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(8, 20)
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1270, 819)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox26)
        Me.Controls.Add(Me.TextBox25)
        Me.Controls.Add(Me.TextBox18)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.TextBox20)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.TextBox17)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextBox15)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label5)
        Me.Name = "Form5"
        Me.Text = "Zustandsverl�ufe l�ngs des Speichers"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Darstellung der Zustandsverl�ufe l�ngs des Speichers als Ergebnis der Simulation
        Dim g As Graphics = Me.CreateGraphics
        g.Clear(Me.BackColor)        'Zeichnung l�schen
        Call EINGABELADUNG_VERLAUF()

        If Korrekturzahl_TT = 0 Then
            tmin = -10
            tmax = 30
            Stundemin = 0
            Stundemax = 72
            Korrekturzahl_TT = 1
            Teilung = 4
        End If
        If Richtung = 1 Then ooo = " (von links nach rechts)"
        If Richtung = -1 Then ooo = " (von rechts nach links)"
        If Richtung = 0 Then ooo = " (Stillstand)"
        TextBox8.Text = "Durchstr�mrichtung: " + Richtung.ToString + ooo
        tMittel = (tmax + tmin) / 2
        tMittel = Int(tMittel)
        TextBox17.Text = tMittel.ToString
        'Konstante x-Achse f�r die gesamte Speicherl�nge smax
        Stundemin = 0
        Stundemax = smax
        Stundeteil = (Stundemax - Stundemin) / 4
        Stundea = Int(Stundemin + Stundeteil)
        Stundeb = Int(Stundemin + 2 * Stundeteil)
        Stundec = Int(Stundemin + 3 * Stundeteil)
        TextBox10.Text = Stundemin.ToString
        TextBox11.Text = Stundea.ToString
        TextBox12.Text = Stundeb.ToString
        TextBox13.Text = Stundec.ToString
        TextBox15.Text = Stundemax.ToString
        TextBox16.Text = Teilung.ToString()
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox20.Text = ""
        TextBox4.Text = ""
        TextBox25.Text = ""
        TextBox26.Text = ""
        TextBox1.Text = "Speicherzustand f�r BS = " + BSTest.ToString
        TextBox2.Text = tmax.ToString()
        TextBox3.Text = tmin.ToString()
        TextBox18.Text = "Partikelnummer p = " + pTest.ToString
        Call drawRahmen()
        'y-Achsteilung
        Netz = 10
        x = (Stundemax - Stundemin) / 100
        dHH = (tmax - tmin) / 5 / Teilung
        For k = 1 To (5 * Teilung)
            y = k * dHH
            If k / 5 = Int(k / 5) Then
                dwl(0, y, Stundemax - Stundemin, y)
            Else
                dwl(0, y, x, y)
            End If
        Next
        'x-Achsteilung
        Netz = 10
        y = (tmax - tmin) / 50
        For k = Stundemin To Stundemax
            If k = Stundea Or k = Stundeb Or k = Stundec Or k = Stundemax Then
                dwl(k - Stundemin, 0, k - Stundemin, tmax - tmin)
            Else
                dwl(k - Stundemin, 0, k - Stundemin, y)
            End If
        Next k

        'Temperaturverl�ufe nach Ergebnissen am Ende der Betriebsstunde BSTest
        cc1 = "" : cc2 = "" : cc3 = "" : cc4 = ""
        cc1a = "" : cc2a = "" : cc3a = "" : cc4a = ""
        If CheckBox15.CheckState = 1 And Richtung = 1 Then
            cc1 = "Lufttemperatur - magenta"
            TextBox4.Text = " �C"
            Netz = 1
            For Stunde = Stundemin + 2 To Stundemax + 1
                t1 = tL(Stunde - 1)
                t2 = tL(Stunde)
                x1 = Stunde - 2 - Stundemin
                x2 = Stunde - 1 - Stundemin
                If t2 = -273 Then t2 = t1
                If t1 > -273 Then dwl(x1, t1 - tmin, x2, t2 - tmin)
            Next
        ElseIf CheckBox15.CheckState = 1 And Richtung = -1 Then
            cc1 = "Lufttemperatur - magenta"
            TextBox4.Text = " �C"
            Netz = 1
            For Stunde = Stundemin + 1 To Stundemax
                t1 = tL(Stunde - 1)
                t2 = tL(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If t2 = -273 Then t2 = t1
                If t1 > -273 Then dwl(x1, t1 - tmin, x2, t2 - tmin)
            Next
        ElseIf CheckBox15.CheckState = 1 And Richtung = 0 Then
            cc1 = "Bei Stillstand keine Lufttemperaturanzeige!"
            TextBox4.Text = ""
        End If

        If CheckBox14.CheckState = 1 And Richtung = 1 Then
            cc2 = "Abs. Luftfeuchte - blau"
            TextBox25.Text = " g/kg"
            Netz = 2
            For Stunde = Stundemin + 2 To Stundemax + 1
                t1 = xL(Stunde - 1)
                t2 = xL(Stunde)
                x1 = Stunde - 2 - Stundemin
                x2 = Stunde - 1 - Stundemin
                If t2 = -273 Then t2 = t1
                If t1 > -273 Then dwl(x1, t1 - tmin, x2, t2 - tmin)
            Next
        ElseIf CheckBox14.CheckState = 1 And Richtung = -1 Then
            cc2 = "Abs. Luftfeuchte - blau"
            TextBox25.Text = " g/kg"
            Netz = 2
            For Stunde = Stundemin + 1 To Stundemax
                t1 = xL(Stunde - 1)
                t2 = xL(Stunde)
                x1 = Stunde - 1 - Stundemin
                x2 = Stunde - Stundemin
                If t2 = -273 Then t2 = t1
                If t1 > -273 Then dwl(x1, t1 - tmin, x2, t2 - tmin)
            Next
        ElseIf CheckBox14.CheckState = 1 And Richtung = 0 Then
            cc2 = "Bei Stillstand keine Luftfeuchteanzeige!"
            TextBox25.Text = ""
        End If

        If CheckBox10.CheckState = 1 Then
            cc3 = "Partikeloberfl�chentemperatur - gr�n"
            TextBox26.Text = " �C"
            Netz = 3
            For Stunde = Stundemin + 2 To Stundemax
                t1 = tOF(Stunde - 1)
                t2 = tOF(Stunde)
                x1 = Stunde - 1.5 - Stundemin
                x2 = Stunde - 0.5 - Stundemin
                If t2 = -273 Then t2 = t1
                If t1 > -273 Then dwl(x1, t1 - tmin, x2, t2 - tmin)
            Next
        End If
        If CheckBox13.CheckState = 1 Then
            cc3a = "Partikelkerntemperatur - gr�n mit Punkten"
            TextBox26.Text = " �C"
            Netz = 3
            For Stunde = Stundemin + 2 To Stundemax
                t1 = tK(Stunde - 1)
                t2 = tK(Stunde)
                x1 = Stunde - 1.5 - Stundemin
                x2 = Stunde - 0.5 - Stundemin
                If t2 = -273 Then t2 = t1
                If t1 > -273 Then
                    dwl(x1, t1 - tmin, x2, t2 - tmin)
                    dwc(x1, t1 - tmin, 2)
                    dwc(x2, t2 - tmin, 2)
                End If
            Next
        End If
        TextBox6.Text = cc1
        TextBox5.Text = cc2
        TextBox7.Text = cc3
        TextBox20.Text = cc3a
Label_BT:
    End Sub

    Private Sub dwc(ByVal dx1 As Double, ByVal dy1 As Double, ByVal R As Double) ' zeichnet relative Linie
        Dim x1, y1 As Double
        x1 = x0 + dx1 * xLL
        y1 = y0 - dy1 * yH
        Dim x, y, d As Single   'Hilfsvariablen 
        ' Konvertierungen sind wegen strenger Typpr�fung erforderlich:
        x = Convert.ToSingle(x1 - R)            'linke obere Ecke
        y = Convert.ToSingle(y1 - R)
        d = Convert.ToSingle(2 * R)             'Durchmesser
        ' Kreis zeichnen:

        Dim p As New Pen(Color.Black, 2)
        Dim pm As New Pen(Color.Magenta, 2)
        Dim pb As New Pen(Color.Blue, 2)
        Dim pgr As New Pen(Color.Green, 2)
        Dim g As Graphics = Me.CreateGraphics()

        If Netz = 1 Then g.DrawEllipse(pm, x, y, d, d)
        If Netz = 2 Then g.DrawEllipse(pb, x, y, d, d)
        If Netz = 3 Then g.DrawEllipse(pgr, x, y, d, d)
        If Netz = 0 Then g.DrawEllipse(p, x, y, d, d)
        g.Dispose()

    End Sub

    Private Sub dwl(ByVal dx1 As Double, ByVal dy1 As Double, ByVal dx2 As Double, ByVal dy2 As Double) ' zeichnet relative Linie
        Dim x1, y1, x2, y2 As Double
        x1 = x0 + dx1 * xLL
        y1 = y0 - dy1 * yH
        x2 = x0 + dx2 * xLL
        y2 = y0 - dy2 * yH
        Dim xa, ya, xb, yb As Single   'Hilfsvariablen 
        ' Konvertierungen sind wegen strenger Typpr�fung erforderlich:
        xa = Convert.ToSingle(x1)              'Anfangspunkt
        ya = Convert.ToSingle(y1)
        xb = Convert.ToSingle(x2)              'Endpunkt
        yb = Convert.ToSingle(y2)
        ' Linie zeichnen:
        Dim p As New Pen(Color.Black, 2)
        Dim pm As New Pen(Color.Magenta, 2)
        Dim pb As New Pen(Color.Blue, 2)
        Dim pgr As New Pen(Color.Green, 2)
        Dim pg As New Pen(Color.Gray, 1)
        Dim g As Graphics = Me.CreateGraphics()
        If Netz = 0 Then
            g.DrawLine(p, xa, ya, xb, yb)
            g.Dispose()
        End If
        If Netz = 1 Then
            g.DrawLine(pm, xa, ya, xb, yb)
            g.Dispose()
        End If
        If Netz = 2 Then
            g.DrawLine(pb, xa, ya, xb, yb)
            g.Dispose()
        End If
        If Netz = 3 Then
            g.DrawLine(pgr, xa, ya, xb, yb)
            g.Dispose()
        End If
        If Netz = 10 Then
            g.DrawLine(pg, xa, ya, xb, yb)
            g.Dispose()
        End If
    End Sub
    Private Sub drawRahmen() 'Rahmen zeichnen
        Dim xp, yp As Single
        Dim g As Graphics = Me.CreateGraphics()
        g.Dispose()
        x0 = TextBox10.Left + TextBox10.Width / 2
        y0 = TextBox3.Top + TextBox3.Height / 2
        LL = TextBox15.Left + TextBox15.Width / 2 - x0
        HH = y0 - TextBox2.Top - TextBox2.Height / 2
        Netz = 0

        xLL = LL / (Stundemax - Stundemin)
        yH = HH / (tmax - tmin)
        'Achsen:
        Netz = 0
        dwl(0, 0, Stundemax - Stundemin, 0)
        dwl(0, 0, 0, tmax - tmin)
        If tmin < 0 And tmax > 0 Then
            dwl(0, -tmin, Stundemax - Stundemin, -tmin)
        End If
    End Sub

    Sub EINGABELADUNG_VERLAUF()
        Verlauf = Objektbezeichnung + "Speicherverlauf.dat"
        FileOpen(1, Verlauf, OpenMode.Input)
        Input(1, BSTest)
        Input(1, pTest)
        Input(1, smax)
        Input(1, Richtung)
        For s = 0 To smax + 1
            Input(1, tL(s))
            Input(1, xL(s))
            xL(s) = xL(s) * 1000
            Input(1, tK(s))
            Input(1, tOF(s))
        Next s
        FileClose(1)
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        tmax = CType(TextBox2.Text, Single)
        tmin = CType(TextBox3.Text, Single)
        Stundemax = CType(TextBox15.Text, Integer)
        Stundemin = CType(TextBox10.Text, Integer)
        Teilung = CType(TextBox16.Text, Integer)
        If tmax > tmin + 2 And Stundemax > Stundemin + 2 And Teilung > 0 Then
        Else
            TextBox18.Text = "Falsche Ma�stabseingabe!"
        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Korrekturzahl_TT = 0
    End Sub
End Class
